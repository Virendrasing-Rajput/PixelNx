var base_url;
$(document).ready(function(){
base_url = $('#base_url').val();
	
	$('#filterByPatientType').on('change' , function(){
		var patient_type = $(this).val();
		   if(patient_type==0){
           		$('#append_p_type').show();
           		$('#other_p_type').addClass('require');
           		$(this).removeClass('require');
		   }else{
		   		$('#append_p_type').hide();
		   		$('#other_p_type').removeClass('require');
		   		$(this).addClass('require');
		   }
	});

	$('#filterByDocName').on('change' , function(){
		var doc_name = $(this).val();
		   if(doc_name==0){
           		$('#append_other_doc').show();
           		$('#other_doc_name').addClass('require');
           		$(this).removeClass('require');
		   }else{
		   		$('#append_other_doc').hide();
		   		$('#other_doc_name').removeClass('require');
		   		$(this).addClass('require');
		   }
	});

	$('#filterByAssetCat').on('change' , function(){
		var asset_cat_name = $(this).val();
		   if(asset_cat_name==0){
           		$('#append_asset_cat').show();
           		$('#other_asset_cat').addClass('require');
           		$(this).removeClass('require');
		   }else{
		   		$('#append_asset_cat').hide();
		   		$('#other_asset_cat').removeClass('require');
		   		$(this).addClass('require');
		   }
	});

	$('#filterByTestCat').on('change' , function(){
		var test_cat_name = $(this).val();
		   if(test_cat_name==0){
           		$('#append_other_test_cat').show();
           		$('#other_test_cat').addClass('require');
           		$(this).removeClass('require');
		   }else{
		   		$('#append_other_test_cat').hide();
		   		$('#other_test_cat').removeClass('require');
		   		$(this).addClass('require');
		   }
	});

	$(function(){
  		$('#datepicker').appendDtpicker({'locale':'en'});
   });

	$(function(){
  		$('.date_only').appendDtpicker({
  			'locale':'en',
  			"dateOnly":true,
  			"autodateOnStart":false
  		});
   });
	
});

    function check_form(element){
		var chk = checkRequire(element);
		if(chk == 0){
			var target = (typeof element == 'object')? $(element):$('#'+element);
			target.submit();
		}
	}

	function on_submit(element){
		var chk = checkRequire(element);
		if(chk == 0){
			return true;
		}else{
			return false;
		}
	}

	$('.return_number').on('keypress',function(evt){
	  var charCode = (evt.which) ? evt.which : event.keyCode;
	  if (charCode > 31 && (charCode < 48 || charCode > 57)){
	   return false;
	  }else{
	   return true;
	  } 
 });