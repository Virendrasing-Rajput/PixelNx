var base_url = '';
$(document).ready(function() {
	
	base_url = $('#base_url').val();
	
	
	var Base64={_keyStr:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",encode:function(r){var t,e,o,a,h,n,c,d="",C=0;for(r=Base64._utf8_encode(r);C<r.length;)t=r.charCodeAt(C++),e=r.charCodeAt(C++),o=r.charCodeAt(C++),a=t>>2,h=(3&t)<<4|e>>4,n=(15&e)<<2|o>>6,c=63&o,isNaN(e)?n=c=64:isNaN(o)&&(c=64),d=d+this._keyStr.charAt(a)+this._keyStr.charAt(h)+this._keyStr.charAt(n)+this._keyStr.charAt(c);return d},decode:function(r){var t,e,o,a,h,n,c,d="",C=0;for(r=r.replace(/[^A-Za-z0-9\+\/\=]/g,"");C<r.length;)a=this._keyStr.indexOf(r.charAt(C++)),h=this._keyStr.indexOf(r.charAt(C++)),n=this._keyStr.indexOf(r.charAt(C++)),c=this._keyStr.indexOf(r.charAt(C++)),t=a<<2|h>>4,e=(15&h)<<4|n>>2,o=(3&n)<<6|c,d+=String.fromCharCode(t),64!=n&&(d+=String.fromCharCode(e)),64!=c&&(d+=String.fromCharCode(o));return d=Base64._utf8_decode(d)},_utf8_encode:function(r){r=r.replace(/\r\n/g,"\n");for(var t="",e=0;e<r.length;e++){var o=r.charCodeAt(e);128>o?t+=String.fromCharCode(o):o>127&&2048>o?(t+=String.fromCharCode(o>>6|192),t+=String.fromCharCode(63&o|128)):(t+=String.fromCharCode(o>>12|224),t+=String.fromCharCode(o>>6&63|128),t+=String.fromCharCode(63&o|128))}return t},_utf8_decode:function(r){for(var t="",e=0,o=c1=c2=0;e<r.length;)o=r.charCodeAt(e),128>o?(t+=String.fromCharCode(o),e++):o>191&&224>o?(c2=r.charCodeAt(e+1),t+=String.fromCharCode((31&o)<<6|63&c2),e+=2):(c2=r.charCodeAt(e+1),c3=r.charCodeAt(e+2),t+=String.fromCharCode((15&o)<<12|(63&c2)<<6|63&c3),e+=3);return t}};
	
	$(document).on('click','.fs_add_campaign_click' , function(){
		if($('.fs_campaign.automation').hasClass('fs_add_campaign')){
			$('.fs_campaign.fs_add_campaign').find('.addEditMessage').trigger('click');
			$(this).closest('.row').find('.messageCustomisation').addClass('hide');	
		}
		$(this).parent().addClass('adding');
		$(this).closest('.row').find('.messageCustomisation').removeClass('hide');
	});
	// preset sortable
	$('ul.preset_list li').draggable({
		revert: true,
		helper: "clone"
	});
	
	$('input#post_search').on('keyup' , function(event){
		if (event.which == 13) {  
			event.preventDefault();
			search_post();
		}
	});
	
	$('#removeSearchPost').click(function(){
		if($('#post_search').val().trim() !== ''){
			$('#post_search').val('');
			get_all_post_data();
		}
	});
	
	function search_post(){ 
		var post_id = $('input#post_search').val().trim();
		if(post_id != ''){
			$('.fs_loading_wrapper').show();
			$.ajax({
				method : 'post',
				url : base_url+'ajax/get_my_page_post_test',
				data : {'page_id' : $('#chooseAutomationpage').selectpicker('val') ,'post_id' : post_id}
			}).done(function(resp){
				$('.fs_loading_wrapper').hide();
				if(resp != ''){
					var myRes = resp.split('@~%^&*!@');
					console.log(myRes[0]);
					if(myRes[0] == 1){
						if(myRes[1] != ''){
							$('#pagePostList').html(myRes[1]);
						}else{
							toastr.error('Invalid post id.','Error');
						}
					}else{
						location.reload();
					}
				}else{
					toastr.error('Something went wrong , please try again' , 'Error');
				}
			});	
		}
	}
	
	
	//add new automation
	var campaign_box_html = $('#compaignBody').find('.row:last')[0].outerHTML;
	var campaignNameField = '<div class="row"><div class="col-md-8"><div class="fs_input_wrapper"><input type="text" id="postCampainName" class="form-control" placeholder="Campaign Name"></div></div></div>';
	var make_droppable = function($elements) {
		$elements.droppable({
			drop: function( event, ui ) {
				var d_target = $(this);
				var target = $(ui.helper[0].outerHTML).attr('data-target');
				var target_text = $(ui.helper[0].outerHTML).text();
				if(target != 0 || typeof target != 'undefined'){
					$.ajax({
						method:'post',
						url : base_url+'ajax/get_preset',
						data : {'target' : target}
					}).done(function(resp){
						if(resp != 0){
							resp = $.parseJSON(resp);
							if(typeof resp['preset_title'] != 'undefined'){
								
								if($('.fs_campaign.automation').hasClass('fs_add_campaign')){
									$('.fs_campaign.fs_add_campaign').find('.addEditMessage').trigger('click');
									$('.messageCustomisation').addClass('hide');
								}
								
								if(d_target.find('.add_icon').length){
									d_target.html('');
									$('#compaignBody').append(campaign_box_html);
									make_droppable($( "#compaignBody .droppable" ));
								}
								
								if(!d_target.hasClass('complete')){
									var targetForm = d_target.closest('form.campaign');
									var meDesc = $.parseJSON(resp['preset_description']);
									targetForm.find('input[name="broadcast_link"]').val(meDesc['message_link'][1]);
									targetForm.find('input[name="broadcast_link_text"]').val(meDesc['message_link'][0]);
									
									targetForm.find('input[name="broadcast_call_to_action"]').val(meDesc['message_call_to_action']);
									targetForm.find('input[name="message_image"]').val(meDesc['message_image']);
									targetForm.find('input[name="broadcast_image_url"]').val(meDesc['message_image']);
									
									
									targetForm.find('input[name="broadcast_headline"]').val(meDesc['message_headline']);
									targetForm.find('textarea[name="broadcast_description"]').val(meDesc['message_description']);
									var textBox = '<div class="fs_add_custom__msg"><div class="fs_input_wrapper"><textarea class="form-control messageBox" placeholder="Type custom message" name="message" maxlength="600">'+meDesc['message']+'</textarea></div><div class="btn_group"><a class="btn cancelEditMessage">Cancel</a><a class="btn addEditMessage">Save</a></div></div>';
									d_target.html(textBox).addClass('complete');
									d_target.closest('.fs_campaign').addClass('fs_add_campaign adding');
									if(targetForm.find('[name="broadcast_video"]').length && meDesc['message_video']){
										targetForm.find('[name="broadcast_video"]').val(meDesc['message_video']);
									}
									d_target.parent().find('.action').removeClass('hide'); 
									targetForm.find('.messageCustomisation').removeClass('hide');
									dynamic_target();
									$('.fs_loading_wrapper').hide();
									//var res_data = '<h3 data-target="'+target+'">'+ersp+'</h3>';
									
										  
								}else{
									$('.fs_loading_wrapper').hide();
									toastr.error('Complete this message.','notice');
								}
							}else{
								$('.fs_loading_wrapper').hide();
								toastr.error('Something went wrong , please try again' , 'Error');
							}
						}else{ 
							toastr.error('Something went wrong , please try again' , 'Error');
						}
					});
					
					
				}
			}
		});
	}

	make_droppable($( "#compaignBody .droppable" ));
	
	//new automation section 
	$('select#chooseAutomationpage').change(function(){
		$('.fs_loading_wrapper').show();
		if($(this).selectpicker('val') != ''){ 
			$('#preSetList').removeClass('hide').parent().css('overflow','hidden');
			$('#compaignBody,#saveAutomationCampaign').removeClass('hide');
			if($('#pagePostTitle').length){
				$('#post_search').val('');
				get_all_post_data();
			}else{
				$('.fs_loading_wrapper').hide();
				$('#myGeneralResp').removeClass('hide');
				$('body').removeClass('mCustomScrollBox_fullHeight');
			}
			 
		}else{
			$('#preSetList,#compaignBody,#saveAutomationCampaign').addClass('hide').parent().css('overflow','');
			
			$('#preSetList').addClass('hide').parent().css('overflow','');
			$('#compaignBody,#saveAutomationCampaign').addClass('hide');
		}
	});
	
	function get_all_post_data(){
		$('.fs_loading_wrapper').show();
		$.ajax({
			method : 'post',
			url : base_url+'ajax/get_my_page_post',
			data : {'page_id' : $('#chooseAutomationpage').selectpicker('val')}
		}).done(function(resp){
			$('.fs_loading_wrapper').hide();
			if(resp != ''){
				var myRes = resp.split('@~%^&*!@');
				console.log(myRes[0]);
				if(myRes[0] == 1){
					$('#pagePostList').text('');
					if(myRes[1] != ''){
						$('#pagePostTitle').text('Select a Post');
						$('#pagePostListKeyword,#myGeneralResp').removeClass('hide');
						$('#pagePostList').html(myRes[1]);
						$('body').removeClass('mCustomScrollBox_fullHeight');
					}else{
						$('#pagePostTitle').text('Post not available');
					}
					$('#genRespMsg').val((myRes[2] != '')?myRes[2]:'');
				}else{
					location.reload();
				}
			}else{
				toastr.error('Somethiing went wrong , please try again' , 'Error');
			}
		});
	}
	
	
	
	//add Campaign 
	$('#addCampaign').on('click' , function(){
		var page = $('#chooseAutomationpage').val();
	});
	
	//add custom message in campaign
	$(document).on('click' , '#addCustomMessage' , function(){
		var msg = $(this).closest('.fs_add_custom__msg').find('.form-control').val().trim();
		if(msg != ''){ 
			$(this).closest('.fs_add_custom__msg').find('.fs_input_wrapper').removeClass('Error');
			if(!$(this).closest('.content').hasClass('complete')){
				$(this).closest('.fs_add_campaign').find('.action').removeClass('hide'); 
				$(this).closest('.fs_campaign').removeClass('fs_add_campaign');
				$('#compaignBody').append(campaign_box_html);
				dynamic_target();
				make_droppable($( "#compaignBody .droppable" ));
				var res_data = '<h3>'+msg+'</h3> <input type="hidden" name="message" value="'+Base64.encode(msg)+'">';
				$(this).closest('.content').html(res_data).addClass('complete');
				$('.messageCustomisation').addClass('hide');	
			}else{
				toastr.error('Complete this message.','notice');
			}
		}else{
			$(this).closest('.fs_add_custom__msg').find('.fs_input_wrapper').addClass('Error');
			toastr.error('Field is required.' , 'Error');
		} 
	});
	
	 
	//hide costom message box
	$(document).on('click' ,'#cancelCustomMessage' , function(){
		$(this).closest('.fs_campaign').removeClass('adding');
		$('.messageCustomisation').addClass('hide');
	});
	
	//sdit campaign
	var editCustomMessage = '';
	$(document).on('click', 'a.editCamp', function(){
		$('.row .messageCustomisation').addClass('hide');
		$('.row .addEditMessage').trigger('click');
		$(this).closest('.row').find('.messageCustomisation').removeClass('hide');
		var target_parent = $(this).closest('.fs_campaign');
		target_parent.addClass('fs_add_campaign');
		editCustomMessage =  target_parent.find('.content h3').text();
		editCustomMessage = (editCustomMessage == '')?target_parent.find('.content .form-control').val():editCustomMessage;
		editCustomMessage = (typeof editCustomMessage != 'undefined')?editCustomMessage:'';
		var edit_html = '<div class="fs_add_custom__msg"><div class="fs_input_wrapper"><textarea class="form-control  messageBox" placeholder="Type custom message" name="message" maxlength="600">'+editCustomMessage+'</textarea></div><div class="btn_group"><a class="btn cancelEditMessage">Cancel</a><a class="btn addEditMessage">Save</a></div></div>';
		target_parent.find('.content').html(edit_html); 
		target_parent.addClass('adding');
	});
	
	function dynamic_target(){
		var cntAccord = 1;
		$('.messageCustomisation').each(function(){
			$(this).find('.panel').each(function(){
				var tar = 'collapse'+cntAccord;
				$(this).find('.panel_heading').attr('href' , '#'+tar);
				$(this).find('.panel-collapse').attr('id' , tar);
				cntAccord++;	
			});
		});
	}
	
	$(document).on('click' , '.cancelEditMessage' , function(){
		$(this).closest('.content').html('<h3>'+editCustomMessage+'</h3> <input type="hidden" name="message" value="'+Base64.encode(editCustomMessage)+'">');
		var target_parent = $(this).closest('.fs_campaign').removeClass('adding fs_add_campaign');
		$('.messageCustomisation').addClass('hide');
	}); 
	
	$(document).on('click' , '.addEditMessage' , function(){
		var msg = $(this).closest('.fs_add_custom__msg').find('.form-control').val().trim();
		if(msg != ''){
			$(this).closest('.content').html('<h3>'+msg+'</h3> <input type="hidden" name="message" value="'+Base64.encode(msg)+'">');
			$('.messageCustomisation').addClass('hide');
			var target_parent = $(this).closest('.fs_add_campaign').removeClass('adding fs_add_campaign');
		}else{
			check_message_null = 0;
			$(this).closest('.fs_add_custom__msg').find('.fs_input_wrapper').addClass('error');
			$(this).closest('.fs_add_custom__msg').find('.form-control').focus();
			toastr.error('Please enter your message.' , 'Error');
			return false; 
		}
	});
	
	//duplicate campaign
	$(document).on('click' , 'a.duplicateCamp' , function(){
		$(this).closest('.row').after($(this).closest('.row')[0].outerHTML);
		$(this).closest('.row').find('.addEditMessage').trigger('click'); 
	});
	//remove campaign
	$(document).on('click' , 'a.removeCamp' , function(){
		var cnf = confirm('Are you sure to remove this campaign?');
		if(cnf == true){
			$(this).closest('.row').remove();	
		}
	});
	
	
	
	
	//set delay
	var targetDelay = '';
	$(document).on('click', 'a.setMsgDelay' , function(){
		var delayDtail = $(this).closest('.fs_dropdown_wrapper').find('.delayDtail').val();
		delayDtail = delayDtail.split(',');
		$('#deleyType').selectpicker('val' , delayDtail[0]);
		$('#deleyData').val(delayDtail[1]);
		$.magnificPopup.open({ items: { src: '#fs_set_delay'  }});
		targetDelay = $(this);
	});
	//set trigger 
	var targetTrigger = '';
	$(document).on('click', 'a.setMsgTrigger' , function(){
		$('.panel_heading').attr('aria-expanded' , false);
		$('.panel-collapse').removeClass('in'); 
		$('ul.keywordList').html('');
		$('ul#preBroadcastList li').removeClass('active');
		var triggerDtail = $(this).closest('.fs_dropdown_wrapper').find('.triggerDtail').val();
		if(triggerDtail != ''){
			triggerDtail = JSON.parse(Base64.decode(triggerDtail));
			var triggerType = triggerDtail[0];
			var triggerData = triggerDtail[1];
			
			$('#fs_set_trigger .panel').each(function(){ 
				if($(this).find('.panel_heading').attr('data-value') == triggerType){
					$(this).find('.panel_heading').attr('aria-expanded' , true);
					$(this).find('.panel-collapse').addClass('in'); 
				}
			});
			if(triggerType == 1){
				
			}else if(triggerType == 2){
				var customKey = '';
				var cnt = 0;
				$.each(triggerData.split(',@~^'), function(index, val){
					if(cnt == 0){
						$('.fs_post_wrapper').removeClass('active');
						$('.fs_post_wrapper').each(function(){
							if($(this).attr('data-target') == val){ $(this).addClass('active'); }
						}); 
					}else{
						customKey += (val != '')?'<li>'+val+'<span class="close removeKeyword"></span></li>':'';
					}
					cnt++;
				});
				$('ul#commentkeywordList').html(customKey);
			}else if(triggerType == 3){
				var customKey = '';
				$.each(triggerData.split(',@~^'), function(index, val){
					customKey += (val != '')?'<li>'+val+'<span class="close removeKeyword"></span></li>':'';
				});
				$('ul#messagekeywordList').html(customKey);
			}else if(triggerType == 4){
				$.each(triggerData.split(',@~^'), function(index, val){
					$('ul#preBroadcastList li').each(function(){
						if($(this).attr('data-value') == val){
							$(this).addClass('active');	
						}
					});
				});
			}
		}
		
		if($('#customFieldAlert').length){
			var checkCustom = 0;
			$(this).closest('.row').find('.customField').each(function(){
				if($(this).val() != ''){
					checkCustom = 1;
					return;
				}
			});
			
			if(checkCustom == 1){
				$('#customFieldAlert').removeClass('hide');
			}else{
				$('#customFieldAlert').addClass('hide');
			}	
		}
		
		
		$(".fs_custom_scrollbar").mCustomScrollbar({ scrollInertia:200 });  
		$.magnificPopup.open({ items: { src: '#fs_set_trigger'  }});
		targetTrigger = $(this);
	});
	
	//pre broadcast selection
	$( "ul#preBroadcastList li" ).click(function(){
		$( "ul#preBroadcastList li" ).removeClass('active');
		$(this).addClass('active');
	});
	
	$('.addMyKeywordField').on('click', function(){
		var target = $(this).parent().find('.fs_add_keyword_form');
		if(target.hasClass('hide')){
			target.removeClass('hide');
		}else{
			target.addClass('hide');
		}
		
	});
	$('.add_keyword_btn').on('click', function(){
		var target = $(this).parent().find('.fs_input_wrapper'); 
		var msg = target.find('.keywordText').val().trim();
		if(msg != ''){
			target.removeClass('Error'); 
			var msg_data = '<li>'+msg+' <span class="close removeKeyword"></span></li>';
			$(this).closest('.fs_custom_keyword').find('.keywordList').append(msg_data);
			target.find('.keywordText').val('');
		}else{
			target.addClass('Error');
		}
	});
	
	//remove keyword
	$(document).on('click' , 'span.removeKeyword' , function(){
		var conf = confirm('Are you sure to remove this keyword?');
		if(conf == true){
			$(this).parent().remove();
		}
	});
	
	
	
	//select page post
	$(document).on('click' , '#pagePostList .fs_post_wrapper' , function(){
		$('#pagePostList .fs_post_wrapper').removeClass('active');
		$(this).addClass('active');
		$('#pagePostListKeyword').removeClass('hide');
	});	
	
	// save trigger
	$('a#saveTrigger').click(function(){
		var type = 0;
		var triggerContents = '';
		$('#fs_set_trigger .fs_set_trigger_wrapper').find('.panel').each(function(){
			if($(this).find('.panel_heading').attr('aria-expanded') == 'true'){
				type = $(this).find('.panel_heading').attr('data-value');
				return false;
			}
		});
		if(type != 0){
			if(type == 1){
				
			}else if(type == 2){
				var mKey = '';
				$('ul#commentkeywordList li').each(function(){
					mKey += $(this).text()+',@~^';
				});
				triggerContents = $('.fs_post_wrapper.active').attr('data-target')+',@~^'+mKey;
			}else if(type == 3){
				$('ul#messagekeywordList li').each(function(){
					triggerContents += $(this).text()+',@~^';
				});
			}else if(type == 4){
				$('ul#preBroadcastList li').each(function(){
					if($(this).hasClass('active')){
						triggerContents += $(this).attr('data-value')+',@~^';	
					}
				});
			}
			if(type == 2 && !$('#pagePostList').find('.fs_post_wrapper').hasClass('active')){
				toastr.error('Please selecte any post.' , 'Error'); 
			}else{
				if(triggerContents != '' || type == 1 || type == 2){ 
					var triggerDetail = JSON.stringify(new Array(type,triggerContents));
					targetTrigger.closest('.fs_dropdown_wrapper').find('.triggerDtail').val(Base64.encode(triggerDetail));
					$.magnificPopup.close({ items: { src: '#fs_set_trigger'  }});
					
				}else{
					var msg = (type == 1)?'Please add message comment':((type == 2)?'Please add your keyword.':((type == 3)?'Please add custom keyword.':'Please select any broadcast.'));
					toastr.error(msg , 'Error');
				}
			}
		}else{
			toastr.error('Please select trigger.' , 'Error');
		}
	});
	
	
	//save delay 
	$('#saveDelay').on('click' , function(){
		var deleyType = $('#deleyType').val();
		var deleyData = $('#deleyData').val();
		if(deleyData != ''){ 
			$('#deleyData').parent().removeClass('Error');
			targetDelay.closest('.fs_dropdown_wrapper').find('.delayDtail').val(deleyType+','+deleyData);
			$.magnificPopup.close({ items: { src: '#fs_set_delay'  }});
			$('#deleyType,#deleyData').val('');
		}else{
			$('#deleyData').parent().addClass('Error');
		}
	});
	
	
	//select page for create campaign
	// $(document).on('click' , 'a.selectFbPostToCampaign' , function(){
		// $('#preSetList,#compaignBody,#saveAutomationCampaign').addClass('hide').parent().css('overflow','');
		// $('.fs_loading_wrapper').show();
		// $('#fs_post_list_id .fs_post_wrapper').removeClass('active');
		// $(this).closest('.fs_post_wrapper').addClass('active');
		// if($(this).attr('data-camp') == 1){
			// $.ajax({
				// method : 'post',
				// url : base_url+'ajax/get_campaign_detail',
				// data : {'page_id' : $('#chooseAutomationpage').selectpicker('val'), 'post_id' : $(this).attr('data-target')}
			// }).done(function(resp){
				// $('.fs_loading_wrapper').hide();
				// if(resp != 0){
					// $('#preSetList,#compaignBody,#saveAutomationCampaign').removeClass('hide').parent().css('overflow','hidden');
					// $('#compaignBody').html(resp+campaign_box_html);
				// }else{
					// message('Something went wrong, plase try again','Error');
				// }
			// });
		// }else{
			// $('.fs_loading_wrapper').hide();
			// $('#preSetList,#compaignBody,#saveAutomationCampaign').removeClass('hide').parent().css('overflow','hidden');
			// $('#compaignBody').html(campaignNameField+campaign_box_html);
		// }
		// make_droppable($( "#compaignBody .droppable" ));
	// });
	
	
	
	//remove campaign
	$(document).on('click' , 'a.removeFbPostCampaign' , function(){
		var cnf = confirm('Are you sure to remove this campaign?');
		if(cnf == true){
			$('.fs_loading_wrapper').show();
			var target = $(this);
			$.ajax({
				method : 'post',
				url : base_url+'ajax/remove_camaign',
				data : {'target_campaign' : target.attr('data-target')}
			}).done(function(resp){
				$('.fs_loading_wrapper').hide();
				console.log(resp);
				if(resp == 1){
					target.parent().closest('a.add_camp').attr('data-camp',0).text('Add Campaign');
					target.remove();
				}else{
					toastr.error('Something went wrong, please try again','Error');
				}
			});
		}
	});
	 
	//save automation
	$('#saveAutomationCampaign').on('click' , function(){
		//var totalData = new Array(); 
		$('a.addEditMessage').trigger('click');
		var cnt = 1; 
		var chk_message = 1;
		$('#compaignBody').find('.row').each(function(){ 
			var message = $(this).find('[name="message"]').val();
			if(typeof message != 'undefined'){
				if(Base64.decode(message) == ''){
					$(this).find('.fs_campaign').addClass('message_null');
					$(this).find('a.editCamp').trigger('click');
					$(this).find('name="message"').focus();
					chk_message = 0;
					return false;
				}else{
					$(this).find('.fs_campaign').removeClass('message_null');
				}
			}
		});
		
		if(chk_message == 1){
			var myCampainTitle = $('#postCampainName').val().trim();
			var target = ($('#campaignTarget').length)?$('#campaignTarget').val():'';
			var chkKey = new Date().getTime();
			console.log(chkKey);
			if(myCampainTitle != ''){
				var countForm = $('form.campaign').length;
				$('.fs_loading_wrapper').show();
				$('form.campaign').each(function(){
					var formAllData = new FormData(this);//$(this).serializeArray();
					formAllData.append('chkKey' , chkKey);
					$.ajax({
						type:'POST',
						url : base_url+'ajax/save_campaign_list',
						data:formAllData, 
						cache:false,
						async: false,		
						contentType: false,
						processData: false,
						success : function(resp){
							console.log(resp);
							if(cnt++ == countForm){
								$.ajax({
									type:'POST',
									url : base_url+'ajax/save_campaign',
									data : {'target' : target,'camp_title' : myCampainTitle , 'page_id' : $('#chooseAutomationpage').selectpicker('val'), 'chkKey' : chkKey}
								}).done(function(resp){
									console.log(resp); 
									if(resp == 1){
										window.location.href = base_url;
									}else{
										$('.fs_loading_wrapper').hide();
										toastr.error('Something went wrong, please try again','Error');
									}
								});
							}
						}
					});
					
				});	
			}else{
				$('#postCampainName').focus();
				toastr.error('Please enter campaign title.','Error');
			}
		}else{
			toastr.error('Please enter your message.','Error');
		}
	});
	
	$(document).on('submit' , 'form.campaign' , function(event){
		event.preventDefault();
		console.log(new FormData(this));
	});
	//set general responce
	$('#setGeneralResp').click(function(){
		var msg = $('#genRespMsg').val().trim();
		$('.fs_loading_wrapper').show();
		$.ajax({
			method : 'post',
			url : base_url+'ajax/save_general_responce',
			data : { 'page_id' : $('#chooseAutomationpage').selectpicker('val'), 'message' : msg}
		}).done(function(resp){
			$('.fs_loading_wrapper').hide();
			if(resp == 1){
				toastr.success('General response message saved successfully.','Success');
				$.magnificPopup.close({ items: { src: '#fs_setgeneral_response_popup'  }});
			}else{
				toastr.error('Please enter campaign title.','Error');
			}
		});
		
	});
	
	
	//add dynamic variables
	$(document).on('click' , '.bc_shortcodes' , function(){
		var taregtTextArea = $('.fs_campaign.adding .content').find('textarea');
		taregtTextArea.val(taregtTextArea.val()+' '+ $(this).attr('data-value'));
	});
	
	
	
	
	
});