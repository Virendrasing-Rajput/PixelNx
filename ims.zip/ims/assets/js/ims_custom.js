var base_url;

$(document).ready(function(){
	
	function pre_loader(type){
		var target = $('.fs_loading_wrapper');
		if(type == 'show'){
			target.fadeIn();
		}else{
			target.fadeOut("slow");
		}
	}

	

	function blank_form_field(){
		console.log('as');
		$('.modal-body').find('input.blankField').val('');
		$('.modal-body').find('select.blankField').prop('selected' , false);
	}
	
	$('.openModal').click(function(event){
		event.preventDefault();
		blank_form_field();
		$($(this).attr('href')).modal('show');
	});
	
	base_url = $('input#base_url').val();
	
	
	$('table.loadinData').each(function(){
		var _this = $(this);
		$.ajax({
			method : 'post',
			url : base_url+'search_data/'+_this.attr('target-location'),
			success : function(resp){
				resp = $.parseJSON(resp);
				if(resp['status'] == 1){
					_this.find('tbody').html(resp['respData']);
					$('.fs_pagination').html(resp['pagilink']);
					$('.countTotal').html(resp['countTotal']);
					if(typeof(resp['amountTotal']) != "undefined") {
						$('.amountTotal').html(resp['amountTotal']);
					}
				}else{
					toastr.error('Something went wrong, please try again later.');
				}
			},
			error : function(resp){
				console.log(resp);
				toastr.error('Something went wrong, please try again later.');
			},
		});
	});
	
	//pagination
	//pagination 
    $('.product_pagination ul li a').click(function(event){
            var target = $(this).parent().attr('data-value');
            $('#productSearchForm').append('<input type="hidden" name="formKey" value="'+target+'">');
            $('[name="searchproductBtn"]').trigger('click'); 
    });
	$(document).on('click' , '.fs_pagination ul li a' , function(){
 	       var target = $(this).parent().attr('data-value');
            $('#SearchForm #formKey').val(target);
            $('[name="search_btn"]').trigger('click'); 
    });
	$('#SearchForm').submit(function(e){
		e.preventDefault();
		var _this = $(this);
		var formdata = new FormData(_this[0]);
		$.ajax({
			method : 'post',
			url : base_url+'search_data/'+_this.attr('target-location'),
			data:formdata,
            cache:false,		
			contentType: false,
			processData: false,			
			success : function(resp){
				resp = $.parseJSON(resp);
				if(resp['status'] == 1){
					//_this.find('tbody').html(resp['respData']);
					 _this.find('#formKey').val(0);
					$('#fs_template_table tbody').html(resp['respData']);
					$('.fs_pagination').html(resp['pagilink']);
					$('.countTotal').html(resp['countTotal']);
					if(typeof(resp['amountTotal']) != "undefined") {
						$('.amountTotal').html(resp['amountTotal']);
					}
				}else{
					toastr.error('Something went wrong, please try again later.');
				}
			},
			error : function(resp){
				console.log(resp);
				toastr.error('Something went wrong, please try again later.');
			},
		});
	})
    	
	
	
	$('#saveButton').on('click' , function(){
		var targetForm = $(this).attr('target-form'); 
		var checkResp = checkRequire(targetForm);
		if(checkResp == 0){
			pre_loader('show');
			var dataimg = new FormData($('#'+targetForm)[0]);
			//dataimg.append('img', event.target.files[0]);
			var target = $(this);
			$.ajax({
				method : 'post',
				url : $('#'+targetForm).attr('action'),
				data:dataimg, 
				cache:false,		
				contentType: false,
				processData: false,
				success : function(resp){
					resp = $.parseJSON(resp);
					// pre_loader('hide');
					// console.log(resp);
					if(resp['status'] == 1){
						location.reload();
					}else if(resp['status'] == 0){
						pre_loader('hide');
						toastr.error(resp['error']);
					}else{
						pre_loader('hide');
						toastr.error('Something went wrong, please try again later.');
					}
				},
				error : function(resp){
					pre_loader('hide');
					toastr.error('Something went wrong, please try again later.');
				}, 
			});	
		}
	});
	$('#view_attendance').on('click' , function(){
		var targetForm = $(this).attr('target-form'); 
		var checkResp = checkRequire(targetForm);
		if(checkResp == 0){
		   $('#itemForm').submit();	
		}
	});
	
	
	$(document).on('click' , 'a.EditMyItemCategory' , function(){
		blank_form_field();
		var target = $(this).closest('tr').attr('data-target');
		pre_loader('show');
		$.ajax({
			method : 'post',
			url : base_url+'form_action/get_category',
			data : { 'target' : target},
			success : function(resp){
				pre_loader('hide');
				resp = $.parseJSON(resp);
				if(resp['status'] == 1){
					$('#itemForm input[name="targetCategory"]').val(resp['data']['id']);
					$('#itemForm input[name="name"]').val(resp['data']['name']);
					$('#itemForm input[name="apply_gst"]').val(resp['data']['apply_gst']);
					$('#categoryModal').modal('show');
				}else{
					toastr.error('Something went wrong, please try again later.');
				}
			},
			error : function(resp){
				pre_loader('hide');
				toastr.error('Something went wrong, please try again later.');
			},
		});
		
	});
	
	$(document).on('click' , 'a.EditMyItem' , function(){
		blank_form_field();
		var target = $(this).closest('tr').attr('data-target');
		pre_loader('show');
		$.ajax({
			method : 'post',
			url : base_url+'form_action/get_item',
			data : { 'target' : target},
			success : function(resp){
				pre_loader('hide');
				resp = $.parseJSON(resp);
				if(resp['status'] == 1){
					$('#itemForm input[name="targetItem"]').val(resp['data']['id']);
					$('#itemForm input[name="name"]').val(resp['data']['name']);
					$('#itemForm select[name="category"] option[value="'+resp['data']['category']+'"]').prop('selected' , true);
					$('#itemForm input[name="rate"]').val(resp['data']['rate']);
					$('#itemForm select[name="unit"] option[value="'+resp['data']['unit']+'"]').prop('selected' , true);
					$('#ItemModal').modal('show');
				}else{
					toastr.error('Something went wrong, please try again later.');
				}
			},
			error : function(resp){
				pre_loader('hide');
				toastr.error('Something went wrong, please try again later.');
			},
		});
		
	});
	
	$(document).on('click' , 'a.EditMyCourse' , function(){
		blank_form_field();
		var target = $(this).closest('tr').attr('data-target');
		pre_loader('show');
		$.ajax({
			method : 'post',
			url : base_url+'form_action/get_item_course',
			data : { 'target' : target},
			success : function(resp){
				pre_loader('hide');
				resp = $.parseJSON(resp);
				if(resp['status'] == 1){
					$('#itemForm input[name="targetCourse"]').val(resp['data']['course_id']);
					$('#itemForm input[name="course_name"]').val(resp['data']['course_name']);
					$('#itemForm input[name="course_duration"]').val(resp['data']['course_duration']);
					$('#itemForm select[name="course_duration_type"] option[value="'+resp['data']['course_duration_type']+'"]').prop('selected' , true);
					$('#itemForm input[name="course_fees"]').val(resp['data']['course_fees']);
					$('#itemForm textarea[name="course_description"]').val(resp['data']['course_description']);
					$('#CourseModal').modal('show');
				}else{
					toastr.error('Something went wrong, please try again later.');
				}
			},
			error : function(resp){
				pre_loader('hide');
				toastr.error('Something went wrong, please try again later.');
			},
		});
		
	});

	$(document).on('click' , 'a.EditMyBatch' , function(){
		blank_form_field();
		var target = $(this).closest('tr').attr('data-target');
		pre_loader('show');
		$.ajax({
			method : 'post',
			url : base_url+'form_action/get_item_batch',
			data : { 'target' : target},
			success : function(resp){
				pre_loader('hide');
				resp = $.parseJSON(resp);
				if(resp['status'] == 1){
					$('#itemForm input[name="targetBatch"]').val(resp['data']['batch_id']);
					$('#itemForm input[name="batch_name"]').val(resp['data']['batch_name']);
					$('#itemForm select[name="batch_course"] option[value="'+resp['data']['batch_course']+'"]').prop('selected' , true);
					$('#itemForm input[name="batch_fees"]').val(resp['data']['batch_fees']);
					$('#itemForm input[name="batch_duration"]').val(resp['data']['batch_duration']);
					$('#itemForm select[name="batch_duration_type"] option[value="'+resp['data']['batch_duration_type']+'"]').prop('selected' , true);
					$('#itemForm input[name="batch_start_date"]').val(resp['data']['batch_start_date']);
					$('#itemForm input[name="batch_time"]').val(resp['data']['batch_time']);
					$('#itemForm select[name="batch_teacher"] option[value="'+resp['data']['batch_teacher']+'"]').prop('selected' , true);
					$('#itemForm select[name="batch_status"] option[value="'+resp['data']['batch_status']+'"]').prop('selected' , true);
					$('#itemForm textarea[name="batch_description"]').val(resp['data']['batch_description']);
					$('#BatchModal').modal('show');
				}else{
					toastr.error('Something went wrong, please try again later.');
				}
			},
			error : function(resp){
				pre_loader('hide');
				toastr.error('Something went wrong, please try again later.');
			},
		});
		
	});

	$(document).on('click' , 'a.EditMyUser' , function(){
		blank_form_field();
		var target = $(this).closest('tr').attr('data-target');
		pre_loader('show');
		$.ajax({
			method : 'post',
			url : base_url+'form_action/get_item_user',
			data : { 'target' : target},
			success : function(resp){
				pre_loader('hide');
				resp = $.parseJSON(resp);
				if(resp['status'] == 1){
					$('#itemForm input[name="targetUser"]').val(resp['data']['user_id']);
					$('#itemForm input[name="tech_name"]').val(resp['data']['user_full_name']);
					$('#itemForm input[name="tech_email"]').val(resp['data']['user_email']);
					$('#itemForm input[name="tech_mobile"]').val(resp['data']['mobile']);
					$('#itemForm input[name="tech_doj"]').val(resp['data']['doj']);
					$('#itemForm select[name="tech_gender"] option[value="'+resp['data']['gender']+'"]').prop('selected' , true);
					$('#itemForm select[name="user_role"] option[value="'+resp['data']['user_role']+'"]').prop('selected' , true);
					//$('#itemForm input[name="tech_qualification"]').val(resp['data']['qualification']);
					$('#itemForm select[name="tech_qualification"] option[value="'+resp['data']['qualification']+'"]').prop('selected' , true);
					$('#itemForm input[name="tech_exp"]').val(resp['data']['experience']);
					$('#itemForm input[name="tech_salary"]').val(resp['data']['user_salary']);
					$('#itemForm textarea[name="tech_address"]').val(resp['data']['address']);
					$('#UserModal').modal('show');
				}else{
					toastr.error('Something went wrong, please try again later.');
				}
			},
			error : function(resp){
				pre_loader('hide');
				toastr.error('Something went wrong, please try again later.');
			},
		});
		
	});
	
	$(document).on('click' , 'a.EditMyEnquiry' , function(){
		blank_form_field();
		var target = $(this).closest('tr').attr('data-target');
		pre_loader('show');
		$.ajax({
			method : 'post',
			url : base_url+'form_action/get_item_enquiry',
			data : { 'target' : target},
			success : function(resp){
				pre_loader('hide');
				resp = $.parseJSON(resp);
				if(resp['status'] == 1){
					$('#itemForm input[name="targetEnquiry"]').val(resp['data']['enq_id']);
					$('#itemForm input[name="enq_name"]').val(resp['data']['enq_name']);
					$('#itemForm input[name="enq_mobile"]').val(resp['data']['enq_mobile']);
					$('#itemForm input[name="enq_email"]').val(resp['data']['enq_email']);
					$('#itemForm select[name="enq_course"] option[value="'+resp['data']['enq_course']+'"]').prop('selected' , true);
					$('#itemForm select[name="enq_college"] option[value="'+resp['data']['enq_college']+'"]').prop('selected' , true);
					$('#itemForm select[name="enq_education"] option[value="'+resp['data']['enq_education']+'"]').prop('selected' , true);
					$('#itemForm input[name="enq_followdate"]').val(resp['data']['enq_followdate']);
					$('#itemForm textarea[name="enq_remark"]').val(resp['data']['enq_remark']);
					$('#EnquiryModal').modal('show');
				}else{
					toastr.error('Something went wrong, please try again later.');
				}
			},
			error : function(resp){
				pre_loader('hide');
				toastr.error('Something went wrong, please try again later.');
			},
		});
		
	});

	$('#check-all').click(function(event) {   
    if(this.checked) {
        $(':checkbox').each(function() {
            this.checked = true;                        
        });
    }else{
    	$(':checkbox').each(function() {
            this.checked = false;                        
        });
    }
   });
   
   
   $(document).on('click' , 'a.EditMyExpenses' , function(){
		blank_form_field();
		var target = $(this).closest('tr').attr('data-target');
		pre_loader('show');
		$.ajax({
			method : 'post',
			url : base_url+'form_action/get_item_expanses',
			data : { 'target' : target},
			success : function(resp){
				pre_loader('hide');
				resp = $.parseJSON(resp);
				if(resp['status'] == 1){
					$('#itemForm input[name="targetExpanses"]').val(resp['data']['exp_id']);
					$('#itemForm input[name="exp_name"]').val(resp['data']['exp_name']);
					$('#itemForm select[name="exp_type"] option[value="'+resp['data']['exp_type']+'"]').prop('selected' , true);
					$('#itemForm input[name="exp_amount"]').val(resp['data']['exp_amount']);
					$('#itemForm select[name="exp_method"] option[value="'+resp['data']['exp_method']+'"]').prop('selected' , true);
					$('#itemForm textarea[name="exp_note"]').val(resp['data']['exp_note']);
					$('#itemForm input[name="exp_date"]').val(resp['data']['exp_date']);
					
					$('#ExpensesModal').modal('show');
				}else{
					toastr.error('Something went wrong, please try again later.');
				}
			},
			error : function(resp){
				pre_loader('hide');
				toastr.error('Something went wrong, please try again later.');
			},
		});
		
	});

   $(document).on('click' , 'a.EditMyCollege' , function(){
		blank_form_field();
		var target = $(this).closest('tr').attr('data-target');
		pre_loader('show');
		$.ajax({
			method : 'post',
			url : base_url+'form_action/get_item_college',
			data : { 'target' : target},
			success : function(resp){
				pre_loader('hide');
				resp = $.parseJSON(resp);
				if(resp['status'] == 1){
					$('#itemForm input[name="targetCollege"]').val(resp['data']['clg_id']);
					$('#itemForm input[name="clg_name"]').val(resp['data']['clg_name']);
					$('#CollegeModal').modal('show');
				}else{
					toastr.error('Something went wrong, please try again later.');
				}
			},
			error : function(resp){
				pre_loader('hide');
				toastr.error('Something went wrong, please try again later.');
			},
		});
		
	});


   $(document).on('click' , 'a.EditMyEducation' , function(){
		blank_form_field();
		var target = $(this).closest('tr').attr('data-target');
		pre_loader('show');
		$.ajax({
			method : 'post',
			url : base_url+'form_action/get_item_education',
			data : { 'target' : target},
			success : function(resp){
				pre_loader('hide');
				resp = $.parseJSON(resp);
				if(resp['status'] == 1){
					$('#itemForm input[name="targetEducation"]').val(resp['data']['edu_id']);
					$('#itemForm input[name="edu_name"]').val(resp['data']['edu_name']);
					$('#EducationModal').modal('show');
				}else{
					toastr.error('Something went wrong, please try again later.');
				}
			},
			error : function(resp){
				pre_loader('hide');
				toastr.error('Something went wrong, please try again later.');
			},
		});
		
	});

   $(document).on('click' , 'a.EditMySalary' , function(){
		blank_form_field();
		var target = $(this).closest('tr').attr('data-target');
		pre_loader('show');
		$.ajax({
			method : 'post',
			url : base_url+'form_action/get_item_salary',
			data : { 'target' : target},
			success : function(resp){
				pre_loader('hide');
				resp = $.parseJSON(resp);
				if(resp['status'] == 1){
					$('#itemForm input[name="targetSalary"]').val(resp['data']['sal_id']);
					$('#itemForm input[name="sal_amount"]').val(resp['data']['sal_amount']);
					$('#itemForm select[name="sal_uid"] option[value="'+resp['data']['sal_uid']+'"]').prop('selected' , true);
					$('#sal_uid').modal('show');
					$('#SalaryModal').modal('show');
				}else{
					toastr.error('Something went wrong, please try again later.');
				}
			},
			error : function(resp){
				pre_loader('hide');
				toastr.error('Something went wrong, please try again later.');
			},
		});
		
	});

});

/******************* Get Batch  STARTS **********************/
function getBatch($this){ 
    var courseId = $($this).val();
    if( courseId != '') {
        var allData = {};
        allData [ 'courseId' ] = courseId;
        $.post(base_url+"search_data/getBatch",allData,function(data, status) {
			$('select[name="stud_batch"]').html(data);
		});
		/*$.post(base_url+"search_data/getFees",allData,function(data, status) {
			$('input[name="stud_fees"]').val(data);
		});*/
    }
}
function getFees($this){
var fees = $($this).find('option:selected').attr('data-fees'); 
	if(fees!=''){
		$('input[name="stud_fees"]').val(fees);
	}
}

function getSalary($this){
var sal_amount = $($this).find('option:selected').attr('data-salary'); 
	if(sal_amount!=''){
		$('input[name="sal_amount"]').val(sal_amount);
	}
}

 /******************* Get Batch  STARTS **********************/
   
/******************* Show Hide Followdate STARTS **********************/
function showhidefollowdate($this){ 
    var follow_status = $($this).val();
    if(follow_status==0){
    	$('#showhidefollowdate').removeClass('hide');
    }else if(follow_status==2){
       $('#showhidefollowdate').val('');
       $('#showhidefollowdate').addClass('hide');
    }
}

 /******************* Show Hide Followdate End **********************/   