
/*******start admin custom ********/ 


function add_new_user(element , target){
	var chk = checkRequire(target);
	if(chk == 0){
		var fName = $('input[name="fName"]').val().trim();
		var uEmail = $('input[name="uEmail"]').val().trim();
		var pass = $('#password').val();
		var type = ($('input[name="userType"]').length)?$('input[name="userType"]:checked').val():'';
		if(pass.length >= 8){
			$('.fs_loading_wrapper').show();
			$.ajax({
				method : 'post',
				url : base_url+'ajax/add_new_user',
				data : {'fName' : fName , 'uEmail' : uEmail , 'pass' : pass , 'type' : type}
			}).done(function(resp){
				if(resp == 1){
					location.reload();
				}else if(resp == 2){
					$('.fs_loading_wrapper').hide();
					toastr.error('Email already exist.','Error');
				}else{
					$('.fs_loading_wrapper').hide();
					toastr.error('Something went wrong, please try again later.','Error');
				}
			});
		}else{
			toastr.error('Password should be minimum 8 characters.','Error');
		}
	}
}


var target_tr = '';
function edit_user(element , target){
	$("#userStatus option").prop("selected" , false);
	target_tr = $(element).closest('tr'); 
	$('.fs_loading_wrapper').show();
	$.ajax({
		method : 'post',
		url : base_url+'ajax/get_user_data',
		data : {'target' : target}
	}).done(function(resp){
		if(resp != 0){
			var resp = resp.split(',!:!@#');
			if(resp[0] == 1){
				resp = JSON.parse(resp[1]);
				$('#isuAgency').prop('checked' , false);
				$('input[name="userTypeU"]').prop('checked' , false);
				$('#userName').val(resp['user_full_name']);
				$("#userStatus option[value='"+resp['status']+"']").prop("selected","true");
				$(".selectpicker").selectpicker('refresh');
				if(resp['is_agency'] == 1){ $('#isuAgency').prop('checked' , true); }
				$('input[name="userTypeU"][value="'+resp['user_type']+'"]').prop("checked","true");
				$('#uId').val(target);
				$.magnificPopup.open({ items: { src: '#fs_edit_user'  }});
				$('.fs_loading_wrapper').hide();
			}else{
				$('.fs_loading_wrapper').hide();
				toastr.error('Something went wrong, please try again later.','Error');
			}
		}else{
			$('.fs_loading_wrapper').hide();
			toastr.error('Something went wrong, please try again later.','Error');
		}
	});
	
	
	
}

function update_user_detail(){
	$('.fs_loading_wrapper').show();
	var is_agency = ($('#isuAgency').is(':checked'))?1:0;
	var type = $('input[name="userTypeU"]:checked').val();
	type = (typeof type != 'undefined')?type:0; 
	$.ajax({
		method : 'post',
		url : base_url+'ajax/update_user_detail',
		data : {'target' : $('#uId').val() , 'status' : $("#userStatus").val(), 'type' :  type, 'is_agency' : is_agency}
	}).done(function(resp){
		$('.fs_loading_wrapper').hide();
		if(resp == 1){
			target_tr.find('.status').text(($("#userStatus").val() == 1)?'Active':'In-Active');
			var type_text = (type == 1)?'Main':((type == 2)?'Pro':'None');
			type_text += (is_agency == 1)?', Agency':'';
			target_tr.find('.type').text(type_text);
			toastr.success('User detail updated successfully.','Success');
			$.magnificPopup.close({ items: { src: '#fs_edit_user'  }});
		}else{
			toastr.error('Something went wrong, please try again later.','Error');
		}
	});
}


function remove_user(element , target){
	var cnf = confirm('Are you sure to remove this user?');
	if(cnf == true){
		$('.fs_loading_wrapper').show();
		$.ajax({
			method : 'post',
			url : base_url+'ajax/remove_user',
			data : {'target' : target}
		}).done(function(resp){
			console.log(resp);
			if(resp == 1){
				$(element).closest('tr').remove();
				toastr.success('User detail updated successfully.','Success');
			}else{
				toastr.error('Something went wrong, please try again later.','Error');
			}
			$('.fs_loading_wrapper').hide();
		});
	}
}





