/*
Copyright (c) 2017 Lab
------------------------------------------------------------------
[Master Javascript]

Project:	IMS

-------------------------------------------------------------------*/
var base_url = $('#base_url').val();
(function ($) {
	/*"use strict";*/
	var IMS = {
		initialised: false,
		version: 1.0,
		mobile: false,
		init: function () {

			if(!this.initialised) {
				this.initialised = true;
			} else {
				return;
			}

			/*-------------- IMS Functions Calling -------------------------------------------------------------------*/
			this.Nav();
			this.fs_Scrollbar();
			this.popup();			
		},
		
		/*-------------- IMS Functions definition -----------------------------------------------*/
		Nav: function () {
			$('.fs_sidebar_toggle .toggle_btn').on('click', function(){
				$('body').addClass('sidebar_open');
			});
			$('.fs_sidebar_closer').on('click', function(){
				$('body').removeClass('sidebar_open');
			});
		},
		Preloader: function () {
			$("#fs_status").fadeOut();
			$("#fs_preloader").delay(350).fadeOut("slow");
		},
		fs_Scrollbar: function () {
			if($(".fs_custom_scrollbar").length){
				$(".fs_custom_scrollbar").mCustomScrollbar({
					scrollInertia:200,
				});
			}
			if($(".fs_custom_scrollbar_x").length){
				$(".fs_custom_scrollbar_x").mCustomScrollbar({
					scrollInertia:200,
					axis:"x"
				});
			}
			
		},
		SelectPicker: function(){
			if($('.selectpicker').length){	
				$('.selectpicker').selectpicker();
			}
		},
		DatePicker: function(){
			if($('.datepicker').length){	
				$('.datepicker').datepicker();//$( ".datepicker" ).datepicker( "option", "dateFormat",'yy-mm-dd');
			}
			if($('.timepicker').length){	
				//$('.timepicker').datetimepicker();
				$('.timepicker').datetimepicker({
                    format: 'LT',
                });
            }    
		},
		popup: function(){
			if($('.fs_popup_link').length){
				$('.fs_popup_link').magnificPopup({
					type: 'inline',
					preloader: true,
					callbacks: {
						open: function() {
							$(".fs_custom_scrollbar_x").mCustomScrollbar({
							   scrollInertia:200,
							   axis:"x"
							});
						},
						close: function() {
						  // Will fire when popup is closed
						}
						// e.t.c.
					}
				});
			}
		}
	};

	

	// Load Event
	$(window).on('load', function() {
		$(".fs_loading_wrapper").delay(350).fadeOut("slow");
		/* Trigger side menu scrollbar */
		var body_h = window.innerHeight;
		$('body').css('height',body_h);
		IMS.Preloader();
		IMS.SelectPicker();
		IMS.DatePicker();
		// add class on body
		setTimeout(function(){
			$('body').addClass('fs_site_loaded');
		},1000);
		
	});

	// Scroll Event
	$(window).on('resize', function () {
		var body_h = window.innerHeight;
		$('body').css('height',body_h);
	});
	
	// Scroll Event
	$(window).on('scroll', function () {
	
	});
	
	// ready function
	$(document).ready(function() {
		IMS.init();
		
		$('[data-toggle="tooltip"]').tooltip(); 
		
		 
		//toastr initialize
		toastr.options = {
		  "closeButton": true,
		  "debug": false,
		  "newestOnTop": false,
		  "progressBar": false,
		  "positionClass": "toast-top-right",
		  "preventDuplicates": true,
		  "onclick": null,
		  "showDuration": "300",
		  "hideDuration": "1000",
		  "timeOut": "5000",
		  "extendedTimeOut": "1000",
		  "showEasing": "swing",
		  "hideEasing": "linear",
		  "showMethod": "fadeIn",
		  "hideMethod": "fadeOut"
		}
		
		
	});
	
	
	$('.return_number').on('keypress',function(evt){
		var charCode = (evt.which) ? evt.which : event.keyCode;
		if (charCode > 31 && (charCode < 48 || charCode > 57)){
			return false;
		}else{
			return true;
		}
	});
	
})(jQuery);


