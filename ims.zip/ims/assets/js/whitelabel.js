$(document).ready(function(){
	
	//site color setting
	$(".example_complex").asColorPicker();//initialize color-picker
	$('.example_complex').on('asColorPicker::change', function (e) {
		if($(this).attr('name') == 'site_primary_color'){
			$('.fs_logo_wrapper , .btn').css('background-color' , $(this).asColorPicker('val'));
			$('.fs_nav_wrapper > ul > li.active > a').css('color' , $(this).asColorPicker('val'));
		}else{
			$('.fs_sidebar_wrapper').css('background-color' , $(this).asColorPicker('val'));
		}
		
	  // on value change 
	});
	
	
	$('[name="domainType"]').on('click' , function(){
		$('#domain_form').removeClass('hide');
		if($(this).val() == 1){
			var placeHolder = 'Sub-domain Name';
		}else{
			var placeHolder = 'Domain Name (without www or http/https)';
		}
		$('#domain_name').attr('placeholder','Enter '+placeHolder);
		$('#domain_name').parent().find('span').html(placeHolder);
	});
});

function remove_my_domain(target){
	var cnf = confirm('Are you sure to disconnect this domain?'); 
	if(cnf == true){
		$(".fs_loading_wrapper").show();
		$.ajax({
			method : 'post',
			url : $('#base_url').val()+'form_action/remove_domain',
			data : {'target' : target}
		}).done(function(resp){
			if(resp == 1){
				location.reload();
			}else if(resp == 2){
				$(".fs_loading_wrapper").hide();
				toastr.error('We are not able to connect. Please, contact support.','Error');
			}else{
				$(".fs_loading_wrapper").hide();
				toastr.error('Something went wrong, plase try again.','Error');
			}
		});
	}
}

function add_domain(){
	var name = $('#domain_name').val().trim();
	var type = $('[name="domainType"]:checked').val();
	var domain_rex = /^[a-zA-Z0-9][a-zA-Z0-9-]{1,61}[a-zA-Z0-9](?:\.[a-zA-Z]{2,})+$/;
	var sub_domain_rex = /^[a-zA-Z0-9\\-]+$/;
	var chk = 0;
	if(type == 1 && sub_domain_rex.test(name) == true){
		chk = 1;
	}else if(type == 2 && domain_rex.test(name) == true){
		chk = 1;
	} 
	
	if(chk == 1){
		if(name != ''){
			$(".fs_loading_wrapper").show();
			$.ajax({
				method : 'post',
				url : $('#base_url').val()+'form_action/add_domain',
				data : {'name' : name}
			}).done(function(resp){
				//console.log(resp);
				if(resp == 1){ 
					location.reload();
				}else if(resp == 2){
					$(".fs_loading_wrapper").hide();
					toastr.error('We are not able to connect. Please, contact support.','Error');
				}else if(resp == 3){
					$(".fs_loading_wrapper").hide();
					toastr.error('Domain already taken. Please try with another domain. ','Error');
				}else{
					$(".fs_loading_wrapper").hide();
					toastr.error('Something went wrong, plase try again.','Error');
				}
			});
		}else{
			$('#domain_name').focus();
			toastr.error('Please enter domain name.','Error');
		}
	}else{
		$('#domain_name').focus();
		var message = (type == 1)?'Sub-domain':'domain';
		toastr.error(message+' name should be valid.','Error');
	}
}