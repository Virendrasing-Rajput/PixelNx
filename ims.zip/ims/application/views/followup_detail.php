<div class="fs_content_wrapper fs_analytics_wrapper">
	<div class="fs_page_header">
		<div class="row">
			<div class="col-md-6 margin-bottom-20">
				<div class="fs_page_title margin-top-10">
					<h3>Follow Up  <?php echo ucfirst($enq_detail['enq_name']); ?></h3>
				</div>
			</div>
			
			<?php if($enq_detail['enq_status']==0){
			echo '<div class="col-md-6 text-right">
				<a href="#BatchModal" class="btn openModal">Add FollowUp</a>
			</div>'; } ?>
		</div>
	</div>
	
	<div class="row">
		<div class="col-md-12">
			<div class="fs_analytics_table admin" id="ManAgency">
				<table id="fs_template_table" class="table table-hover dataTable table-striped width-full loadinData" target-location="followup_data/<?php echo $enq_id; ?>">
					<thead>
						<tr>
						<th>#</th>
							
							<th>Date</th>
							<th>Next FollowDate</th>
							<th>Mode </th>
							<th>Feedback </th>
							<th>Follow By </th>
							<th>Status</th>
							<th>Note</th>
						</tr> 
					</thead>
					<tbody>
						<tr>
							<td colspan="6" align="center">Loading...</td>
						</tr> 
					</tbody>
				</table>
			</div>
		</div>
	</div> 
</div>


<div id="BatchModal" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Add FollowUp</h4>
			</div>
			<div class="modal-body form-horizontal">
				<form method="post" action="<?php echo base_url('form_action/manage_followup'); ?>" id="itemForm">
					<input type="hidden" name="targetFollow">
					<input type="hidden" name="follow_enqid" value="<?php echo $enq_id; ?>" >
					<div class="form-group ">
						<label class="control-label col-sm-3" for="email">Mode:</label>
						<div class="col-sm-9">
							<select class="form-control require blankField" name="follow_mode">
								<option value="call">Call</option>
								<option value="email">Email</option>
								<option value="email">Sms</option>
							</select>
						</div>
					</div>

					<div class="form-group ">
						<label class="control-label col-sm-3" for="email">Feedback:</label>
						<div class="col-sm-9">
							<select class="form-control require blankField" name="follow_feedback">
								<option value="positive">Positive</option>
								<option value="negative">Negative</option>
							</select>
						</div>
					</div>

					
                    
                    
                    <div class="form-group ">
						<label class="control-label col-sm-3" for="email">Status:</label>
						<div class="col-sm-9">
							<select class="form-control require blankField" name="follow_status" onchange="showhidefollowdate(this)">
								<option value="0">Continue</option>
								<option value="2">Blocked</option>
							</select>
						</div>
					</div>

					<div class="form-group" id="showhidefollowdate">
						<label class="control-label col-sm-3">Next Follow Date:</label>
						<div class="col-sm-9">
						  <input type="text" class="form-control blankField  datepicker" name="follow_next_date" placeholder="Next Follow Date">
						</div>
					</div>

					<div class="form-group ">
						<label class="control-label col-sm-3" for="email"> Note:</label>
						<div class="col-sm-9">
							<textarea  class="form-control blankField " name="follow_note" placeholder="Note"></textarea>
						</div>
					</div>
				</form>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" id="saveButton" target-form="itemForm">Save</button>
			</div>
		</div>
	</div>
</div>