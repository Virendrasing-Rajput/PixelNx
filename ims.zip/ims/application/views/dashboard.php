<div class="fs_content_wrapper fs_dashboard_wrapper">
	<div class="fs_page_header">
		<div class="row">
			<div class="col-md-12 margin-bottom-20">
				<div class="fs_page_title margin-top-10">
					<h3>Dashboard</h3>
				</div>
			</div>
		</div>
	</div> 
	<?php
	$doctor_count = 0;// $this->my_model->aggregate_data('doctor' , 'id' , 'COUNT' , array('status' => 1));
	$patient_count = 0;//$this->my_model->aggregate_data('patient' , 'patient_id' , 'COUNT' , '');
	$pathology_test_count = 0;//$this->my_model->aggregate_data('path_test' , 'p_test_id' , 'COUNT' , array('p_test_status'=>1));
	$assets_count = 0;//$this->my_model->aggregate_data('asset' , 'asset_id' , 'COUNT' , array('asset_status'=>1));
	/*
	
	?>
	<div class="row">
		<div class="col-md-3 margin-bottom-40">
			<div class="fs_analytic_box users">
				<div class="icon" style="color: #b0b4ab;">
					<i class="fa fa-user-md"></i>
				</div>
				<div class="detail">
					<label>Doctors</label>
					<h1><?php echo $doctor_count; ?></h1>
				</div>
			</div>
		</div>
		<div class="col-md-3 margin-bottom-40">
			<div class="fs_analytic_box in_users">
				<div class="icon">
					<i class="fa fa-wheelchair-alt"></i>
				</div>
				<div class="detail">
					<label>Patient</label>
					<h1><?php echo $patient_count; ?></h1>
				</div>
			</div>
		</div>
		<div class="col-md-3 margin-bottom-40">
			<div class="fs_analytic_box tt_broadcast">
				<div class="icon">
					<i class="fa fa-plus-square"></i>
				</div>
				<div class="detail">
					<label>Pathology Tests</label>
					<h1><?php echo $pathology_test_count; ?></h1>
				</div>
			</div>
		</div>
		<div class="col-md-3 margin-bottom-40">
			<div class="fs_analytic_box users">
				<div class="icon">
					<i class="fa fa-medkit"></i>
				</div>
				<div class="detail">
					<label>Assets</label>
					<h1><?php echo $assets_count; ?></h1>
				</div>
			</div>
		</div>	
	</div>

	<div class="row">
		<div class="col-md-12">
			<?php if(isset($patientDetail) && !empty($patientDetail)){?>
				<div class="fs_analytics_table admin dash_table" id="ManAgency">
					<table id="fs_template_table" class="table table-hover dataTable table-striped width-full">
						<thead>
							<tr>
								<th>#</th>
								<th class="title">Patient Name</th>
								<th class="action">Patient Contact</th>
								<th class="action">Referred by</th>
								<th class="action">Advance Amount</th>
								<th class="action">Remaining Amount</th>
								<th class="action">Doctor Commission</th>
								<th class="action">Action</th>
							</tr> 
						</thead>
						<tbody>
							<?php
							$cnt = 1;
							foreach($patientDetail as $patient){
								$contact = ($patient['p_contact'] != 0)?$patient['p_contact']:'Not available';
								$doc_info = $this->my_model->select_data('name,commission','doctor',array('id'=>$patient['d_id']));
								$path_test_info = $this->my_model->select_data('p_test_rate,p_test_discount','path_test',array('p_test_id'=>$patient['p_path_test']));
								if($path_test_info[0]['p_test_discount']!=''){
                                	$discount_amount = ($path_test_info[0]['p_test_rate'])*($path_test_info[0]['p_test_discount']/100);
                                	$total_amount = $path_test_info[0]['p_test_rate'] - $discount_amount;
								}else{
									$total_amount = $path_test_info[0]['p_test_rate'];
								}
								$remaining_amount = $total_amount - $patient['p_advance_amount'];
								$commission = ($total_amount)*($doc_info[0]['commission']/100);
								
								echo '<tr>
										<td>'.$cnt++.'</td>
										<td>'.$patient['p_name'].'</td>
										<td>'.$contact.'</td>
										<td>'.$doc_info[0]['name'].'</td>
										<td>'.$patient['p_advance_amount'].'</td>
										<td>'.$remaining_amount.'</td>
										<td>'.$commission.'</td>
										<td>
											<a title="Edit"><i class="fa fa-edit"></i></a> 
											<a title="View Detail"><i class="fa fa-eye"></i></a>
										</td>
									</tr>';
							}
							?>
						</tbody>
					</table>
				</div>
				<div class="text-center">
					<a href="<?php echo base_url('patients'); ?>" class="btn">View More</a>
				</div>
			<?php
			}else{
				echo '<div class="fs_noPost">
						<img src="'.base_url('assets/images/icon/unhappy.svg').'" alt="" class="mCS_img_loaded">
						<p>Oops...there are no patient available.</p>
					</div>	';
			}
			?>
		</div>
	</div>
	 */ ?>
	
</div>