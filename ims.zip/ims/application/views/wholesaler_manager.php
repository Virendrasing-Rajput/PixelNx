<div class="fs_content_wrapper fs_analytics_wrapper">
	<div class="fs_page_header">
		<div class="row">
			<div class="col-md-6 margin-bottom-20">
				<div class="fs_page_title margin-top-10">
					<h3>Wholesaler(<?php echo (isset($itemCount))?$itemCount:'0'; ?>)</h3>
				</div>
			</div>
			<div class="col-md-6 text-right">
				<a href="#ItemModal" class="btn openModal">Add Wholesaler</a>
			</div>
		</div>
	</div>
	
	<div class="row">
		<div class="col-md-12">
			<div class="fs_analytics_table admin" id="ManAgency">
				<table id="fs_template_table" class="table table-hover dataTable table-striped width-full loadinData" target-location="wholesaler_data">
					<thead>
						<tr>
							<th>#</th>
							<th>Owner Name</th>
							<th>Shop Name</th>
							<th>Contact No.</th>
							<th>Address</th>
							<th>Action</th>
						</tr> 
					</thead>
					<tbody>
						<tr>
							<td colspan="6" align="center">Loading...</td>
						</tr> 
					</tbody>
				</table>
			</div>
		</div>
	</div> 
</div>


<div id="ItemModal" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Manage Wholesaler</h4>
			</div>
			<div class="modal-body form-horizontal">
				<form method="post" action="<?php echo base_url('form_action/manage_wholesaler'); ?>" id="itemForm">
					<input type="hidden" name="targetWholesaler">
					<div class="form-group">
						<label class="control-label col-sm-3">Owner Name:</label>
						<div class="col-sm-9">
						  <input type="email" class="form-control blankField require" name="name" placeholder="Owner Name">
						</div>
					</div>
					<div class="form-group">
						<label class="control-label col-sm-3">Shop Name:</label>
						<div class="col-sm-9">
						  <input type="email" class="form-control blankField require" name="shop_name" placeholder="Shop Name">
						</div>
					</div>
					<div class="form-group">
						<label class="control-label col-sm-3">Contact No.:</label>
						<div class="col-sm-9">
						  <input type="email" class="form-control blankField require" data-valid="mobile" data-error="Contact no. should be valid." name="contact" placeholder="Wholesaler Contact No.">
						</div>
					</div>
					<div class="form-group ">
						<label class="control-label col-sm-3" for="email">Address:</label>
						<div class="col-sm-9">
							<textarea type="email" class="form-control blankField require" name="address" placeholder="Shop Adderess"></textarea>
						</div>
					</div>
				</form>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" id="saveButton" target-form="itemForm">Save</button>
			</div>
		</div>
	</div>
</div>