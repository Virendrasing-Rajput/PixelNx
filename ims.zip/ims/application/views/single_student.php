<div class="fs_content_wrapper fs_analytics_wrapper">
	<div class="fs_page_header">
		<div class="row">
			<div class="col-md-6 margin-bottom-20">
				<div class="fs_page_title margin-top-10">
					<h3><?php echo ucfirst($user_detail['user_full_name']); ?></h3>
				</div>
			</div>
			
		</div>
	</div>
	<style type="text/css">
		.btn-file {
            position: relative;
            overflow: hidden;
		}
		.btn-file input[type=file] {
		    position: absolute;
		    top: 0;
		    right: 0;
		    min-width: 100%;
		    min-height: 100%;
		    font-size: 100px;
		    text-align: right;
		    filter: alpha(opacity=0);
		    opacity: 0;
		    outline: none;
		    background: white;
		    cursor: inherit;
		    display: block;
		}
	</style>
	<div class="row">
		<div class="col-md-12">
			<div id="exTab1" >	
			  <ul  class="nav nav-pills">
				<li ><a  href="#1a" data-toggle="tab">Basic Details</a></li>
				<li><a href="#2a" data-toggle="tab">Course</a></li>
				
				<li class="active"><a href="#4a" data-toggle="tab">Fees Section</a></li>
			   </ul>

			  <div class="tab-content clearfix">
			         <!-- Basic Detail Tab Start  -->
					 <div class="tab-pane " id="1a">
					 <?php
                     $imgsrc=base_url().'webimage/defaultuser.jpg"';
			          echo'<div class="col-md-3">
			          	<img class="img-responsive" src="'.$imgsrc.'" alt="">
			          	<span class="btn btn-default btn-file">
						    Browse <input type="file">
						</span>
			          </div>';

			          ?>
			          <div class="col-md-9">    
						  <table class="table table-hover">
						    <tbody>
						     <tr>
							    <th>Name:</th>
							    <td><?php echo ucfirst($user_detail['user_full_name']); ?></td>
							  </tr>
							  <tr>
							    <th>Mobile:</th>
							    <td><?php echo $user_detail['mobile']; ?></td>
							  </tr>
							  <tr>
							    <th>Email:</th>
							    <td><?php echo $user_detail['user_email']; ?></td>
							  </tr>
							  <tr>
							    <th>Address:</th>
							    <td><?php echo $user_detail['address']; ?></td>
							  </tr>
						    </tbody>
						  </table>
			          </div>
					 </div>
                      <!-- Basic Detail Tab End  -->
					<div class="tab-pane" id="2a">
						  <table class="table">
						    <thead>
						      <tr>
						         <th>#</th>
						        <th>Course Name</th>
						        <th>Batch Name</th>
						        <th>Fees</th>
						        <th>Discount</th>
						        <!--<th>Change</th>-->
						      </tr>
						    </thead>
						    <tbody>
						    <?php if(!empty($user_course_detail)){$count=0;
						    foreach ($user_course_detail as $single_course) {$count++;
						    	$course_name=$single_course['course_name'];
						    	$batch_name=$single_course['batch_name'];
						    	$course_fees=$single_course['stud_fess'];
						    	$discount=$single_course['stud_disc'];
						    	echo '<tr>
						         <td>'.$count.'</td>
						        <td>'.$course_name.'</td>
						        <td>'.$batch_name.'</td>
						        <td>'.$course_fees.'</td>
						        <td>'.$discount.'</td>
						         
						      </tr>';	
						    	}	
						     } ?>    
						    </tbody>
						  </table>
					</div>

			        
                   
				   <div class="tab-pane active" id="4a">
			       <a href="#FeesModal" class="btn openModal">Add Fees</a>
			         <?php if(!empty($user_course_detail)){$count=0;
				
					} ?>  
			 
                     <table class="table table-hover">
						<thead>
						  <tr>
							<th>Date</th>
							<th>Description</th>
							<th>Deposit/Discount</th>
							<th>Method</th>
						  </tr>
						</thead>
						<tbody>
						
						
				<?php foreach ($user_course_detail as $single_course) {$count++;
					    	$course_name=$single_course['course_name'];
					    	$batch_name=$single_course['batch_name'];
					    	$course_fees=$single_course['stud_fess'];
					    	$discount=$single_course['stud_disc'];
							$totaldeposite=$this->my_model->aggregate_data('fees','fess_amount','SUM', array('fess_studid'=>$single_course['stud_id']), '');
							$remaining=$course_fees-$totaldeposite-$discount;
						    echo '<h3>'.$course_name.' ('.$batch_name.')</h3>';	
                            echo '<p>Fess: '.$course_fees.'</p>';
                            if($discount>0){
							echo '<tr>
								<td>-</td>
								<td>Discount</td>
								<td>'.$discount.'</td>
								<td></td>
								</tr>';
							$fees_detail=$this->my_model->select_data('*' , 'fees' , array('fess_studid'=>$single_course['stud_id']), '' ,'');
							if(!empty($fees_detail)){
                             		foreach ($fees_detail as $fees) {
                             		echo '<tr><td>'.date("d-m-Y", strtotime($fees['fess_date'])).'</td><td>'.$fees['fees_note'].'</td><td>'.$fees['fess_amount'].'</td><td>'.$fees['fess_method'].'</td></tr>';	
                             		}
                             	}
								
							echo '<tr><td colspan="2"><span class="label label-danger">Remining Amount</span></td><td><b>'.$remaining.'</b></td></tr>';	
							}							
				      } ?>		
					   </tbody>
					  </table>
                    					
					</div>    
					
					
			  </div>
            </div>
		</div>
	</div> 
</div>


<div id="FeesModal" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Add Fees</h4>
			</div>
			<div class="modal-body form-horizontal">
				<form method="post" action="<?php echo base_url('form_action/add_fees'); ?>" id="itemForm">
					<input type="hidden" name="fees_userId" value="<?php echo $user_detail['user_id']; ?>">
					<div class="form-group">
						<label class="control-label col-sm-3">Amount:</label>
						<div class="col-sm-9">
						  <input type="email" class="form-control blankField require" name="fees_amount" placeholder="Amount">
						</div>
					</div>
					<div class="form-group ">
						<label class="control-label col-sm-3" for="email">Payment Method:</label>
						<div class="col-sm-9">
							<select class="form-control require blankField" name="fess_method">
								<option value="Net Banking">Net Banking</option>
								<option value="Cheque">Cheque</option>
								<option value="Cash">Cash</option>
							</select>
						</div>
					</div>

					<div class="form-group ">
						<label class="control-label col-sm-3" for="email">Course/Batch:</label>
						<div class="col-sm-9">
							<select class="form-control require blankField" name="fees_course">
								<?php
								if(!empty($user_course_detail)){
									foreach($user_course_detail as $cData){
										echo '<option value="'.$cData['stud_id'].'">'.$cData['course_name'].' ('.$cData['batch_name'].')</option>';
									}
								}
								?>
							</select>
						</div>
					</div>


					<div class="form-group ">
						<label class="control-label col-sm-3" for="email">Note:</label>
						<div class="col-sm-9">
							<textarea type="email" class="form-control blankField require" name="fees_remark" placeholder="Note"></textarea>
						</div>
					</div>
				</form>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" id="saveButton" target-form="itemForm">Save</button>
			</div>
		</div>
	</div>
</div>


	