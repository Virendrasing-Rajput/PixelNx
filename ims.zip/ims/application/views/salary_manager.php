<div class="fs_content_wrapper fs_analytics_wrapper">
	<div class="fs_page_header">
		<div class="row">
			<div class="col-md-6 margin-bottom-20">
				<div class="fs_page_title margin-top-10">
					<h3>Salary(<span class="countTotal"><?php echo (isset($courseCount))?$courseCount:'0'; ?></span>)</h3>
				</div>
			</div>
			<div class="col-md-6 text-right">
				<a href="#SalaryModal" class="btn openModal">Add Salary</a>
			</div>
		</div>
	</div>
	<div class="row hide">
	  <div class="col-md-12">
		  <form class="form-inline" method="post" id="SearchForm" target-location="salary_data">
				<input type="hidden" id="formKey" name="formKey" value="0">
			  <button type="submit" class="btn btn-default" name="search_btn">Search</button>
		</form>
	  </div>
	</div>
	
	<div class="row">
		<div class="col-md-12">
			<div class="fs_analytics_table admin" id="ManAgency">
				<table id="fs_template_table" class="table table-hover dataTable table-striped width-full loadinData" target-location="salary_data">
					<thead>
						<tr>
							<th>#</th>
							<th>Name</th>
							<th>Amount</th>
							<th>Date</th>
							<th>Action</th>
						</tr> 
					</thead>
					<tbody>
						<tr>
							<td colspan="5" align="center">Loading...</td>
						</tr> 
					</tbody>
				</table>
			</div>
		</div>
		<div class="col-md-12">
			<div class="fs_pagination">
					
			</div>
		</div>
	</div> 
</div>


<div id="SalaryModal" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Add Salary</h4>
			</div>
			<div class="modal-body form-horizontal">
				<form method="post" action="<?php echo base_url('form_action/manage_salary'); ?>" id="itemForm">
					<input type="hidden" name="targetSalary">

					<div class="form-group ">
						<label class="control-label col-sm-3" for="email">Staff:</label>
						<div class="col-sm-9">
							<select class="form-control require blankField" name="sal_uid" onchange="getSalary(this)">
								<?php
								echo '<option value="" data-fees="">Select Staff</option>';
								if(isset($staffList) && !empty($staffList)){
									foreach($staffList as $cData){
										echo '<option value="'.$cData['user_id'].'" data-salary="'.$cData['user_salary'].'">'.$cData['user_full_name'].'</option>';
									}
								}
								?>
							</select>
						</div>
					</div>

					<div class="form-group">
						<label class="control-label col-sm-3"> Salary:</label>
						<div class="col-sm-9">
						  <input type="text" class="form-control blankField require" name="sal_amount" placeholder="Salary">
						</div>
				   </div>
				</form>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" id="saveButton" target-form="itemForm">Save</button>
			</div>
		</div>
	</div>
</div>