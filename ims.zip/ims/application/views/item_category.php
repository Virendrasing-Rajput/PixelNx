<div class="fs_content_wrapper fs_analytics_wrapper">
	<div class="fs_page_header">
		<div class="row">
			<div class="col-md-6 margin-bottom-20">
				<div class="fs_page_title margin-top-10">
					<h3>Item Category (<?php echo (isset($itemCategoryCount))?$itemCategoryCount:'0'; ?>)</h3>
				</div>
			</div>
			<div class="col-md-6 text-right">
				<a href="#categoryModal" class="btn openModal">Add Category</a>
			</div>
		</div>
	</div>
	
	<div class="row">
		<div class="col-md-12">
			<div class="fs_analytics_table">
				<table id="fs_template_table" class="table table-hover dataTable table-striped width-full loadinData" target-location="item_category_data">
					<thead>
						<tr>
							<th>#</th>
							<th>Category Name</th>
							<th>Apply GST</th>
							<th>Action</th>
						</tr> 
					</thead>
					<tbody>
						<tr>
							<td colspan="4" align="center">Loading...</td>
						</tr> 
					</tbody>
				</table>
			</div>
		</div>
	</div> 
</div>


<div id="categoryModal" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Manage Category</h4>
			</div>
			<div class="modal-body form-horizontal">
				<form id="categoryForm" action="<?php echo base_url('form_action/manage_category'); ?>">
					<input type="hidden" name="targetCategory" class="blankField">
					<div class="form-group">
						<label class="control-label col-sm-2">Name:</label>
						<div class="col-sm-10">
						  <input type="text" class="form-control require blankField" name="name" placeholder="Category Name">
						</div>
					</div>
					<div class="form-group ">
						<label class="control-label col-sm-2" for="email">GST:</label>
						<div class="col-sm-10">
							<div class=" input-group">
							  <input type="text" class="form-control return_number require blankField" name="apply_gst" placeholder="Apply GST">
							  <span class="input-group-addon">%</span>
							</div>
						</div>
					</div>
				</form>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" id="saveButton" target-form="categoryForm">Save</button>
			</div>
		</div>
	</div>
</div>