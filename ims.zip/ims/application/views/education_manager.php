<div class="fs_content_wrapper fs_analytics_wrapper">
	<div class="fs_page_header">
		<div class="row">
			<div class="col-md-6 margin-bottom-20">
				<div class="fs_page_title margin-top-10">
					<h3>Educations(<span class="countTotal"></span>)</h3>
				</div>
			</div>
			<div class="col-md-6 text-right">
				<a href="#EducationModal" class="btn openModal">Add Education</a>
			</div>
		</div>
	</div>
	<div class="row hide">
	  <div class="col-md-12">
		  <form class="form-inline" method="post" id="SearchForm" target-location="education_data">
				<input type="hidden" id="formKey" name="formKey" value="0">
			  <button type="submit" class="btn btn-default" name="search_btn">Search</button>
		</form>
	  </div>
	</div>
	
	<div class="row">
		<div class="col-md-12">
			<div class="fs_analytics_table admin" id="ManAgency">
				<table id="fs_template_table" class="table table-hover dataTable table-striped width-full loadinData" target-location="education_data">
					<thead>
						<tr>
							<th>#</th>
							<th>Name</th>
							<th>Action</th>
						</tr> 
					</thead>
					<tbody>
						<tr>
							<td colspan="3" align="center">Loading...</td>
						</tr> 
					</tbody>
				</table>
			</div>
		</div>
		<div class="col-md-12">
			<div class="fs_pagination">
					
			</div>
		</div>
	</div> 
</div>


<div id="EducationModal" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Add Education</h4>
			</div>
			<div class="modal-body form-horizontal">
				<form method="post" action="<?php echo base_url('form_action/manage_education'); ?>" id="itemForm">
					<input type="hidden" name="targetEducation">
					<div class="form-group">
						<label class="control-label col-sm-3">Education Name:</label>
						<div class="col-sm-9">
						  <input type="text" class="form-control blankField require" name="edu_name" placeholder="Education Name">
						</div>
					</div>
				</form>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" id="saveButton" target-form="itemForm">Save</button>
			</div>
		</div>
	</div>
</div>