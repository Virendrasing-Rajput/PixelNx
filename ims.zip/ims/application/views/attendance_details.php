<div class="fs_content_wrapper fs_analytics_wrapper">
	<div class="fs_page_header">
		<div class="row">
			<div class="col-md-6 margin-bottom-20">
				<div class="fs_page_title margin-top-10">
					<h3><?php echo $batchdetalis[0]['batch_name']; ?></h3>
					<h5><?php echo $date; ?></h5>
				</div>
			</div>
			
		</div>
	</div>
	
	<div class="row">
		<div class="col-md-12">
			<div class="fs_analytics_table admin" id="ManAgency">
				<table id="fs_template_table" class="table table-hover dataTable table-striped width-full " target-location="user_data">
					<thead>
						<tr>
							<th>#</th>
							<th>Name</th>
							<th>Status</th>
							
						</tr> 
					</thead>
					<tbody>
						<?php if(!empty($studentList)){$cnt='';
							foreach ($studentList as  $cData) {$cnt++;
								if (in_array($cData['user_id'], $attendacedata)){
									$status='<span class="label label-success">Present</span>';
								}else{
									$status='<span class="label label-danger">Absent</span>';
								}
								echo '<tr>
									<td>'.$cnt++.'</td>
									<td>'.$cData['user_full_name'].'</td>
									<td>'.$status.'</td>
							     </tr>';
							}

						} else{
                         echo '<tr><td colspan="6" align="center">No record found</td></tr>';
						} ?>
					</tbody>
				</table>
			</div>
		</div>
	</div> 
</div>

