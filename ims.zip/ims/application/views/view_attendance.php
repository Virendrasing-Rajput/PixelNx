<div class="fs_content_wrapper fs_analytics_wrapper">
	<div class="fs_page_header">
		<div class="row">
			<div class="col-md-6 margin-bottom-20">
				<div class="fs_page_title margin-top-10">
					<h3>View Attendance</h3>
				</div>
			</div>
			
		</div>
	</div>
	
	<div class="row">
		<div class="col-md-12">
		<?php if($page=="View Attendance"){ ?>
			<div class="fs_analytics_table admin" id="ManAgency">
				<form method="post" action="<?php echo base_url('commons/attendance_detail'); ?>" id="itemForm">
					
					<div class="form-group">
						<label class="control-label col-sm-3"> Date:</label>
						<div class="col-sm-9">
						  <input type="text" class="form-control blankField require datepicker" name="att_date" placeholder=" Date">
						</div>
					</div>
					<div class="form-group ">
						<label class="control-label col-sm-3" for="email">Courses:</label>
						<div class="col-sm-9">
							<select class="form-control require blankField" name="stud_course" onchange="getBatch(this)">
								<?php
								if(isset($courseList) && !empty($courseList)){
									echo '<option value="">Select Course</option>';
									foreach($courseList as $cData){
										$selected='';
										if($cData['course_id']==$enqData['enq_course']){ $selected='selected';}
										echo '<option value="'.$cData['course_id'].'" '. $selected.'>'.$cData['course_name'].'</option>';
									}
								}
								?>
							</select>
						</div>
					</div>
					<div class="form-group ">
						<label class="control-label col-sm-3" for="email">Batches:</label>
						<div class="col-sm-9">
							<select class="form-control require blankField" name="stud_batch">
							echo '<option value="">Select Batch</option>';
								<?php
								if(isset($batchList) && !empty($batchList)){
									foreach($batchList as $cData){
										echo '<option value="'.$cData['batch_id'].'">'.$cData['batch_name'].'</option>';
									}
								}
								?>
							</select>
						</div>
					</div>	
			 </div>
			<div class="col-md-12">
				<button type="button" class="btn btn-default" id="view_attendance" target-form="itemForm">Save</button>
			</div>
			<?php } ?>

			<?php if($page=="Attendance"){ ?>
			<div class="fs_analytics_table admin" id="ManAgency">
				<form method="post" action="<?php echo base_url('commons/get_student'); ?>" id="itemForm">
					<div class="form-group ">
						<label class="control-label col-sm-3" for="email">Courses:</label>
						<div class="col-sm-9">
							<select class="form-control require blankField" name="stud_course" onchange="getBatch(this)">
								<?php
								if(isset($courseList) && !empty($courseList)){
									echo '<option value="">Select Course</option>';
									foreach($courseList as $cData){
										$selected='';
										if($cData['course_id']==$enqData['enq_course']){ $selected='selected';}
										echo '<option value="'.$cData['course_id'].'" '. $selected.'>'.$cData['course_name'].'</option>';
									}
								}
								?>
							</select>
						</div>
					</div>
					<div class="form-group ">
						<label class="control-label col-sm-3" for="email">Batches:</label>
						<div class="col-sm-9">
							<select class="form-control require blankField" name="stud_batch">
							echo '<option value="">Select Batch</option>';
								<?php
								if(isset($batchList) && !empty($batchList)){
									foreach($batchList as $cData){
										echo '<option value="'.$cData['batch_id'].'">'.$cData['batch_name'].'</option>';
									}
								}
								?>
							</select>
						</div>
					</div>	
			 </div>
			<div class="col-md-12">
				<button type="button" class="btn btn-default" id="view_attendance" target-form="itemForm">Get Student</button>
			</div>
			<?php } ?>
		</div>
	</div> 
</div>



	