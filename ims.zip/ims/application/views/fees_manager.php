<div class="fs_content_wrapper fs_analytics_wrapper">
	<div class="fs_page_header">
		<div class="row">
			<div class="col-md-6 margin-bottom-20">
				<div class="fs_page_title margin-top-10">
					<h3>Fees Management</h3>
				</div>
			</div>
			
		</div>
	</div>
	
	<div class="row">
	  <div class="col-md-12">
		  <form class="form-inline hide" method="post" id="SearchForm" target-location="feesmanager_data">
				<input type="hidden" id="formKey" name="formKey" value="0">
			  <button type="submit" class="btn btn-default" name="search_btn">Search</button>
		</form>
	  </div>
	</div>
	
	<div class="row">
		<div class="col-md-12">
			<div class="fs_analytics_table admin" id="ManAgency">
				<table id="fs_template_table" class="table table-hover dataTable table-striped width-full loadinData" target-location="feesmanager_data">
					<thead>
						<tr>
							<th>#</th>
							<th>Name</th>
							<th>Mobile</th>
							<th>Email</th>
							<th>Remaining</th>
							<th>Action</th>
						</tr> 
					</thead>
					<tbody>
						<tr>
							<td colspan="6" align="center">Loading...</td>
						</tr> 
					</tbody>
				</table>
			</div>
		</div>
		<div class="col-md-12">
		<div class="fs_pagination">
				
		</div>
		</div>
	</div> 
</div>

