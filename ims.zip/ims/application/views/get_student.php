<div class="fs_content_wrapper fs_analytics_wrapper">
	<div class="fs_page_header">
		<div class="row">
			<div class="col-md-6 margin-bottom-20">
				<div class="fs_page_title margin-top-10">
					<h3><?php echo $batchdetalis[0]['batch_name']; ?></h3>
					<h5><?php echo date('Y-m-d'); ?></h5>
				</div>
			</div>
			
		</div>
	</div>
	
	<div class="row">
		<div class="col-md-12">
			<div class="fs_analytics_table admin" id="ManAgency">
				<table id="fs_template_table" class="table table-hover dataTable table-striped width-full " target-location="user_data">
                    <thead>
                        <tr>
                            <th>All  <?php if(!empty($studentList))echo '<input type="checkbox" id="check-all"></th>';?>
                            <th>Name</th>       
                            
                        </tr> 
                    </thead>
                    <tbody>
                        <?php if(!empty($studentList)){$cnt='';
                       echo '<form method="post" action="'.base_url('commons/add_attendance').'" id="itemForm">
                             <input type="hidden" name="att_batch" value="'.$batchdetalis[0]['batch_id'].'">';
                            foreach ($studentList as  $cData) {$cnt++;
                               
                                echo '<tr>
                                    <td><input type="checkbox" name="attendance[]" value="'.$cData['user_id'].'"></td>
                                    <td>'.$cData['user_full_name'].'</td>
                                    
                                 </tr>';
                            }
                        echo '</form>';
                        } else{
                         echo '<tr><td colspan="6" align="center">No record found</td></tr>';
                        } 
                        ?>
                    </tbody>
                </table>
			</div>
             <?php if(!empty($studentList)){
            echo '<button type="button" class="btn btn-default" id="view_attendance" target-form="itemForm">Submit</button>';
            }?>
		</div>
	</div> 
</div>

