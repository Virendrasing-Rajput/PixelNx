
</div>
<!-- site wrapper end -->

<!-- site jquery start -->
<script src="<?php echo base_url('assets/js/lib/jquery-3.1.1.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/lib/jquery-ui.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/lib/bootstrap.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugin/mCustomScrollbar/mCustomScrollbar.concat.min.js'); ?>"></script>


<?php
/*

<script src="<?php echo base_url('assets/js/lib/jquery-ui.min.js'); ?>"></script>
<script src="http://mugifly.github.io/jquery-simple-datetimepicker/jquery.simple-dtpicker.js"></script>

if(isset($dashboard) || isset($doctors) || isset($patients) || isset($assets) || isset($path_test)){
	echo '<script src="'.base_url('assets/js/plugin/datatables/jquery.dataTables.js').'"></script>
	<script src="'.base_url('assets/js/plugin/datatables/dataTables.fixedHeader.js').'"></script>
	<script src="'.base_url('assets/js/plugin/datatables/dataTables.bootstrap.js').'"></script>
	<script src="'.base_url('assets/js/plugin/datatables/dataTables.responsive.js').'"></script>
	<script src="'.base_url('assets/js/plugin/datatables/dataTables.tableTools.js').'"></script>';
}


if(isset($broadcast) || isset($calendar) || isset($analytics)){
	echo '<script src="'.base_url('assets/js/plugin/datepicker/bootstrap-datepicker.min.js').'"></script>
	<script src="'.base_url('assets/js/plugin/datetimepicker/moment.js').'"></script>
	<script src="'.base_url('assets/js/plugin/datetimepicker/bootstrap-datetimepicker.min.js').'"></script>';
}


<script src="<?php echo base_url('assets/js/plugin/bootstrap_select/bootstrap-select.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugin/magnific_popup/jquery.magnific-popup.min.js'); ?>"></script>



if(isset($whitelabel_setting)){
	echo '<script src="'.base_url('assets/js/plugin/asColorPicker/asColorPicker.js').'"></script>';
	echo '<script src="'.base_url('assets/js/whitelabel.js?'.date('his')).'"></script>';
}
*/
?>
<script src="<?php echo base_url('assets/js/toastr.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugin/datetimepicker/moment.js');?>"></script>
<script src="<?php echo base_url('assets/js/plugin/datetimepicker/bootstrap-datetimepicker.min.js');?>"></script>
<script src="<?php echo base_url('assets/js/valid.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/custom.js?'.date('his')); ?>"></script>
<script src="<?php echo base_url('assets/js/ims_custom.js?'.date('his')); ?>"></script>
<!-- site jquery end -->

<?php
	
	if($this->session->flashdata('success') != ''){
		echo '<script>toastr.success('."'".$this->session->flashdata('success')."'".')</script>';
	}

	if($this->session->flashdata('error') != ''){
		echo '<script>toastr.error('."'".$this->session->flashdata('error')."'".')</script>';
	}

	if($this->session->flashdata('warning') != ''){
		echo '<script>toastr.warning('."'".$this->session->flashdata('warning')."'".')</script>';
	}
?>
</body>
</html>