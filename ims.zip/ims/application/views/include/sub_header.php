<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta content="width=device-width, initial-scale=1.0" name="viewport" />
	<meta name="description"  content=""/>
	<meta name="keywords" content="">
	<meta name="author"  content=""/>
	<meta name="MobileOptimized" content="320">
	
	<link rel="shortcut icon" type="image/ico" href="<?php echo base_url($this->common->site_favicon); ?>" />
	<link rel="icon" type="image/ico" href="<?php echo base_url($this->common->site_favicon); ?>" />
	
	<title><?php echo $this->common->site_name; ?></title>
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
	<link href="<?php echo base_url('assets/css/bootstrap.css'); ?>" rel="stylesheet">
	<link href="<?php echo base_url('assets/css/jquery-ui.min.css'); ?>" rel="stylesheet">
	<link rel="stylesheet" href="http://mugifly.github.io/jquery-simple-datetimepicker/jquery.simple-dtpicker.css">
	<link href="<?php echo base_url('assets/css/bootstrap_theme.css'); ?>" rel="stylesheet">
	<link href="<?php echo base_url('assets/css/font-awesome.min.css'); ?>" rel="stylesheet">
	<link href="<?php echo base_url('assets/css/mCustomScrollbar.css'); ?>" rel="stylesheet">
	<link href="<?php echo base_url('assets/css/magnific-popup.css'); ?>" rel="stylesheet">
	<?php
	if(isset($templates) || isset($msgBtn) || isset($analytics) || isset($dashboard) || isset($user) || isset($agency)){
		echo '<link href="'.base_url('assets/css/datatable.css').'"  rel="stylesheet">';
	}
	?>
	<link href="<?php echo base_url('assets/css/bootstrap-select.min.css'); ?>" rel="stylesheet">
	
	<?php  
	if(isset($broadcast) || isset($calendar) || isset($analytics)){
		echo '<link href="'.base_url('assets/css/bootstrap-datepicker.min.css').'" rel="stylesheet">
		<link href="'.base_url('assets/css/bootstrap-datetimepicker.min.css').'" rel="stylesheet">';
	}
	
	if(isset($whitelabel_setting)){
		echo '<link href="'.base_url('assets/css/asColorPicker.css').'" rel="stylesheet">';
	}	
	?>
	
	<link href="<?php echo base_url('assets/css/animation.css'); ?>" rel="stylesheet">
	<link href="<?php echo base_url('assets/css/toastr.css'); ?>" rel="stylesheet">
	<link href="<?php echo base_url('assets/css/style.css?'.date('his')); ?>" rel="stylesheet">
	<?php echo $this->common->my_css(); ?>
</head>
<body class="<?php echo ((isset($broadcast) && !isset($broadcastDeta)) || (isset($campaign) && !isset($campaignDetail)))?'mCustomScrollBox_fullHeight':''; ?>">
<div class="fs_loading_wrapper">
	<div class="cssload-loader"></div>
</div>
<!-- site wrapper start -->
<div class="fs_site_wrapper">
	
	<div class="fs_sidebar_toggle clearfix">
		<!--<div class="fs_logo">
			<a href="<?php echo base_url(); ?>dashboard"><img src="<?php echo base_url(); ?>assets/images/logo_dark.png" alt="" /></a>
		</div> -->
		<div class="toggle_btn"> <img src="<?php echo base_url(); ?>assets/images/icon/menu.svg" alt="" /> Menu</div>
	</div>
	<div class="fs_sidebar_closer"></div>
	
	
	<div class="fs_sidebar_wrapper fs_custom_scrollbar">
		<div class="fs_sidebar_inner">
			<a href="<?php echo base_url(); ?>user" class="fs_logo_wrapper">
				<!-- <span>Ds</span> -->
				<img src="<?php echo base_url($this->common->site_logo); ?>" alt="" />
			</a>
			
			<div class="fs_nav_wrapper">
				<ul>
					<li <?php echo (isset($patients))?'class="active"':''; ?>>
						<a href="<?php echo base_url('add_patient'); ?>">
							<span class="icon">
								<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 459.46 459.46" style="enable-background:new 0 0 459.46 459.46;" xml:space="preserve"><g><g><g><circle cx="63.444" cy="164.99" r="33.614"/><path d="M247.869,133.679c14.773-9.149,34.411-4.813,43.763,10.287c9.204,14.859,4.69,34.49-10.286,43.763l-55.088,34.12c-12.236,7.578-26.712,4.936-33.047,0.016l-6.261-4.864c-0.014,3.708,0.054,7.537,0.21,11.489c0.174,4.372,3.767,7.832,8.143,7.832h235.233c3.697,0,6.931-2.487,7.881-6.059l4.705-17.695c5.082-31.254-16.53-57.652-46.951-66.437c-61.654-17.804-138.057-30.966-175.366-29.91c0,0-15.22,11.639-25.251,42.163l9.67,1.706L247.869,133.679z"/><path d="M433.044,306.512c-2.291,0-4.515,0.294-6.636,0.845c0-10.193,0-40.763,0-50.909c-8.568,0-219.89,0-231.105,0c-15.365,0-27.655-12.08-28.253-27.16c-0.385-9.711-0.249-19.391,0.254-27.546l-26.464-20.555l61.922,28.38c4.913,2.251,10.698,1.893,15.298-0.956l55.088-34.12c6.956-4.307,10.243-13.587,5.247-22.331c-4.742-7.653-14.779-9.921-22.327-5.246l-47.695,29.541l-56.075-25.7l23.251,4.101c3.242-10.436,7.53-20.72,13.175-30.352l-58.119-1.067c-12.741-0.234-22.893,9.994-23.12,22.284c0,0,0,0.001,0,0.002l-0.743,40.487c-0.199,10.838,7.378,20.408,18.029,22.636H20.133v-98.664c0-5.558-4.505-10.063-10.063-10.063c-5.558,0-10.063,4.505-10.063,10.063c0,234.967-0.044,221.928,0.082,222.966c0.12,14.463,11.919,26.194,26.41,26.194c14.565,0,26.415-11.85,26.415-26.415s-11.85-26.415-26.415-26.415c-2.195,0-4.326,0.274-6.366,0.78c0-19.282,0-16.721,0-30.017h386.15v54.645c0,14.768,11.594,27.422,26.762,27.422c14.565,0,26.415-11.85,26.415-26.415S447.61,306.512,433.044,306.512z"/></g></g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g></svg>
								</span>	
							<span>PATIENT</span> 
						</a>
					</li>
					
					<li>
						<a href="<?php echo base_url('sub_admin/logout'); ?>">
							<span class="icon">
								<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="19.75px" height="15.266px" viewBox="-0.5 -0.5 19.75 15.266" enable-background="new -0.5 -0.5 19.75 15.266" xml:space="preserve"><g><g><path fill="#5A6168" stroke="#5A6269" stroke-miterlimit="10" d="M18.198,0H10.84c-0.305,0-0.551,0.245-0.551,0.549s0.247,0.549,0.551,0.549h6.807v12.069H1.103V1.098h4.719v2.749C5.82,3.862,5.82,3.878,5.82,3.894c0,2.244,1.833,4.069,4.084,4.069h2.711l-1.449,1.443c-0.215,0.215-0.215,0.563,0,0.776c0.107,0.106,0.248,0.16,0.391,0.16c0.142,0,0.281-0.054,0.389-0.16l2.392-2.381c0.215-0.215,0.215-0.563,0-0.777l-2.392-2.381c-0.215-0.215-0.563-0.215-0.778,0s-0.215,0.563,0,0.776l1.448,1.442H9.904c-1.629,0-2.958-1.309-2.981-2.927c0.001-0.015,0.002-0.028,0.002-0.044V0.549C6.925,0.245,6.678,0,6.373,0H0.551C0.247,0,0,0.245,0,0.549v13.168c0,0.303,0.247,0.549,0.551,0.549h17.647c0.305,0,0.552-0.246,0.552-0.549V0.549C18.75,0.245,18.503,0,18.198,0z"/></g></g></svg>
							</span>	
							<span>LOGOUT</span>
						</a>
					</li>
					
					
				</ul>
			</div>
			
		</div>
	</div>
	
	<input type="hidden" value="<?php echo base_url(); ?>" id="base_url">