<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta content="width=device-width, initial-scale=1.0" name="viewport" />
	<meta name="description"  content=""/>
	<meta name="keywords" content="">
	<meta name="author"  content=""/>
	<meta name="MobileOptimized" content="320">
	
	<link rel="shortcut icon" type="image/ico" href="<?php echo base_url($this->common->site_favicon); ?>" />
	<link rel="icon" type="image/ico" href="<?php echo base_url($this->common->site_favicon); ?>" />
	
	<title><?php if(isset($title)) echo $title.' | '; ?><?php echo $this->common->site_name; ?></title>
	<!--<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">-->
	<link href="<?php echo base_url('assets/css/bootstrap.css'); ?>" rel="stylesheet">
	<link href="<?php echo base_url('assets/css/bootstrap_theme.css'); ?>" rel="stylesheet">
	<link href="<?php echo base_url('assets/css/font-awesome.min.css'); ?>" rel="stylesheet">
	<link href="<?php echo base_url('assets/css/mCustomScrollbar.css'); ?>" rel="stylesheet">
	
	
	
	<?php  
	/*
	
	<link rel="stylesheet" href="http://mugifly.github.io/jquery-simple-datetimepicker/jquery.simple-dtpicker.css">
	<link href="<?php echo base_url('assets/css/jquery-ui.min.css'); ?>" rel="stylesheet">
	<link href="<?php echo base_url('assets/css/magnific-popup.css'); ?>" rel="stylesheet">
	<link href="<?php echo base_url('assets/css/bootstrap-select.min.css'); ?>" rel="stylesheet">
	echo '<link href="'.base_url('assets/css/datatable.css').'"  rel="stylesheet">';
	
	if(isset($broadcast) || isset($calendar) || isset($analytics)){
		echo '<link href="'.base_url('assets/css/bootstrap-datepicker.min.css').'" rel="stylesheet">
		<link href="'.base_url('assets/css/bootstrap-datetimepicker.min.css').'" rel="stylesheet">';
	}
	
	if(isset($whitelabel_setting)){
		echo '<link href="'.base_url('assets/css/asColorPicker.css').'" rel="stylesheet">';
	}	
	
	*/
	?>
	
	<link href="<?php echo base_url('assets/css/animation.css'); ?>" rel="stylesheet">
	<link href="<?php echo base_url('assets/css/toastr.css'); ?>" rel="stylesheet">
	<link href="<?php echo base_url('assets/css/bootstrap-datetimepicker.min.css'); ?>" rel="stylesheet">
	<link href="<?php echo base_url('assets/css/jquery-ui.min.css'); ?>" rel="stylesheet">
	<link href="<?php echo base_url('assets/css/style.css?'.date('his')); ?>" rel="stylesheet">
	<?php echo $this->common->my_css(); ?>
</head>
<body class="<?php echo ((isset($broadcast) && !isset($broadcastDeta)) || (isset($campaign) && !isset($campaignDetail)))?'mCustomScrollBox_fullHeight':''; ?>">
<div class="fs_loading_wrapper">
	<div class="cssload-loader"></div>
</div>
<!-- site wrapper start -->
<div class="fs_site_wrapper">
	
	<div class="fs_sidebar_toggle clearfix">
		<!--<div class="fs_logo">
			<a href="<?php echo base_url(); ?>dashboard"><img src="<?php echo base_url(); ?>assets/images/logo_dark.png" alt="" /></a>
		</div> -->
		<div class="toggle_btn"> <img src="<?php echo base_url(); ?>assets/images/icon/menu.svg" alt="" /> Menu</div>
	</div>
	<div class="fs_sidebar_closer"></div>
	
	
	<div class="fs_sidebar_wrapper fs_custom_scrollbar">
		<div class="fs_sidebar_inner">
			<a href="<?php echo base_url(); ?>user" class="fs_logo_wrapper">
				<!-- <span>Ds</span> -->
				<img src="<?php echo base_url($this->common->site_logo); ?>" alt="" style="width:100px;" />
			</a>
			
			<div class="fs_nav_wrapper">
				<ul>
					<li <?php echo (isset($page) && $page == 'dashboard')?'class="active"':''; ?>>
						<a href="<?php echo base_url('dashboard'); ?>">
							<span class="icon">
								<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="23.997px" height="15.104px" viewBox="0 0 23.997 15.104" enable-background="new 0 0 23.997 15.104" xml:space="preserve"><path fill="#5A6269" d="M0,15.104V1.438C0,0.644,0.644,0,1.438,0l0,0c0.794,0,1.438,0.644,1.438,1.438v13.666H0z"/><g><path fill="#5A6269" d="M20.997,3v9.104H9V3H20.997 M22.997,0H7C6.448,0,6,0.448,6,1v13.104c0,0.553,0.448,1,1,1h15.997c0.552,0,1-0.447,1-1V1C23.997,0.448,23.549,0,22.997,0L22.997,0z"/></g></svg>
							</span>
							<span>DASHBOARD</span>
						</a>  
					</li>
					
					
					<li <?php echo (isset($page) && $page == 'enquiry_manager')?'class="active"':''; ?>>
						<a href="<?php echo base_url('commons/enquiry_manager'); ?>">
							<span class="icon">
								<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="23.997px" height="15.104px" viewBox="0 0 23.997 15.104" enable-background="new 0 0 23.997 15.104" xml:space="preserve"><path fill="#5A6269" d="M0,15.104V1.438C0,0.644,0.644,0,1.438,0l0,0c0.794,0,1.438,0.644,1.438,1.438v13.666H0z"/><g><path fill="#5A6269" d="M20.997,3v9.104H9V3H20.997 M22.997,0H7C6.448,0,6,0.448,6,1v13.104c0,0.553,0.448,1,1,1h15.997c0.552,0,1-0.447,1-1V1C23.997,0.448,23.549,0,22.997,0L22.997,0z"/></g></svg>
							</span>
							<span>Enquiries </span>
						</a>  
					</li>

					<li <?php echo (isset($page) && $page == 'college_manager')?'class="active"':''; ?>>
						<a href="<?php echo base_url('admin/college_manager'); ?>">
							<span class="icon">
								<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="23.997px" height="15.104px" viewBox="0 0 23.997 15.104" enable-background="new 0 0 23.997 15.104" xml:space="preserve"><path fill="#5A6269" d="M0,15.104V1.438C0,0.644,0.644,0,1.438,0l0,0c0.794,0,1.438,0.644,1.438,1.438v13.666H0z"/><g><path fill="#5A6269" d="M20.997,3v9.104H9V3H20.997 M22.997,0H7C6.448,0,6,0.448,6,1v13.104c0,0.553,0.448,1,1,1h15.997c0.552,0,1-0.447,1-1V1C23.997,0.448,23.549,0,22.997,0L22.997,0z"/></g></svg>
							</span>
							<span>College</span>
						</a>  
					</li>

					<li <?php echo (isset($page) && $page == 'education_manager')?'class="active"':''; ?>>
						<a href="<?php echo base_url('admin/education_manager'); ?>">
							<span class="icon">
								<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="23.997px" height="15.104px" viewBox="0 0 23.997 15.104" enable-background="new 0 0 23.997 15.104" xml:space="preserve"><path fill="#5A6269" d="M0,15.104V1.438C0,0.644,0.644,0,1.438,0l0,0c0.794,0,1.438,0.644,1.438,1.438v13.666H0z"/><g><path fill="#5A6269" d="M20.997,3v9.104H9V3H20.997 M22.997,0H7C6.448,0,6,0.448,6,1v13.104c0,0.553,0.448,1,1,1h15.997c0.552,0,1-0.447,1-1V1C23.997,0.448,23.549,0,22.997,0L22.997,0z"/></g></svg>
							</span>
							<span>Education</span>
						</a>  
					</li>
                    
                    <li <?php echo (isset($page) && $page == 'student_manager')?'class="active"':''; ?>>
						<a href="<?php echo base_url('commons/student_manager'); ?>">
							<span class="icon">
								<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="23.997px" height="15.104px" viewBox="0 0 23.997 15.104" enable-background="new 0 0 23.997 15.104" xml:space="preserve"><path fill="#5A6269" d="M0,15.104V1.438C0,0.644,0.644,0,1.438,0l0,0c0.794,0,1.438,0.644,1.438,1.438v13.666H0z"/><g><path fill="#5A6269" d="M20.997,3v9.104H9V3H20.997 M22.997,0H7C6.448,0,6,0.448,6,1v13.104c0,0.553,0.448,1,1,1h15.997c0.552,0,1-0.447,1-1V1C23.997,0.448,23.549,0,22.997,0L22.997,0z"/></g></svg>
							</span>
							<span>Students </span>
						</a>  
					</li>
					<li <?php echo (isset($page) && $page == 'staff_manager')?'class="active"':''; ?>>
						<a href="<?php echo base_url('admin/staff_manager'); ?>">
							<span class="icon">
								<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="23.997px" height="15.104px" viewBox="0 0 23.997 15.104" enable-background="new 0 0 23.997 15.104" xml:space="preserve"><path fill="#5A6269" d="M0,15.104V1.438C0,0.644,0.644,0,1.438,0l0,0c0.794,0,1.438,0.644,1.438,1.438v13.666H0z"/><g><path fill="#5A6269" d="M20.997,3v9.104H9V3H20.997 M22.997,0H7C6.448,0,6,0.448,6,1v13.104c0,0.553,0.448,1,1,1h15.997c0.552,0,1-0.447,1-1V1C23.997,0.448,23.549,0,22.997,0L22.997,0z"/></g></svg>
							</span>
							<span>Staff</span>
						</a>  
					</li>

					<li <?php echo (isset($page) && $page == 'salary_manager')?'class="active"':''; ?>>
						<a href="<?php echo base_url('admin/salary_manager'); ?>">
							<span class="icon">
								<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="23.997px" height="15.104px" viewBox="0 0 23.997 15.104" enable-background="new 0 0 23.997 15.104" xml:space="preserve"><path fill="#5A6269" d="M0,15.104V1.438C0,0.644,0.644,0,1.438,0l0,0c0.794,0,1.438,0.644,1.438,1.438v13.666H0z"/><g><path fill="#5A6269" d="M20.997,3v9.104H9V3H20.997 M22.997,0H7C6.448,0,6,0.448,6,1v13.104c0,0.553,0.448,1,1,1h15.997c0.552,0,1-0.447,1-1V1C23.997,0.448,23.549,0,22.997,0L22.997,0z"/></g></svg>
							</span>
							<span>Staff Salary</span>
						</a>  
					</li>

					
					<li <?php echo (isset($page) && $page == 'course_manager')?'class="active"':''; ?>>
						<a href="<?php echo base_url('admin/course_manager'); ?>">
							<span class="icon">
								<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="23.997px" height="15.104px" viewBox="0 0 23.997 15.104" enable-background="new 0 0 23.997 15.104" xml:space="preserve"><path fill="#5A6269" d="M0,15.104V1.438C0,0.644,0.644,0,1.438,0l0,0c0.794,0,1.438,0.644,1.438,1.438v13.666H0z"/><g><path fill="#5A6269" d="M20.997,3v9.104H9V3H20.997 M22.997,0H7C6.448,0,6,0.448,6,1v13.104c0,0.553,0.448,1,1,1h15.997c0.552,0,1-0.447,1-1V1C23.997,0.448,23.549,0,22.997,0L22.997,0z"/></g></svg>
							</span>
							<span>Courses</span>
						</a>  
					</li>

					<li <?php echo (isset($page) && $page == 'batches_manager')?'class="active"':''; ?>>
						<a href="<?php echo base_url('admin/batches_manager'); ?>">
							<span class="icon">
								<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="23.997px" height="15.104px" viewBox="0 0 23.997 15.104" enable-background="new 0 0 23.997 15.104" xml:space="preserve"><path fill="#5A6269" d="M0,15.104V1.438C0,0.644,0.644,0,1.438,0l0,0c0.794,0,1.438,0.644,1.438,1.438v13.666H0z"/><g><path fill="#5A6269" d="M20.997,3v9.104H9V3H20.997 M22.997,0H7C6.448,0,6,0.448,6,1v13.104c0,0.553,0.448,1,1,1h15.997c0.552,0,1-0.447,1-1V1C23.997,0.448,23.549,0,22.997,0L22.997,0z"/></g></svg>
							</span>
							<span>Batches</span>
						</a>  
					</li>
					<li <?php echo (isset($page) && $page == 'view_manager')?'class="active"':''; ?>>
						<a href="<?php echo base_url('commons/view_attendance'); ?>">
							<span class="icon">
								<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="23.997px" height="15.104px" viewBox="0 0 23.997 15.104" enable-background="new 0 0 23.997 15.104" xml:space="preserve"><path fill="#5A6269" d="M0,15.104V1.438C0,0.644,0.644,0,1.438,0l0,0c0.794,0,1.438,0.644,1.438,1.438v13.666H0z"/><g><path fill="#5A6269" d="M20.997,3v9.104H9V3H20.997 M22.997,0H7C6.448,0,6,0.448,6,1v13.104c0,0.553,0.448,1,1,1h15.997c0.552,0,1-0.447,1-1V1C23.997,0.448,23.549,0,22.997,0L22.997,0z"/></g></svg>
							</span>
							<span>View Attendance</span>
						</a>  
					</li>

					<li <?php echo (isset($page) && $page == 'attendance')?'class="active"':''; ?>>
						<a href="<?php echo base_url('commons/attendance'); ?>">
							<span class="icon">
								<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="23.997px" height="15.104px" viewBox="0 0 23.997 15.104" enable-background="new 0 0 23.997 15.104" xml:space="preserve"><path fill="#5A6269" d="M0,15.104V1.438C0,0.644,0.644,0,1.438,0l0,0c0.794,0,1.438,0.644,1.438,1.438v13.666H0z"/><g><path fill="#5A6269" d="M20.997,3v9.104H9V3H20.997 M22.997,0H7C6.448,0,6,0.448,6,1v13.104c0,0.553,0.448,1,1,1h15.997c0.552,0,1-0.447,1-1V1C23.997,0.448,23.549,0,22.997,0L22.997,0z"/></g></svg>
							</span>
							<span>Add Attendance</span>
						</a>  
					</li>
					
					
					<li <?php echo (isset($page) && $page == 'expenses_type_manager')?'class="active"':''; ?>>
						<a href="<?php echo base_url('admin/expenses_type_manager'); ?>">
							<span class="icon">
								<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="23.997px" height="15.104px" viewBox="0 0 23.997 15.104" enable-background="new 0 0 23.997 15.104" xml:space="preserve"><path fill="#5A6269" d="M0,15.104V1.438C0,0.644,0.644,0,1.438,0l0,0c0.794,0,1.438,0.644,1.438,1.438v13.666H0z"/><g><path fill="#5A6269" d="M20.997,3v9.104H9V3H20.997 M22.997,0H7C6.448,0,6,0.448,6,1v13.104c0,0.553,0.448,1,1,1h15.997c0.552,0,1-0.447,1-1V1C23.997,0.448,23.549,0,22.997,0L22.997,0z"/></g></svg>
							</span>
							<span>Expenses Type</span>
						</a>  
					</li>
					
					<li <?php echo (isset($page) && $page == 'expenses_manager')?'class="active"':''; ?>>
						<a href="<?php echo base_url('admin/expenses_manager'); ?>">
							<span class="icon">
								<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="23.997px" height="15.104px" viewBox="0 0 23.997 15.104" enable-background="new 0 0 23.997 15.104" xml:space="preserve"><path fill="#5A6269" d="M0,15.104V1.438C0,0.644,0.644,0,1.438,0l0,0c0.794,0,1.438,0.644,1.438,1.438v13.666H0z"/><g><path fill="#5A6269" d="M20.997,3v9.104H9V3H20.997 M22.997,0H7C6.448,0,6,0.448,6,1v13.104c0,0.553,0.448,1,1,1h15.997c0.552,0,1-0.447,1-1V1C23.997,0.448,23.549,0,22.997,0L22.997,0z"/></g></svg>
							</span>
							<span>Expenses</span>
						</a>  
					</li>
					
					<li <?php echo (isset($page) && $page == 'fees')?'class="active"':''; ?>>
						<a href="<?php echo base_url('admin/fees'); ?>">
							<span class="icon">
								<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="23.997px" height="15.104px" viewBox="0 0 23.997 15.104" enable-background="new 0 0 23.997 15.104" xml:space="preserve"><path fill="#5A6269" d="M0,15.104V1.438C0,0.644,0.644,0,1.438,0l0,0c0.794,0,1.438,0.644,1.438,1.438v13.666H0z"/><g><path fill="#5A6269" d="M20.997,3v9.104H9V3H20.997 M22.997,0H7C6.448,0,6,0.448,6,1v13.104c0,0.553,0.448,1,1,1h15.997c0.552,0,1-0.447,1-1V1C23.997,0.448,23.549,0,22.997,0L22.997,0z"/></g></svg>
							</span>
							<span>Fees</span>
						</a>  
					</li>
					
					<li <?php echo (isset($page) && $page == 'fees_manager')?'class="active"':''; ?>>
						<a href="<?php echo base_url('admin/fees_manager'); ?>">
							<span class="icon">
								<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="23.997px" height="15.104px" viewBox="0 0 23.997 15.104" enable-background="new 0 0 23.997 15.104" xml:space="preserve"><path fill="#5A6269" d="M0,15.104V1.438C0,0.644,0.644,0,1.438,0l0,0c0.794,0,1.438,0.644,1.438,1.438v13.666H0z"/><g><path fill="#5A6269" d="M20.997,3v9.104H9V3H20.997 M22.997,0H7C6.448,0,6,0.448,6,1v13.104c0,0.553,0.448,1,1,1h15.997c0.552,0,1-0.447,1-1V1C23.997,0.448,23.549,0,22.997,0L22.997,0z"/></g></svg>
							</span>
							<span>Remaining Fees</span>
						</a>  
					</li>
					
					<li <?php echo (isset($page) && $page == 'account_manager')?'class="active"':''; ?>>
						<a href="<?php echo base_url('admin/account_manager'); ?>">
							<span class="icon">
								<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="23.997px" height="15.104px" viewBox="0 0 23.997 15.104" enable-background="new 0 0 23.997 15.104" xml:space="preserve"><path fill="#5A6269" d="M0,15.104V1.438C0,0.644,0.644,0,1.438,0l0,0c0.794,0,1.438,0.644,1.438,1.438v13.666H0z"/><g><path fill="#5A6269" d="M20.997,3v9.104H9V3H20.997 M22.997,0H7C6.448,0,6,0.448,6,1v13.104c0,0.553,0.448,1,1,1h15.997c0.552,0,1-0.447,1-1V1C23.997,0.448,23.549,0,22.997,0L22.997,0z"/></g></svg>
							</span>
							<span>Accounts</span>
						</a>  
					</li>
					
					
					<li>
						<a href="<?php echo base_url('home/logout'); ?>">
							<span class="icon">
								<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="19.75px" height="15.266px" viewBox="-0.5 -0.5 19.75 15.266" enable-background="new -0.5 -0.5 19.75 15.266" xml:space="preserve"><g><g><path fill="#5A6168" stroke="#5A6269" stroke-miterlimit="10" d="M18.198,0H10.84c-0.305,0-0.551,0.245-0.551,0.549s0.247,0.549,0.551,0.549h6.807v12.069H1.103V1.098h4.719v2.749C5.82,3.862,5.82,3.878,5.82,3.894c0,2.244,1.833,4.069,4.084,4.069h2.711l-1.449,1.443c-0.215,0.215-0.215,0.563,0,0.776c0.107,0.106,0.248,0.16,0.391,0.16c0.142,0,0.281-0.054,0.389-0.16l2.392-2.381c0.215-0.215,0.215-0.563,0-0.777l-2.392-2.381c-0.215-0.215-0.563-0.215-0.778,0s-0.215,0.563,0,0.776l1.448,1.442H9.904c-1.629,0-2.958-1.309-2.981-2.927c0.001-0.015,0.002-0.028,0.002-0.044V0.549C6.925,0.245,6.678,0,6.373,0H0.551C0.247,0,0,0.245,0,0.549v13.168c0,0.303,0.247,0.549,0.551,0.549h17.647c0.305,0,0.552-0.246,0.552-0.549V0.549C18.75,0.245,18.503,0,18.198,0z"/></g></g></svg>
							</span>	
							<span>LOGOUT</span>
						</a>
					</li>

					
					
					
				</ul>
			</div>
			
		</div>
	</div>
	
	<input type="hidden" value="<?php echo base_url(); ?>" id="base_url">