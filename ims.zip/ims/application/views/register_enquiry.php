<div class="fs_content_wrapper fs_analytics_wrapper">
	<div class="fs_page_header">
		<div class="row">
			<div class="col-md-6 margin-bottom-20">
				<div class="fs_page_title margin-top-10">
					<h3>Make Admission</h3>
				</div>
			</div>
			
		</div>
	</div>
	
	<div class="row">
		<div class="col-md-12">
			<div class="fs_analytics_table admin" id="ManAgency">
				<form method="post" action="<?php echo base_url('form_action/register_enquiry'); ?>" id="itemForm">
				<input type="hidden"  name="enq_id"  value="<?php echo $enqData['enq_id']; ?>">
				  <input type="hidden"  name="enq_college"  value="<?php echo $enqData['enq_college'];?>">
					<input type="hidden"  name="enq_education"  value="<?php echo $enqData['enq_education']; ?>">
					<div class="form-group">
						<label class="control-label col-sm-3"> Name:</label>
						<div class="col-sm-9">
						  <input type="text" class="form-control blankField require" name="stud_name" placeholder="Name" value="<?php echo $enqData['enq_name']; ?>">
						</div>
					</div>
					<div class="form-group">
						<label class="control-label col-sm-3"> Email:</label>
						<div class="col-sm-9">
						  <input type="email" class="form-control blankField require" name="stud_email" placeholder=" Email" value="<?php echo $enqData['enq_email']; ?>" data-valid="email" data-error="Please enter valid email">
						</div>
					</div>
					<div class="form-group">
						<label class="control-label col-sm-3"> Mobile:</label>
						<div class="col-sm-9">
						  <input type="text" class="form-control blankField require" name="stud_mobile" placeholder=" Mobile" value="<?php echo $enqData['enq_mobile']; ?>" data-valid="mobile" data-error="Please enter valid mobile">
						</div>
					</div>
					
					<div class="form-group ">
						<label class="control-label col-sm-3" for="email">Gender:</label>
						<div class="col-sm-9">
							<select class="form-control require blankField" name="stud_gender">
								<option value="male">Male</option>
								<option value="female">Female</option>
							</select>
						</div>
					</div>
					<div class="form-group ">
						<label class="control-label col-sm-3" for="email">Address:</label>
						<div class="col-sm-9">
							<textarea class="form-control blankField require" name="stud_address" placeholder=" Address"></textarea>
						</div>
					</div>
					<div class="form-group ">
						<label class="control-label col-sm-3" for="email">Courses:</label>
						<div class="col-sm-9">
							<select class="form-control require blankField" name="stud_course" onchange="getBatch(this)">
								<?php
								if(isset($courseList) && !empty($courseList)){
									foreach($courseList as $cData){
										$selected='';
										if($cData['course_id']==$enqData['enq_course']){ $selected='selected';}
										echo '<option value="'.$cData['course_id'].'" '. $selected.'>'.$cData['course_name'].'</option>';
									}
								}
								?>
							</select>
						</div>
					</div>
					<div class="form-group ">
						<label class="control-label col-sm-3" for="email">Batches:</label>
						<div class="col-sm-9">
							<select class="form-control require blankField" name="stud_batch" onchange="getFees(this)">
								<?php
								echo '<option value="" data-fees="">Select Batch</option>';
								if(isset($batchList) && !empty($batchList)){
									foreach($batchList as $cData){
										echo '<option value="'.$cData['batch_id'].'" data-fees="'.$cData['batch_fees'].'">'.$cData['batch_name'].'</option>';
									}
								}
								?>
							</select>
						</div>
					</div>

					<div class="form-group">
						<label class="control-label col-sm-3"> Course Fees:</label>
						<div class="col-sm-9">
						  <input type="text" class="form-control blankField require" name="stud_fees" placeholder="Course Fees" value="" data-valid="number" data-error="Please enter numeric value" readonly>
						</div>
					</div>

					<div class="form-group">
						<label class="control-label col-sm-3"> Deposit Amount:</label>
						<div class="col-sm-9">
						  <input type="text" class="form-control blankField require" name="stud_deposit" placeholder="Deposit" value="" data-valid="number" data-error="Please enter numeric value">
						</div>
					</div>

					<div class="form-group">
						<label class="control-label col-sm-3"> Discount:</label>
						<div class="col-sm-9">
						  <input type="text" class="form-control blankField " name="stud_descount" placeholder=" Discount" value="" data-valid="number" data-error="Please enter numeric value">
						</div>
					</div>

					<div class="form-group">
						<label class="control-label col-sm-3">Joining Date:</label>
						<div class="col-sm-9">
						  <input type="text" class="form-control blankField require datepicker" name="stud_doj" placeholder="Joining Date">
						</div>
					</div>

					<div class="form-group ">
						<label class="control-label col-sm-3" for="email">Note:</label>
						<div class="col-sm-9">
							<textarea class="form-control blankField require" name="stud_note" placeholder=" Note"></textarea>
						</div>
					</div>

				</form>
			</div>
			<div class="col-md-12">
				<button type="button" class="btn btn-default" id="saveButton" target-form="itemForm">Save</button>
			</div>
		</div>
	</div> 
</div>



	