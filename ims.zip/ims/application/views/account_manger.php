<div class="fs_content_wrapper fs_analytics_wrapper">
	<div class="fs_page_header">
		<div class="row">
			<div class="col-md-6 margin-bottom-20">
				<div class="fs_page_title margin-top-10">
					<h3>Account</h3>
				</div>
			</div>
			<div class="col-md-6 text-right">
				<h3>Profit (<span class="amountTotal"></span>)</h3>
			</div>
			
		</div>
	</div>
	
	<div class="row">
	  <div class="col-md-12">
		  <form class="form-inline" method="post" id="SearchForm" target-location="account_data">
			<div class="form-group">
			<input type="hidden" id="formKey" name="formKey" value="0">
				<select  class="form-control" id="ac_month" name="ac_month">
					<option value=''>Select Month</option>
					<option value='01'>Janaury</option>
					<option value='02'>February</option>
					<option value='03'>March</option>
					<option value='04'>April</option>
					<option value='05'>May</option>
					<option value='06'>June</option>
					<option value='07'>July</option>
					<option value='08'>August</option>
					<option value='09'>September</option>
					<option value='10'>October</option>
					<option value='11'>November</option>
					<option value='12'>December</option>
				 </select> 
			  </div>
			  
			  <div class="form-group">
				<select  class="form-control" id="ac_year" name="ac_year">
					<option value=''>Select Year</option>
					<?php
					$current_year=date("Y")-10;
					$limit=$current_year+20;
					for($year=$current_year;$year <= $limit; $year++)
					echo '<option value="'.$year.'">'.$year.'</option>';
					?>
				 </select> 
			  </div>
			  
			
			  <button type="submit" class="btn btn-default" name="search_btn">Search</button>
		</form>
	  </div>
	</div>
	
	<div class="row">
		<div class="col-md-12">
			<div class="fs_analytics_table admin" id="ManAgency">
				<table id="fs_template_table" class="table table-hover dataTable table-striped width-full loadinData" target-location="account_data">
					<thead>
						<tr>
							<th>#</th>
							<th>Description</th>
							<th>Credited</th>
							<th>Debited</th>
							<th>Date</th>
						</tr> 
					</thead>
					<tbody>
						<tr>
							<td colspan="6" align="center">Loading...</td>
						</tr> 
					</tbody>
				</table>
			</div>
		</div>
		
		<div class="col-md-12">
		<div class="fs_pagination">
				
		</div>
		</div>
	</div> 
</div>

