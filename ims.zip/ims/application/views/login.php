<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta content="width=device-width, initial-scale=1.0" name="viewport" />
	<meta name="description"  content=""/>
	<meta name="keywords" content="">
	<meta name="author"  content=""/>
	<meta name="MobileOptimized" content="320">
	
	<title><?php echo $this->common->site_name; ?></title>
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
	<link rel="icon" type="image/ico" href="<?php echo base_url($this->common->site_favicon); ?>" />
	<link href="<?php echo base_url('assets/css/bootstrap.css'); ?>" rel="stylesheet">
	<link href="<?php echo base_url('assets/css/bootstrap_theme.css'); ?>" rel="stylesheet">
	<link href="<?php echo base_url('assets/css/animation.css'); ?>" rel="stylesheet">
	<link href="<?php echo base_url('assets/css/toastr.css'); ?>" rel="stylesheet">
	<link href="<?php echo base_url('assets/css/style.css'); ?>" rel="stylesheet">
	<?php echo $this->common->my_css(); ?>
</head>
<body class="fs_authentication">
<div class="fs_loading_wrapper">
	<div class="cssload-loader"></div>
</div>
<!-- site wrapper start -->
<div class="fs_site_wrapper">	
	<?php print_r($_SESSION); ?>
	<input type="hidden" value="<?php echo base_url(); ?>" id="base_url">
    <div class="fs_authentication_wrapper">
    <div class="fs_logo">
        <img src="<?php echo base_url($this->common->site_logo); ?>" alt="" />
    </div>
    <div class="fs_authentication_inner" id="login-form">
        <div class="fs_head">
            <h3>Login</h3>
        </div>
        <div class="fs_input_wrapper">
            <input type="text" class="form-control require" data-valid="email" data-error="Email should be valid." placeholder="Email address" value="<?php echo (isset($email))?$email:''; ?>" />
        </div>
        <div class="fs_input_wrapper password">
            <input type="password" class="form-control require" placeholder="Password" value="<?php echo (isset($password))?$password:''; ?>" />
        </div>
        <div class="fs_checkbox">
            <input type="checkbox" id="chk_all" <?php echo (isset($email))?'checked':''; ?>>
            <label for="chk_all" >Remember me</label>
        </div>
        <div class="fs_action_wrapper target-submit">
            <a href="javascript:;"  button-type="login" data-target="login-form" class="btn btn_loader target-submit">
                <svg class="button-loader"><circle cx="50%" cy="50%" r="8" class="path"></circle><circle cx="50%" cy="50%" r="8" class="fill"></circle></svg>
                <span>Login</span>
            </a>
            <p class="error_msg"></p>
        </div>
        
    </div>
</div>

</div>
<!-- site wrapper end -->
<!-- site jquery start -->
<script src="<?php echo base_url('assets/js/lib/jquery-3.1.1.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/lib/bootstrap.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/lib/jquery-ui.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/toastr.js'); ?>"></script>
<script>
    $(document).ready(function(){
       $(".fs_loading_wrapper").delay(350).fadeOut("slow");



        $('a[button-type="login"]').click(function(){
            $('.error_msg').text('');
            var base_url = $('#base_url').val();
            var email = $('input[data-valid="email"]').val().trim();
            var pass = $('input[type="password"]').val();
            var email_rex = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/;	
            if(email != ''){
                $('input[data-valid="email"]').parent().removeClass('Error');
                if(pass != ''){
                    $('input[type="password"]').parent().removeClass('Error');
                    if(email_rex.test(email)){
                        $('input[data-valid="email"]').parent().removeClass('Error');
                        var target = $(this);
                        target.addClass('btn_loading');
                        var remember = ($('#chk_all').is(':checked'))?1:0;
                        $.ajax({
                            method : 'post',
                            url : $('#base_url').val()+'welcome/check_login',
                            data : {'email' : email, 'password' : pass , 'remember' :remember}
                        }).done(function(resp){
                            //console.log(resp);
                            if(resp == 1){
                                location.reload();
                            }else if(resp == 2){
                                target.removeClass('btn_loading');
                                toastr.error('Your account has been inactive, contact administrator to active account.' , 'Error');
                            }else if(resp == 3){
                               target.removeClass('btn_loading');
                                toastr.error('Wrong credentials.' , 'Error');
                            }else{
                                target.removeClass('btn_loading');
                                toastr.error('Wrong credentials.' , 'Error');
                            }
                        });
                    }else{ 
                        $('input[data-valid="email"]').parent().addClass('Error');
                        toastr.error('Email should be valid.' , 'Error');
                    }
                }else{
                    $('input[type="password"]').focus();
                    $('input[type="password"]').parent().addClass('Error');
                    toastr.error('You missed out some fields.' , 'Error');	
                }
            }else{
                $('input[data-valid="email"]').focus();
                $('input[data-valid="email"]').parent().addClass('Error');
                toastr.error('You missed out some fields.' , 'Error');
            }
        });
    });
</script>
<!-- site jquery end -->
</body>
</html>