<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Common{
	public $main_domain = 'messageprvt.com';
	public $site_name = 'Institute Management System';	
	public $site_logo = 'assets/images/logo.svg';
	public $site_favicon = 'assets/images/user_logo/favicon.png';
	public $site_primary_color = '#008cd2';  
	public $site_secondary_color = '#282c2f';   
	public $user_id = '';
	public $user_role = '';
	public $user_full_name = '';
	public $user_email = '';
	public $is_agency = '';
	
	
	
	function __Construct(){	
		$this->CI = get_instance();
		if($this->CI->session->userdata('login') == 1){
			$this->user_id = $this->CI->session->userdata('user_id');
			$this->user_role = $this->CI->session->userdata('user_role');
			$this->user_full_name = $this->CI->session->userdata('user_full_name');
			$this->user_email = $this->CI->session->userdata('user_email');
			$this->is_agency = $this->CI->session->userdata('is_agency');
		} 
	}
	
	function my_css(){
		return '<style>
					/* primary color start */
					.fs_campaign:hover,.fs_select_wrapper .bootstrap-select>.dropdown-toggle:active, .fs_select_wrapper .bootstrap-select>.dropdown-toggle:hover, .fs_select_wrapper .bootstrap-select>.dropdown-toggle:focus,.fs_logo_wrapper,.fs_broadcast_option > .panel > .panel_heading.btn[aria-expanded="true"],.fs_select_wrapper .btn-default:active, .fs_select_wrapper .btn-default.active, .fs_select_wrapper .open > .dropdown-toggle.btn-default,.btn, .fs_campaign.automation .content > h3 , .fs_campaign .content.ui-droppable-hover , ul.fs_message_list > li:active , ul.fs_message_list > li.ui-draggable-dragging ,.btn:active, .btn:focus, .btn:hover, .fs_calendar_wrapper .fs_page_title > h3 > span , .msgbtn, .cssload-loader, .fs_set_trigger_wrapper .panel .panel_heading[aria-expanded="true"] > span.title, .fs_set_trigger_wrapper .fs_post_list .fs_post_wrapper.active, .fs_custom_keyword .fs_add_keyword, .fs_sidebar_toggle .toggle_btn, .fs_checkbox [type="checkbox"]:checked + label:after{
						background-color: '.$this->site_primary_color.';
					}

					.datepicker table tr td.active.active, .datepicker table tr td.active.disabled, .datepicker table tr td.active.disabled.active, .datepicker table tr td.active.disabled.disabled, .datepicker table tr td.active.disabled:active, .datepicker table tr td.active.disabled:hover, .datepicker table tr td.active.disabled:hover.active, .datepicker table tr td.active.disabled:hover.disabled, .datepicker table tr td.active.disabled:hover:active, .datepicker table tr td.active.disabled:hover:hover, .datepicker table tr td.active.disabled:hover[disabled], .datepicker table tr td.active.disabled[disabled], .datepicker table tr td.active:active, .datepicker table tr td.active:hover, .datepicker table tr td.active:hover.active, .datepicker table tr td.active:hover.disabled, .datepicker table tr td.active:hover:active, .datepicker table tr td.active:hover:hover, .datepicker table tr td.active:hover[disabled], .datepicker table tr td.active[disabled]{
						background-image: -webkit-gradient(linear,0 0,0 100%,from('.$this->site_primary_color.'),to('.$this->site_primary_color.'));
					}

					.fs_nav_wrapper > ul > li > a:hover, .fs_nav_wrapper > ul > li.active > a,.fs_nav_wrapper > ul > li > a:hover > span.icon svg path, .fs_nav_wrapper > ul > li.active > a > span.icon svg path,.fs_nav_wrapper > ul > li > a:hover, .fs_nav_wrapper > ul > li.active > a, .fs_nav_wrapper > ul > li > a:hover > span.icon svg path, .fs_nav_wrapper > ul > li.active > a > span.icon svg path,.fs_nav_wrapper > ul > li > a:hover, .fs_nav_wrapper > ul > li.active > a, .fs_nav_wrapper > ul > li > a:hover > span.icon svg path, .fs_nav_wrapper > ul > li.active > a > span.icon svg path, .fs_nav_wrapper > ul > li > a:hover, .fs_nav_wrapper > ul > li.active > a, .fs_nav_wrapper > ul > li > a:hover > span.icon svg path, .fs_nav_wrapper > ul > li.active > a > span.icon svg path,.fs_nav_wrapper > ul > li > a:hover > span.icon svg path, .fs_nav_wrapper > ul > li.active > a > span.icon svg path{
						color:'.$this->site_primary_color.';
						stroke: '.$this->site_primary_color.';
						fill: '.$this->site_primary_color.';
					}
					a,.fs_broadcast_option > .panel .fs_input_wrapper > .btn:hover, #fs_duplicate_broadcast .bootstrap-datetimepicker-widget .btn, #fs_schedule_broadcast_popup .bootstrap-datetimepicker-widget .btn{
						color:'.$this->site_primary_color.';
					}
					.fs_input_wrapper .form-control:focus, #fs_schedule_broadcast_popup .fs_radio_wrapper label input:focus, .fs_authentication_inner .fs_input_wrapper .form-control:focus{
						border-color: '.$this->site_primary_color.';
					}
					.fs_radio_wrapper [type="radio"]:checked + label:after{
						box-shadow: 0px 0px 0px 5px '.$this->site_primary_color.';	
					}
					/* primary color end */

					/* Secondary color start */
					.fs_sidebar_wrapper, .fs_select_wrapper .bootstrap-select.btn-group .dropdown-menu li a:focus, .fs_select_wrapper .bootstrap-select.btn-group .dropdown-menu li a:hover, .fs_broadcast_option > .panel > .panel_heading.btn , .fs_authentication , .error_page , .fs_dropdown_wrapper > ul > li > a:hover{
						background-color: '.$this->site_secondary_color.';
					}
					/* Secondary color end */
				</style>';
	}
	
	
	
	/*function send_mail($name , $email , $subject , $message){
		$ch = curl_init(); 
		curl_setopt($ch,CURLOPT_URL, 'https://mandrillapp.com/api/1.0/messages/send-template.json');
		curl_setopt($ch,CURLOPT_POSTFIELDS, '{
			"key":"YZlSLI5sBCKr_ndCOnFV1g",
			"template_name":"Feel Social",
			"template_content":[
				{"name":"messagebody","content":"'.$message.'"}
			 ],
			 "message":{"to":[
				{"email":"'.$email.'",
				"name":"'.$name.'",
				"type":"to"}
			],
			"subject":"'.$subject.'"
			},
			"async":false,
			"ip_pool":"Main Pool"
		}');
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		return curl_exec($ch);
	}*/
	
	
}
