<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Search_data extends CI_Controller {

    public function __Construct(){
		parent::__Construct();
		if($this->session->userdata('login') != 1){
			redirect(base_url());
		}
		$this->load->library('ci_pagination'); 
	}

	
	
	
	/**************************************************************/
	/***************** Manage Course Section Start ************/
	/**************************************************************/
	
	
	public function course_data(){
		$cond="	course_id!=''";
		
		$order = array('course_id' , 'DESC');
		$currentPosition = (isset($_POST['formKey']))?$_POST['formKey']:0;
		$courseData=$this->my_model->select_data('*' , 'courses' , $cond, array('10' , $currentPosition),$order);
		$countTotal = $this->my_model->aggregate_data('courses' , 'course_id' , 'COUNT' ,$cond,'',$like='');
        $paginationButton = $this->ci_pagination->pagination_data($countTotal, $currentPosition , '10');
		$respData = '';
		$cnt = 1;
		if(!empty($courseData)){
			foreach($courseData as $cData){
				$respData .= '<tr data-target="'.$cData['course_id'].'">
									<td>'.$cnt++.'</td>
									<td>'.$cData['course_name'].'</td>
									<td>'.$cData['course_duration'].' '.$cData['course_duration_type'].'</td>
									<td>
										<a title="Edit" class="EditMyCourse"><i class="fa fa-edit"></i></a> 
									</td>
							</tr>';
			}
		}else{
			$respData .= '<tr><td colspan="3" align="center">Oops! Data not available.</td></tr>';
		}		
		echo json_encode(array('status' => 1 , 'respData' => $respData,'pagilink'=>$paginationButton,'countTotal'=>$countTotal), JSON_UNESCAPED_SLASHES);
	}
	
	/**************************************************************/
	/****************** Manage Course Section End *************/
	/**************************************************************/
	
	
	/**************************************************************/
	/***************** Manage Course Section Start ************/
	/**************************************************************/
	
	
	public function user_data(){
		$user_role='';
		if($this->session->userdata('req_user_role')){	
		$user_role=$this->session->userdata('req_user_role');
		$this->session->unset_userdata('req_user_role');
		}
		$cond="user_role!='1'";
		if($user_role!=''){
			if($user_role==4){
				$cond .= "AND user_role = 4";
			}else{
				$cond .= "AND user_role !=4 ";
			}
		}
		if(isset($_POST['formKey'])){
			if($_POST['user_full_name']!=''){
			   $user_full_name=$_POST['user_full_name'];
			   $cond .= "AND user_full_name = '$user_full_name' "; 
			}
			if($_POST['user_email']!=''){
			   $user_email=$_POST['user_email'];
			   $user_email .= "AND user_email = '$user_email' "; 
			}
			if($_POST['mobile']!=''){
			   $mobile=$_POST['mobile'];
			    $cond .="AND mobile = '$mobile' "; 
			}
			if($_POST['user_role']!=''){
			   $user_role=$_POST['user_role'];
			   if($user_role==4){
					$cond .= "AND user_role = $user_role ";
				}else{
					$cond .= "AND user_role !=4 ";
					$cond .= "AND user_role !=1 ";
				}
              			   
			}
			$doj='';
			$search_year=date('Y');
			if($_POST['user_year']!=''){
			   $search_year=$_POST['user_year'];
			   $doj = "AND doj LIKE '%$search_year%' "; 
			}
			if($_POST['user_month']!=''){
			   $search_year=$search_year.'-'.$_POST['user_month'];
			   $doj = "AND doj LIKE '%$search_year%' "; 
			}
			$cond .=$doj;
		}
		$order = array('user_id' , 'DESC');
		$currentPosition = (isset($_POST['formKey']))?$_POST['formKey']:0;
		$userData=$this->my_model->select_data('*' , 'user' , $cond, array('10' , $currentPosition),$order);
		$countTotal = $this->my_model->aggregate_data('user' , 'user_id' , 'COUNT' ,$cond,'',$like='');
        $paginationButton = $this->ci_pagination->pagination_data($countTotal, $currentPosition , '10');
		
		
		$respData = '';
		$cnt = 1;
		if(!empty($userData)){
			$editlink='<a title="Edit"  class="EditMyUser"><i class="fa fa-edit"></i></a>'; 
			foreach($userData as $cData){
				if($cData['user_role']==4){
				 $href='href="'.base_url().'commons/single_student/'.$cData['user_id'].'"';
				 $editlink='<a title="View"  '.$href.'  ><i class="fa fa-eye"></i></a>';	
				}
				$respData .= '<tr data-target="'.$cData['user_id'].'">
									<td>'.$cnt++.'</td>
									<td>'.$cData['user_full_name'].'</td>
									<td>'.$cData['mobile'].'</td>
									<td>'.$cData['user_email'].'</td>
									<td>'.date("d-M-y", strtotime($cData['doj'])).'</td>
									<td>'.$editlink.'</td>
							</tr>';
			}
		}else{
			$respData .= '<tr><td colspan="5" align="center">Oops! Data not available.</td></tr>';
		}		
		echo json_encode(array('status' => 1 , 'respData' => $respData,'pagilink'=>$paginationButton,'countTotal'=>$countTotal), JSON_UNESCAPED_SLASHES);
	}
	
	/**************************************************************/
	/****************** Manage Course Section End *************/
	/**************************************************************/
	
	


	/**************************************************************/
	/***************** Manage Batch Section Start ************/
	/**************************************************************/
	
	
	public function batch_data(){
		$cond="batch_id!=''";
		if(isset($_POST['formKey'])){
			if($_POST['batch_name']!=''){
			   $batch_name=$_POST['batch_name'];
			   $cond .= "AND batch_name = '$batch_name' "; 
			}
			if($_POST['batch_course']!=''){
			   $batch_course=$_POST['batch_course'];
			   $batch_course .= "AND batch_course = '$batch_course' "; 
			}
			
			if($_POST['batch_status']!=''){
			   $batch_status=$_POST['batch_status'];
			   $cond .= "AND batch_status = $batch_status "; 
			}
		
		}
		
		$join_array =
        array('multiple',
	     array(
		   	array('courses','courses.course_id = batches.batch_course'),
		   	)
	   	);
		
		$order = array('batch_id' , 'DESC');
		$currentPosition = (isset($_POST['formKey']))?$_POST['formKey']:0;
		$batchData=$this->my_model->select_data('batches.*,courses.course_name' , 'batches' , $cond, array('10' , $currentPosition),$order,'',$join_array);
		
		$countTotal = $this->my_model->aggregate_data('batches' , 'batch_id' , 'COUNT' ,$cond,$join_array);
        $paginationButton = $this->ci_pagination->pagination_data($countTotal, $currentPosition , '10');
		$respData = '';
		$cnt = 1;
		if(!empty($batchData)){
			foreach($batchData as $cData){
				$batch_status = ($cData['batch_status'] == 1) ? '<span class="label label-success">Active</span>' : '<span class="label label-danger">InActive</span>';
			
				$respData .= '<tr data-target="'.$cData['batch_id'].'">
									<td>'.$cnt++.'</td>
									<td>'.$cData['batch_name'].'</td>
									<td>'.$cData['course_name'].'</td>
									<td>'.$cData['batch_fees'].'</td>
									<td>'.date("d-M-y", strtotime($cData['batch_start_date'])).'</td>
									<td>'.$cData['batch_time'].'</td>
									<td>'.$batch_status.'</td>
									<td>
										<a title="Edit" class="EditMyBatch"><i class="fa fa-edit"></i></a> 
									</td>
							</tr>';
			}
		}else{
			$respData .= '<tr><td colspan="7" align="center">Oops! Data not available.</td></tr>';
		}		
		echo json_encode(array('status' => 1 , 'respData' => $respData,'pagilink'=>$paginationButton,'countTotal'=>$countTotal), JSON_UNESCAPED_SLASHES);
	}
	public function getBatch(){
        if(isset($_POST['courseId'])) {
            $subCate  = $this->my_model->select_data('*' , 'batches' , array('batch_course'=>$_POST['courseId'],'batch_status'=>1) , '', '' , '' , '');
            $str = '<option value="" data-fees="">Select Batch</option>';
            if(!empty($subCate)) {
                foreach($subCate as $solo_subCate) {
                    $str .= '<option value="'.$solo_subCate['batch_id'].'"  data-fees="'.$solo_subCate['batch_fees'].'">'.$solo_subCate['batch_name'].'</option>';
                }
            }
            else {
                $str .= '<option value="">Nothing found</option>';
            }
            echo $str;
        }
        else {
	        echo '0';
	    }
	    die();
    }
    public function getFees(){
        if(isset($_POST['courseId'])) {
            $courseDetail  = $this->my_model->select_data('course_fees' , 'courses' , array('course_id'=>$_POST['courseId']) , '', '' , '' , '');
            echo $courseDetail[0]['course_fees']; 
        }
        else {
	        echo '0';
	    }
	    die();
    }


	
	
	/**************************************************************/
	/****************** Manage Batch Section End *************/
	/**************************************************************/



	/**************************************************************/
	/***************** Manage Enquiry Section Start ************/
	/**************************************************************/
	
	
	public function enquiry_data(){
		$cond="enq_id!='0'";
		if(isset($_POST['formKey'])){
			if($_POST['enq_name']!=''){
			   $enq_name=$_POST['enq_name'];
			   $cond .= "AND enq_name LIKE '%$enq_name%' "; 
			}
			if($_POST['enq_email']!=''){
			   $enq_email=$_POST['enq_email'];
			   $cond .= "AND enq_email LIKE '%$enq_email%' "; 
			}
			if($_POST['enq_mobile']!=''){
			   $enq_mobile=$_POST['enq_mobile'];
			   $cond .= "AND enq_mobile = '$enq_mobile' "; 
			}
			if($_POST['enq_status']!=''){
			   $enq_status=$_POST['enq_status'];
			   $cond .= "AND enq_status = $enq_status "; 
			}
		}
		$order = array('enq_id' , 'Desc');
		$currentPosition = (isset($_POST['formKey']))?$_POST['formKey']:0;
		$enqData=$this->my_model->select_data('*' , 'enquiries' , $cond, array('10' , $currentPosition),$order);
		
		$countTotal = $this->my_model->aggregate_data('enquiries' , 'enq_id' , 'COUNT' ,$cond,'',$like='');
        $paginationButton = $this->ci_pagination->pagination_data($countTotal, $currentPosition , '10');
		$respData = '';
		$cnt = 1;
		if(!empty($enqData)){
			foreach($enqData as $cData){
				if($cData['enq_status']==0){
					$status='<span class="label label-warning">InProgress</span> <a href="'.base_url().'commons/register_enquiry/'.$cData['enq_id'].'" class="btn-warning"> Register This User</a>';
				}else if($cData['enq_status']==1){
					$status='<span class="label label-success">Registered</span>';
				}else{
					$status='<span class="label label-danger">Blocked</span>';
				}
				$respData .= '<tr data-target="'.$cData['enq_id'].'">
									<td>'.$cnt++.'</td>
									<td>'.$cData['enq_name'].'</td>
									<td>'.$cData['enq_email'].'</td>
									<td>'.$cData['enq_mobile'].'</td>
									<td>'.date("d-M-y", strtotime($cData['enq_followdate'])).'</td>
									<td>'.$status.'</td>
									<td>
										<a title="Edit" class="EditMyEnquiry"><i class="fa fa-edit"></i></a> 
										<a href="'.base_url().'commons/followup/'.$cData['enq_id'].'" title="Follow Up" ><i class="fa fa-arrows-v" aria-hidden="true"></i></a>
									</td>
							</tr>';
			}
		}else{
			$respData .= '<tr><td colspan="6" align="center">Oops! Data not available.</td></tr>';
		}		
		echo json_encode(array('status' => 1 , 'respData' => $respData,'pagilink'=>$paginationButton,'countTotal'=>$countTotal), JSON_UNESCAPED_SLASHES);
	}
	
	
	/**************************************************************/
	/****************** Manage Enquiry Section End *************/
	/**************************************************************/
	

	public function followup_data($enq_id=''){
		$join_array =
        array('multiple',
	     array(
		   	array('enquiries','enquiries.enq_id = followup.follow_enqid'),
		   	array('user','user.user_id = followup.follow_userid')
		   	)
	   	);
	    $followup_detail= $this->my_model->select_data('*' , 'followup' , array('follow_enqid'=>$enq_id) , '' , array('follow_id' , 'DESC'),'',$join_array);
		$respData = '';
		$cnt = 1;
		if(!empty($followup_detail)){
			foreach($followup_detail as $cData){
				if($cData['follow_status']==0){
					$status='<span class="label label-success">Continue</span>';
				}else{
					$status='<span class="label label-danger">Blocked</span>';
				}
				$respData .= '<tr data-target="'.$cData['enq_id'].'">
									<td>'.$cnt++.'</td>
									
									<td>'.date("d-M-y", strtotime($cData['follow_date'])).'</td>
									<td>'.date("d-M-y", strtotime($cData['follow_next_date'])).'</td>
									<td>'.$cData['follow_mode'].'</td>
									<td>'.$cData['follow_feedback'].'</td>
									<td>'.$cData['user_full_name'].'</td>
									<td>'.$status.'</td>
									<td>'.$cData['follow_note'].'</td>
							</tr>';
			}
		}else{
			$respData .= '<tr><td colspan="8" align="center">Oops! Data not available.</td></tr>';
		}		
		echo json_encode(array('status' => 1 , 'respData' => $respData), JSON_UNESCAPED_SLASHES);
	}
	
	/**************************************************************/
	/****************** Manage Enquiry Section End *************/
	/**************************************************************/
	
	
	/**************************************************************/
	/***************** Manage Expenses Type Section Start ************/
	/**************************************************************/
	
	
	public function expensestype_data(){
		$join_array ='';
		$expensestypeData = $this->my_model->select_data('*' , 'expanses_add' , '' , '' );
		$respData = '';
		$cnt = 1;
		if(!empty($expensestypeData)){
			foreach($expensestypeData as $cData){
				
				$respData .= '<tr data-target="'.$cData['expense_add_id'].'">
									<td>'.$cnt++.'</td>
									<td>'.$cData['expense_name'].'</td>
									
							</tr>';
			}
		}else{
			$respData .= '<tr><td colspan="1" align="center">Oops! Data not available.</td></tr>';
		}		
		echo json_encode(array('status' => 1 , 'respData' => $respData), JSON_UNESCAPED_SLASHES);
	}
	public function getExpensestype(){
        if(isset($_POST['courseId'])) {
            $subCate  = $this->my_model->select_data('*' , 'batches' , array('batch_course'=>$_POST['courseId'],'batch_status'=>1) , '', '' , '' , '');
            $str = '';
            if(!empty($subCate)) {
                foreach($subCate as $solo_subCate) {
                    $str .= '<option value="'.$solo_subCate['batch_id'].'">'.$solo_subCate['batch_name'].'</option>';
                }
            }
            else {
                $str .= '<option value="">Nothing found</option>';
            }
            echo $str;
        }
        else {
	        echo '0';
	    }
	    die();
    }


	
	
	/**************************************************************/
	/****************** Manage Expenses Type Section  End *************/
	
	
	/**************************************************************/
	/***************** Manage Expenses Section Start ************/
	/**************************************************************/
	
	
	public function expanses_data(){
		$cond="exp_id!=''";
		$registration_date='';
		$search_year=date('Y');
		if(isset($_POST['formKey'])){
			
	    if($_POST['exp_type']!=''){
		   $exp_type=$_POST['exp_type'];
		   $cond.= "AND exp_type = $exp_type "; 
		}
		if($_POST['exp_year']!=''){
		   $search_year=$_POST['exp_year'];
		   $registration_date = "AND exp_date LIKE '%$search_year%' "; 
		}
		if($_POST['exp_month']!=''){
		   $search_year=$search_year.'-'.$_POST['exp_month'];
		   $registration_date = "AND exp_date LIKE '%$search_year%' "; 
		}
		$cond .=$registration_date;
	}	
		$join_array =
        array('multiple',
	     array(
		   	array('expanses_add','expanses_add.expense_add_id= expanses.exp_type'),
		   	)
	   	);
		
		$order = array('exp_id' , 'DESC');
		$currentPosition = (isset($_POST['formKey']))?$_POST['formKey']:0;
		$countTotal = $this->my_model->aggregate_data('expanses' , 'exp_id' , 'COUNT' ,$cond,$join_array);
		$amountTotal = $this->my_model->aggregate_data('expanses' , 'exp_amount' , 'SUM' ,$cond,$join_array);
        $paginationButton = $this->ci_pagination->pagination_data($countTotal, $currentPosition , '10');
		$expensesData=$this->my_model->select_data('*' , 'expanses' , $cond, array('10' , $currentPosition),$order,'',$join_array);
		
		$respData = '';
		$cnt = 1;
		if(!empty($expensesData)){
			foreach($expensesData as $cData){
				
				$respData .= '<tr data-target="'.$cData['exp_id'].'">
									<td>'.$cnt++.'</td>
									<td>'.$cData['exp_name'].'</td>
									<td>'.$cData['exp_amount'].'</td>
									<td>'.$cData['exp_method'].'</td>
									<td>'.date("d-M-y", strtotime($cData['exp_date'])).'</td>
									<td>'.$cData['expense_name'].'</td>
									
									<td>
										<a title="Edit" class="EditMyExpenses"><i class="fa fa-edit"></i></a> 
									</td>
							</tr>';
			}
		}else{
			$respData .= '<tr><td colspan="5" align="center">Oops! Data not available.</td></tr>';
		}		
		echo json_encode(array('status' => 1 , 'respData' => $respData,'pagilink'=>$paginationButton,'countTotal'=>$countTotal,'amountTotal'=>$amountTotal), JSON_UNESCAPED_SLASHES);
	}

	
	
	/**************************************************************/
	/****************** Manage Expenses Section End *************/
	/**************************************************************/
	
	/**************************************************************/
	/***************** Manage Fees Section Start ************/
	/**************************************************************/
	
	
	public function feesmanager_data(){
		$cond="	stud_id!=''";
		
		$join_array =
        array('multiple',
	     array(
		   	array('user','user.user_id= student_course.stud_user_id'),
		   	)
	   	);
	
		
		
		$order = array('stud_doj' , 'DESC');
		$currentPosition = (isset($_POST['formKey']))?$_POST['formKey']:0;
		$stucourseData=$this->my_model->select_data('*' , 'student_course' , $cond, array('10' , $currentPosition),$order,'',$join_array);
		$countTotal = $this->my_model->aggregate_data('student_course' , 'stud_id' , 'COUNT' ,$cond,$join_array);
        $paginationButton = $this->ci_pagination->pagination_data($countTotal, $currentPosition , '10');
		
		$respData = '';
		$cnt = 1;
		if(!empty($stucourseData)){
			foreach($stucourseData as $cData){
				 $href='href="'.base_url().'commons/single_student/'.$cData['user_id'].'"';
				$respData .= '<tr data-target="'.$cData['stud_id'].'">
									<td>'.$cnt++.'</td>
									<td>'.$cData['user_full_name'].'</td>
									<td>'.$cData['mobile'].'</td>
									<td>'.$cData['user_email'].'</td>
									<td><span class="label label-danger">'.$cData['stud_remaining'].'</span></td>
									<td>
										<a '.$href.' title="Add Fees" class="EditMyExpenses"><i class="fa fa-plus"></i></a> 
									</td>
							</tr>';
			}
		}else{
			$respData .= '<tr><td colspan="5" align="center">Oops! Data not available.</td></tr>';
		}		
		echo json_encode(array('status' => 1 , 'respData' => $respData,'pagilink'=>$paginationButton,'countTotal'=>$countTotal), JSON_UNESCAPED_SLASHES);
	}
    

	public function fees_data(){
		$cond="fess_id!=''";
		$registration_date='';
		$search_year=date('Y');
		if(isset($_POST['formKey'])){
		if($_POST['user_full_name']!=''){
		   $user_full_name=$_POST['user_full_name'];
		   $cond .= "AND user_full_name = '$user_full_name' "; 
		}
		if($_POST['user_email']!=''){
		   $user_email=$_POST['user_email'];
		   $user_email .= "AND user_email = '$user_email' "; 
		}
		if($_POST['fess_year']!=''){
		   $search_year=$_POST['fess_year'];
		   $registration_date = "AND fess_date LIKE '%$search_year%' "; 
		}
		if($_POST['fess_month']!=''){
		   $search_year=$search_year.'-'.$_POST['fess_month'];
		   $registration_date = "AND fess_date LIKE '%$search_year%' "; 
		}
		$cond .=$registration_date;
	}	
		
		$join_array =
        array('multiple',
	     array(
		   	array('user','user.user_id = fees.fees_uid'),
		   	)
	   	);
		
		$order = array('fess_id' , 'DESC');
		$currentPosition = (isset($_POST['formKey']))?$_POST['formKey']:0;
		$countTotal = $this->my_model->aggregate_data('fees' , 'fess_id' , 'COUNT' ,$cond,$join_array);
		$amountTotal = $this->my_model->aggregate_data('fees' , 'fess_amount' , 'SUM' ,$cond,$join_array);
        $paginationButton = $this->ci_pagination->pagination_data($countTotal, $currentPosition , '10');

		$feesData=$this->my_model->select_data('*' , 'fees' , $cond, array('10' , $currentPosition),$order,'',$join_array);
		$respData = '';
		$cnt = 1;
		if(!empty($feesData)){
			foreach($feesData as $cData){
				 $href='href="'.base_url().'commons/single_student/'.$cData['user_id'].'"';
				$respData .= '<tr data-target="'.$cData['fess_id'].'">
									<td>'.$cnt++.'</td>
									<td>'.$cData['user_full_name'].'</td>
									<td>'.$cData['mobile'].'</td>
									<td>'.$cData['fess_amount'].'</td>
                                    <td>'.date("d-M-y", strtotime($cData['fess_date'])).'</td>
									 <td><a '.$href.' title="Add Fees" class="EditMyExpenses"><i class="fa fa-eye"></i></a> 
									</td>
							</tr>';
			}
		}else{
			$respData .= '<tr><td colspan="5" align="center">Oops! Data not available.</td></tr>';
		}		
		
		echo json_encode(array('status' => 1 , 'respData' => $respData,'pagilink'=>$paginationButton,'countTotal'=>$countTotal,'amountTotal'=>$amountTotal), JSON_UNESCAPED_SLASHES);
	}
	
	
	/**************************************************************/
	/****************** Manage Fees Section End *************/
	/**************************************************************/
	
	/**************************************************************/
	/****************** Manage Account Section End *************/
	/**************************************************************/
	
	
	function account_data(){
		$cond="ac_id!=''";
		$fessCond="fess_id!=''";
		$expCond="exp_id!=''";
		$salCond="sal_id!=''";
		$registration_date='';
		$registration_datefees='';
		$registration_dateexp ='';
		$registration_datesal='';
		$search_year=date('Y');
		if(isset($_POST['formKey'])){
		if($_POST['ac_year']!=''){
		   $search_year=$_POST['ac_year'];
		   $registration_date = "AND ac_date LIKE '%$search_year%' "; 
		   $registration_datefees = "AND fess_date LIKE '%$search_year%' ";
		   $registration_dateexp = "AND exp_date LIKE '%$search_year%' ";
		   $registration_datesal = "AND sal_date LIKE '%$search_year%' ";  
		}
		if($_POST['ac_month']!=''){
		   $search_year=$search_year.'-'.$_POST['ac_month'];
		   $registration_date = "AND ac_date LIKE '%$search_year%' "; 
		   $registration_datefees = "AND fess_date LIKE '%$search_year%' ";
           $registration_datesal = "AND sal_date LIKE '%$search_year%' "; 		   
		}
		$cond .=$registration_date;
		$fessCond .=$registration_datefees;
		$expCond .=$registration_dateexp;
		$salCond .=$registration_datesal;
	}	
		
		
		
		$order = array('ac_date' , 'DESC');
		$currentPosition = (isset($_POST['formKey']))?$_POST['formKey']:0;
		$countTotal = $this->my_model->aggregate_data('account' , 'ac_id' , 'COUNT' ,$cond,'');
		
        $paginationButton = $this->ci_pagination->pagination_data($countTotal, $currentPosition , '10');
        $accountData=$this->my_model->select_data('*' , 'account' ,$cond, array('10' , $currentPosition),$order,'');
		
		$feesTotal = $this->my_model->aggregate_data('fees' , 'fess_amount' , 'SUM' ,$fessCond);
		$expTotal = $this->my_model->aggregate_data('expanses' , 'exp_amount' , 'SUM' ,$expCond);
		$salTotal = $this->my_model->aggregate_data('salary' , 'sal_amount' , 'SUM' ,$salCond);
		$amountTotal =$feesTotal-$expTotal-$salTotal;
		$respData = '';
		$cnt = 1;
		if(!empty($accountData)){
			foreach($accountData as $cData){
				$ac_type=$cData['ac_type'];
				$description='';
				if($ac_type==1){
					$feesDetail=$this->my_model->select_data('*' , 'fees' ,array('fess_id'=>$cData['ac_type_id']),1);
					$amount=$feesDetail[0]['fess_amount'];
					$href='href="'.base_url().'commons/single_student/'.$feesDetail[0]['fees_uid'].'"';
					$description='Fees Deposit <a '.$href.' title="View Fees" ><i class="fa fa-eye">';
					
				}else if($ac_type==2){
					$expDetail=$this->my_model->select_data('*' , 'expanses' ,array('exp_id'=>$cData['ac_type_id']),1);
					$amount=$expDetail[0]['exp_amount'];
					
					$description=$expDetail[0]['exp_name'];
				}else if($ac_type==3){
				  $join_array = array('multiple',array(array('user','salary.sal_uid = user.user_id'),));
                   $salDetail=$this->my_model->select_data('salary.sal_amount,user.user_full_name' , 'salary' ,array('sal_id'=>$cData['ac_type_id']),1,'','',$join_array);
                   $amount=$salDetail[0]['sal_amount'];
                   $description=$salDetail[0]['user_full_name'].' Salary';
				}
				$respData .= '<tr data-target="'.$cData['ac_id'].'">
									<td>'.$cnt++.'</td>
									<td>'.$description.'</td>';
									if($ac_type==1){
				$respData.=         '<td>'.$amount.'</td>
									<td>-</td>';	
									}else if($ac_type==2){
				$respData.=         '<td>-</td>
									<td>'.$amount.'</td>';
				                    }else if($ac_type==3){
				$respData.=         '<td>-</td>
									<td>'.$amount.'</td>';
									} 
									
				$respData.= '       <td>'.date("d-M-y", strtotime($cData['ac_date'])).'</td>
				              </tr>';
			}
		}else{
			$respData .= '<tr><td colspan="4" align="center">Oops! Data not available.</td></tr>';
		}		
		echo json_encode(array('status' => 1 , 'respData' => $respData,'pagilink'=>$paginationButton,'countTotal'=>$countTotal,'amountTotal'=>$amountTotal), JSON_UNESCAPED_SLASHES);
	}
	
	/**************************************************************/
	/****************** Manage Account Section End *************/
	/**************************************************************/



	/**************************************************************/
	/***************** Manage College Section Start ************/
	/**************************************************************/
	
	
	public function college_data(){
		$cond="	clg_id!=''";
		
		$order = array('clg_id' , 'DESC');
		$currentPosition = (isset($_POST['formKey']))?$_POST['formKey']:0;
		$collegeData=$this->my_model->select_data('*' , 'college' , $cond, array('10' , $currentPosition),$order);
		$countTotal = $this->my_model->aggregate_data('college' , 'clg_id' , 'COUNT' ,$cond,'',$like='');
        $paginationButton = $this->ci_pagination->pagination_data($countTotal, $currentPosition , '10');
		$respData = '';
		$cnt = 1;
		if(!empty($collegeData)){
			foreach($collegeData as $cData){
				$respData .= '<tr data-target="'.$cData['clg_id'].'">
									<td>'.$cnt++.'</td>
									<td>'.$cData['clg_name'].'</td>
									<td>
										<a title="Edit" class="EditMyCollege"><i class="fa fa-edit"></i></a> 
									</td>
							</tr>';
			}
		}else{
			$respData .= '<tr><td colspan="3" align="center">Oops! Data not available.</td></tr>';
		}		
		echo json_encode(array('status' => 1 , 'respData' => $respData,'pagilink'=>$paginationButton,'countTotal'=>$countTotal), JSON_UNESCAPED_SLASHES);
	}
	
	/**************************************************************/
	/****************** Manage College Section End *************/
	/**************************************************************/


	/**************************************************************/
	/***************** Manage Education Section Start ************/
	/**************************************************************/
	
	
	public function education_data(){
		$cond="	edu_id!=''";
		
		$order = array('edu_id' , 'DESC');
		$currentPosition = (isset($_POST['formKey']))?$_POST['formKey']:0;
		$educationData=$this->my_model->select_data('*' , 'education' , $cond, array('10' , $currentPosition),$order);
		$countTotal = $this->my_model->aggregate_data('education' , 'edu_id' , 'COUNT' ,$cond,'',$like='');
        $paginationButton = $this->ci_pagination->pagination_data($countTotal, $currentPosition , '10');
		$respData = '';
		$cnt = 1;
		if(!empty($educationData)){
			foreach($educationData as $cData){
				$respData .= '<tr data-target="'.$cData['edu_id'].'">
									<td>'.$cnt++.'</td>
									<td>'.$cData['edu_name'].'</td>
									<td>
										<a title="Edit" class="EditMyEducation"><i class="fa fa-edit"></i></a> 
									</td>
							</tr>';
			}
		}else{
			$respData .= '<tr><td colspan="3" align="center">Oops! Data not available.</td></tr>';
		}		
		echo json_encode(array('status' => 1 , 'respData' => $respData,'pagilink'=>$paginationButton,'countTotal'=>$countTotal), JSON_UNESCAPED_SLASHES);
	}
	
	/**************************************************************/
	/****************** Manage Education Section End *************/
	/**************************************************************/


	/**************************************************************/
	/***************** Manage Salary Section Start ************/
	/**************************************************************/
	
	public function salary_data(){
		$cond="sal_id!=''";
		if(isset($_POST['formKey'])){
			if($_POST['uid']!=''){
			   $sal_uid=$_POST['uid'];
			   $cond .= "AND sal_uid = '$sal_uid' "; 
			}
			
		}
		
		$join_array =
        array('multiple',
	     array(
		   	array('user','salary.sal_uid = user.user_id'),
		   	)
	   	);
		
		$order = array('sal_date' , 'DESC');
		$currentPosition = (isset($_POST['formKey']))?$_POST['formKey']:0;
		$salData=$this->my_model->select_data('salary.*,user.user_full_name' , 'salary' , $cond, array('10' , $currentPosition),$order,'',$join_array);
		
		$countTotal = $this->my_model->aggregate_data('salary' , 'sal_id' , 'COUNT' ,$cond,$join_array);
        $paginationButton = $this->ci_pagination->pagination_data($countTotal, $currentPosition , '10');
		$respData = '';
		$cnt = 1;
		if(!empty($salData)){
			foreach($salData as $cData){
				
			
				$respData .= '<tr data-target="'.$cData['sal_id'].'">
									<td>'.$cnt++.'</td>
									<td>'.$cData['user_full_name'].'</td>
									<td>'.$cData['sal_amount'].'</td>
									<td>'.date("d-M-y", strtotime($cData['sal_date'])).'</td>
									<td>
										<a title="Edit" class="EditMySalary"><i class="fa fa-edit"></i></a> 
									</td>
							</tr>';
			}
		}else{
			$respData .= '<tr><td colspan="5" align="center">Oops! Data not available.</td></tr>';
		}		
		echo json_encode(array('status' => 1 , 'respData' => $respData,'pagilink'=>$paginationButton,'countTotal'=>$countTotal), JSON_UNESCAPED_SLASHES);
	}
	
	/**************************************************************/
	/****************** Manage Salary Section End *************/
	/**************************************************************/



	
	
}