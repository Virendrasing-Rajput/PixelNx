<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function __Construct(){
		parent::__Construct();
		if($this->session->userdata('login') == 1){
			redirect(base_url('dashboard'));
		}
	}

	public function index(){
		 $this->login();
	}

	public function login(){
		$data=array();
		if($this->input->cookie('email')){
			$data['email'] = $this->input->cookie('email');
			$data['password'] = $this->input->cookie('pass');
		}
      	$this->load->view('login' , $data);
	}

	public function check_login(){
       if(isset($_POST['email']) && isset($_POST['password'])){
			$check_user = $this->my_model->select_data('*' , 'user' , array('user_email' => $_POST['email'] , 'user_password' => md5($_POST['password'])));
			if(!empty($check_user)){
                if($check_user['0']['status'] == 1){
					$user_sess = array(
									'login' =>  1,
									'user_id' =>  $check_user['0']['user_id'],
									'user_role' =>  $check_user['0']['user_role'],
									'user_full_name' =>  $check_user['0']['user_full_name'],
									'user_email' =>  $check_user['0']['user_email'],
									);
					$this->session->set_userdata($user_sess);
					if(isset($_POST['remember']) && $_POST['remember'] == 1){
						setcookie('email', $_POST['email'], time() + (86400 * 30), "/"); // 86400 = 1 day
						setcookie('pass', $_POST['password'], time() + (86400 * 30), "/"); // 86400 = 1 day
					}else{
						setcookie('email', '', time() - (86400 * 30), "/"); // 86400 = 1 day
						setcookie('pass', '', time() - (86400 * 30), "/"); // 86400 = 1 day
					}
					echo 1;	
				}else{
					echo 2;
				}	
			}else{
				echo 3;
			}
		}else{
			echo 0;
		}
	}
}
