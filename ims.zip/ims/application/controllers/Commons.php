<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Commons extends CI_Controller {

	public function __Construct(){
		parent::__Construct();
		// if($this->session->userdata('login') == 1){
			// redirect(base_url('dashboard'));
		// }else if($this->session->userdata('login') == 2){
			// redirect(base_url('add_patient'));
		// }
	}

	public function index(){
		 $this->dashboard();
	}

   public function enquiry_manager(){
        $data['title']='Enquiry';	   
		$data['page'] = 'enquiry_manager';
		$data['enquiryCount'] = $this->my_model->aggregate_data('enquiries' , 'enq_id' , 'COUNT');
		$data['courseList'] = $this->my_model->select_data('course_id,course_name' , 'courses' , '' , '' , array('course_id' , 'DESC'));
		
		$data['collegeList'] = $this->my_model->select_data('*' , 'college' , '' , '' , array('clg_name' , 'ASC'));
		$data['educationList'] = $this->my_model->select_data('*' , 'education' , '' , '' , array('edu_name' , 'ASC'));
      	$this->load->view('include/header' , $data);
      	$this->load->view('include/header' , $data);
      	$this->load->view('enquiry_manager' , $data);
      	$this->load->view('include/footer' , $data);
	}
    public function register_enquiry($enq_id=''){
	  $data['title']='Register';	
      $enqData = $this->my_model->select_data('*' , 'enquiries' , array('enq_id'=>$enq_id,'enq_status!='=>1) , 1 , array('enq_id' , 'DESC') , '' , '');
      if(empty($enqData)){ redirect(base_url().'commons/enquiry_manager'); }
      $enqData = $enqData[0];
      $data['enqData']=$enqData;
      $data['page'] = 'Make Admission';
	  $data['courseList'] = $this->my_model->select_data('course_id,course_name' , 'courses' , '' , '' , array('course_id' , 'Asc'));
	  $data['batchList'] = $this->my_model->select_data('batch_id,batch_name,batch_fees' , 'batches' , array('batch_course'=>$enqData['enq_course']),'');
	  /*$course_fees=$this->my_model->select_data('course_fees' , 'courses' , array('course_id'=>$enqData['enq_course'] , ) , '');
      $data['course_fees']= $course_fees[0]['course_fees'];*/
      $this->load->view('include/header' , $data);
      $this->load->view('register_enquiry' , $data);
      $this->load->view('include/footer' , $data);
    }

    public function student_manager(){
		$data['title']='Students';	
		$this->session->set_userdata(array('req_user_role'=>4));
		$data['page'] = 'student_manager';
		$data['teacherCount'] = $this->my_model->aggregate_data('user' , 'user_id' , 'COUNT',array('user_role'=>4));
		$data['userType'] = 'Student';
		$data['userRole'] = 4;
		$data['courseList'] = $this->my_model->select_data('course_id,course_name' , 'courses' , '' , '' , array('course_id' , 'Asc'));
      	$this->load->view('include/header' , $data);
      	$this->load->view('user_manager' , $data);
      	$this->load->view('include/footer' , $data);
	}

	public function single_student($user_id=''){	
      $data['page'] = 'Single Student';
	  $user_detail= $this->my_model->select_data('*' , 'user' , array('user_id'=>$user_id,'user_role'=>4) , '' , '');
	  $data['user_detail']=$user_detail[0];
	  $join_array =
        array('multiple',
	     array(
		   	array('courses','courses.course_id = student_course.stud_course'),
		   	array('batches','batches.batch_id = student_course.stud_batch'),
		   	)
	   	);
	  $data['user_course_detail']= $this->my_model->select_data('*' , 'student_course' , array('stud_user_id'=>$user_id) , '' , '','',$join_array);
	 
	  $data['title']=$user_detail[0]['user_full_name'];
      $this->load->view('include/header' , $data);
      $this->load->view('single_student' , $data);
      $this->load->view('include/footer' , $data); 
	} 

	public function followup($enq_id=''){
	$data['title'] = 'Follow Up ';
      $data['page'] = 'Follow Up';
	  $enq_detail= $this->my_model->select_data('*' , 'enquiries' , array('enq_id'=>$enq_id) , '' , '','','');
	  $data['enq_detail']=$enq_detail[0];
	  $data['enq_id']=$enq_id;
      $this->load->view('include/header' , $data);
      $this->load->view('followup_detail' , $data);
      $this->load->view('include/footer' , $data); 
	} 

	public function view_attendance(){
	 $data['title'] = 'View Attendance';
      $data['page'] = 'View Attendance';
	  $data['courseList'] = $this->my_model->select_data('course_id,course_name' , 'courses' , '' , '' , array('course_id' , 'Asc'));
      $this->load->view('include/header' , $data);
      $this->load->view('view_attendance' , $data);
      $this->load->view('include/footer' , $data); 
	}

	public function attendance_detail(){
      if($_POST){
		  $data['title'] = 'Attendance Detail';
	      $data['page'] = 'Attendance Detail';
		  $att_batch=$_POST['stud_batch'];
		  $att_date=date('Y-m-d',strtotime($_POST['att_date'])).' 00:00:00';
		  $join_array =
			        array('multiple',
				     array(
					   	array('user','user.user_id = student_course.stud_user_id'),
					   	)
				   	);
		  $data['studentList'] = $this->my_model->select_data('user.user_id,user.user_full_name' , 'student_course' ,array('stud_batch'=>$att_batch) , '' , '','',$join_array);
		  $attendacedata=array();	   	
		  $attendanceList = $this->my_model->select_data('att_user,att_stud' , 'attendance' ,array('att_batch'=>$att_batch,'att_date'=>$att_date) , '' , '','','');
		  if(!empty($attendanceList)){
		  	foreach ($attendanceList as $cData) {
		  		array_push($attendacedata,$cData['att_user']);
		  	}
			$attendacedata=json_decode($attendanceList[0]['att_stud']);
		  }
		  
		  $data['attendacedata']=$attendacedata;
		 
		  $data['batchdetalis'] = $this->my_model->select_data('batch_name' , 'batches' , array('batch_id'=>$att_batch),'');
		  $data['date']=date('d-M-Y',strtotime($att_date));
	      $this->load->view('include/header' , $data);
	      $this->load->view('attendance_details' , $data);
	      $this->load->view('include/footer' , $data);
	     }  
	} 

	public function attendance(){
	  $data['title'] = 'Attendance ';
      $data['page'] = 'Attendance';
      $data['courseList'] = $this->my_model->select_data('course_id,course_name' , 'courses' , '' , '' , array('course_id' , 'Asc'));
      $this->load->view('include/header' , $data);
      $this->load->view('view_attendance' , $data);
      $this->load->view('include/footer' , $data); 
	}   
    public function get_student(){
    if($_POST){
		  $data['title'] = 'Attendance Detail';
	      $data['page'] = 'Attendance Detail';
		  $att_batch=$_POST['stud_batch'];
		  $join_array =
			        array('multiple',
				     array(
					   	array('user','user.user_id = student_course.stud_user_id'),
					   	)
				   	);
		  $data['studentList'] = $this->my_model->select_data('user.user_id,user.user_full_name' , 'student_course' ,array('stud_batch'=>$att_batch) , '' , '','',$join_array);
		  $data['batchdetalis'] = $this->my_model->select_data('batch_name,batch_id' , 'batches' , array('batch_id'=>$att_batch),'');
	      $this->load->view('include/header' , $data);
	      $this->load->view('get_student' , $data);
	      $this->load->view('include/footer' , $data);
      } 
	} 

	public function add_attendance(){
	  if($_POST){
		$attendanceList=$_POST['attendance'];
		
		$att_batch=$_POST['att_batch'];
		$att_date=date('Y-m-d').' 00:00:00';
		$chk_today = $this->my_model->select_data('att_user' , 'attendance' ,array('att_batch'=>$att_batch,'att_date'=>$att_date) , '' , '','','');
		if(!empty($chk_today)){
			$this->my_model->delete_data('attendance' ,array('att_batch'=>$att_batch,'att_date'=>$att_date));
		}
		
			/*foreach ($attendanceList as $cData) {
				$this->my_model->insert_data('attendance',array('att_batch'=>$att_batch,'att_date'=>$att_date,'att_user'=>$cData));
			}*/
			$this->my_model->insert_data('attendance',array('att_batch'=>$att_batch,'att_date'=>$att_date,'att_stud'=>json_encode($attendanceList)));
		
		redirect(base_url().'commons/attendance');
	 }
   }

}
