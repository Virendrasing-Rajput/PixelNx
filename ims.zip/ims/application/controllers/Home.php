<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

    public function __Construct(){
		parent::__Construct();
		if($this->session->userdata('login') != 1){
			redirect(base_url());
		}
	}

	public function index(){
		$this->dashboard();
	}
	
	public function dashboard(){
		$data['title']='Dashboard';
		$data['page'] = 'dashboard';
      	$this->load->view('include/header' , $data);
      	$this->load->view('dashboard' , $data);
      	$this->load->view('include/footer' , $data);
	}

    function logout(){
        $this->session->sess_destroy();
        redirect(base_url());
    }

    

}