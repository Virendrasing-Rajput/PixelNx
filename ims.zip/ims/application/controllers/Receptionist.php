<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Receptionist extends CI_Controller {

	public function __Construct(){
		parent::__Construct();
		// if($this->session->userdata('login') == 1){
			// redirect(base_url('dashboard'));
		// }else if($this->session->userdata('login') == 2){
			// redirect(base_url('add_patient'));
		// }
	}

	public function index(){
		 $this->dashboard();
	}

	public function enquiry_manager(){
		$data['page'] = 'course_manager';
		$data['courseCount'] = $this->my_model->aggregate_data('courses' , 'course_id' , 'COUNT');
		$data['courseCategoryData'] = $this->my_model->select_data('cat_id,cat_name' , 'course_category' , '' , '' , array('cat_id' , 'DESC'));
      	$this->load->view('include/header' , $data);
      	$this->load->view('course_manager' , $data);
      	$this->load->view('include/footer' , $data);
	}

	


}
