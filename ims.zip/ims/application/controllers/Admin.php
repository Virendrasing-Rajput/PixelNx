<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	public function __Construct(){
		parent::__Construct();
		// if($this->session->userdata('login') == 1){
			// redirect(base_url('dashboard'));
		// }else if($this->session->userdata('login') == 2){
			// redirect(base_url('add_patient'));
		// }
	}

	public function index(){
		 $this->dashboard();
	}

	public function course_manager(){
		$data['title'] = 'Courses';
		$data['page'] = 'course_manager';
		$data['courseCount'] = $this->my_model->aggregate_data('courses' , 'course_id' , 'COUNT');
		
      	$this->load->view('include/header' , $data);
      	$this->load->view('course_manager' , $data);
      	$this->load->view('include/footer' , $data);
	}

	
    
	public function staff_manager(){
		$data['title'] = 'Staff';
		$this->session->set_userdata(array('req_user_role'=>'3,4'));
		$data['page'] = 'staff_manager';
		$data['userType'] = 'Staff';
		$data['userRole'] = '';
		$data['educationList'] = $this->my_model->select_data('*' , 'education' , '' , '' , array('edu_name' , 'ASC'));
      	$this->load->view('include/header' , $data);
      	$this->load->view('user_manager' , $data);
      	$this->load->view('include/footer' , $data);
	}
	
	
	
	

    public function batches_manager(){
		$data['title']='Batches';
		$data['page'] = 'batches_manager';
		$data['batchCount'] = $this->my_model->aggregate_data('batches' , 'batch_id' , 'COUNT');
		$data['courseList'] = $this->my_model->select_data('course_id,course_name' , 'courses' , '' , '' , array('course_id' , 'DESC'));
		$data['teacherList'] = $this->my_model->select_data('user_id,user_full_name' ,'user', array('user_role'=>3) , '' , array('user_id' , 'asc'));
      	$this->load->view('include/header' , $data);
      	$this->load->view('batches_manager' , $data);
      	$this->load->view('include/footer' , $data);
	}
    
	public function expenses_type_manager(){
		$data['title']='Expenses Type';
		$data['page'] = 'expenses_type_manager';
		$data['expensestypeCount'] = $this->my_model->aggregate_data('expanses_add' , 'expense_add_id' , 'COUNT');
      	$this->load->view('include/header' , $data);
      	$this->load->view('expenses_type_manager' , $data);
      	$this->load->view('include/footer' , $data);
	}
	
	public function expenses_manager(){
		$data['title']='Expenses';
		$data['page'] = 'expenses_manager';
		$data['expansesCount'] = $this->my_model->aggregate_data('expanses' , 'exp_id' , 'COUNT');
		$data['expensesType'] = $this->my_model->select_data('*' , 'expanses_add' );
      	$this->load->view('include/header' , $data);
      	$this->load->view('expenses_manager' , $data);
      	$this->load->view('include/footer' , $data);
	}
	
	function fees(){
		$data['title']='Fees';
		$data['page'] = 'fees';
      	$this->load->view('include/header' , $data);
      	$this->load->view('fees' , $data);
      	$this->load->view('include/footer' , $data);
	}
	
	public function fees_manager(){
		$data['title']='Fees Manager';
		$data['page'] = 'fees_manager';
      	$this->load->view('include/header' , $data);
      	$this->load->view('fees_manager' , $data);
      	$this->load->view('include/footer' , $data);
	}
	public function account_manager(){
		$data['title']='Accounts';
		$data['page'] = 'account_manager';
      	$this->load->view('include/header' , $data);
      	$this->load->view('account_manger' , $data);
      	$this->load->view('include/footer' , $data);
	}

	public function college_manager(){
		$data['title'] = 'College';
		$data['page'] = 'college_manager';
      	$this->load->view('include/header' , $data);
      	$this->load->view('college_manager' , $data);
      	$this->load->view('include/footer' , $data);
	}

	public function education_manager(){
		$data['title'] = 'Education';
		$data['page'] = 'education_manager';
      	$this->load->view('include/header' , $data);
      	$this->load->view('education_manager' , $data);
      	$this->load->view('include/footer' , $data);
	}

	public function salary_manager(){
		$data['title'] = 'Salary';
		$data['page'] = 'salary_manager';
		$cond = "user_role IN (2,3)";
		$data['staffList']=$this->my_model->select_data('user_id,user_salary,user_full_name' , 'user', $cond );
      	$this->load->view('include/header' , $data);
      	$this->load->view('salary_manager' , $data);
      	$this->load->view('include/footer' , $data);
	}
	
	



}
