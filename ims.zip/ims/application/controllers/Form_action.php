<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Form_action extends CI_Controller {

    public function __Construct(){
		parent::__Construct();
		if($this->session->userdata('login') != 1){
			redirect(base_url());
		}
		$this->userId=$this->session->userdata('user_id');
	}



	
	

	/**************************************************************/
	/***************** Manage Course Section Start ************/
	/**************************************************************/
	
	
	public function manage_course(){
		if(isset($_POST) && !empty($_POST)){
			$courseData = array(
									'course_name' => $_POST['course_name'],
									'course_duration' => $_POST['course_duration'],
									'course_duration_type' => $_POST['course_duration_type'],
									'course_description' => $_POST['course_description'],
								);
			if(isset($_POST['targetCourse']) && $_POST['targetCourse'] != ''){
				$this->my_model->update_data('courses' , $courseData , array('course_id' => $_POST['targetCourse']));	
			}else{
				$this->my_model->insert_data('courses' , $courseData);			
			}					
 			$resp = array('status' => 1);
		}else{
			$resp = array('status' => 0);
		}
		echo json_encode($resp, JSON_UNESCAPED_SLASHES);
	}
	
	public function get_item_course(){
		if(isset($_POST['target'])){
			$checkData = $this->my_model->select_data('*' , 'courses' , array('course_id' => $_POST['target']) , 1);
			if(!empty($checkData)){
				$resp = array('status' => 1 , 'data' => $checkData[0]);
			}else{
				$resp = array('status' => 0);	
			}
		}else{
			$resp = array('status' => 0);
		}
		echo json_encode($resp, JSON_UNESCAPED_SLASHES);
	}
	
	
	/**************************************************************/
	/****************** Manage Course Section End *************/
	/**************************************************************/




	/**************************************************************/
	/***************** Manage User Section Start ************/
	/**************************************************************/
	
	
	public function manage_user(){
		if(isset($_POST) && !empty($_POST)){
			$userData = array(
									'user_role' => $_POST['user_role'],
									'user_full_name' => $_POST['tech_name'],
									'user_email' => $_POST['tech_email'],
									'mobile' => $_POST['tech_mobile'],
									'gender' => $_POST['tech_gender'],
									'qualification' => $_POST['tech_qualification'],
									'experience' => $_POST['tech_exp'],
									'user_salary' => $_POST['tech_salary'],
									'address' => $_POST['tech_address'],
									'doj' =>date("Y-m-d h:i:s", strtotime($_POST['tech_doj'])), 
									'status' => 1
								);
			if(isset($_POST['targetUser']) && $_POST['targetUser'] != ''){
				$this->my_model->update_data('user' , $userData , array('user_id' => $_POST['targetUser']));	
			}else{
				$userData['registration_date']= date("Y-m-d h:i:s"); 
				$this->my_model->insert_data('user' , $userData);			
			}					
 			$resp = array('status' => 1);
		}else{
			$resp = array('status' => 0);
		}
		echo json_encode($resp, JSON_UNESCAPED_SLASHES);
	}
	
	public function get_item_user(){
		if(isset($_POST['target'])){
			$checkData = $this->my_model->select_data('*' , 'user' , array('user_id' => $_POST['target']) , 1);
			
			if(!empty($checkData)){
				$resp = array('status' => 1 , 'data' => $checkData[0]);
			}else{
				$resp = array('status' => 0);	
			}
		}else{
			$resp = array('status' => 0);
		}
		echo json_encode($resp, JSON_UNESCAPED_SLASHES);
	}
	
	
	/**************************************************************/
	/****************** Manage Course Section End *************/
	/**************************************************************/
	
	

	/**************************************************************/
	/***************** Manage Course Section Start ************/
	/**************************************************************/
	
	
	public function manage_batch(){
		if(isset($_POST) && !empty($_POST)){
			$batchData = array(
									'batch_name' => $_POST['batch_name'],
									'batch_course' => $_POST['batch_course'],
									'batch_fees' => $_POST['batch_fees'],
									'batch_duration' => $_POST['batch_duration'],
									'batch_duration_type' => $_POST['batch_duration_type'],
									'batch_start_date' =>date("Y-m-d", strtotime($_POST['batch_start_date']))." 00:00:00",
									'batch_time' => $_POST['batch_time'], 
									'batch_description' => $_POST['batch_description'],
									'batch_status' =>  $_POST['batch_status'],
									
								);
			if(isset($_POST['targetBatch']) && $_POST['targetBatch'] != ''){
				$this->my_model->update_data('batches' , $batchData , array('batch_id' => $_POST['targetBatch']));	
			}else{
				$this->my_model->insert_data('batches' , $batchData);			
			}					
 			$resp = array('status' => 1);
		}else{
			$resp = array('status' => 0);
		}
		echo json_encode($resp, JSON_UNESCAPED_SLASHES);
	}
	
	public function get_item_batch(){
		if(isset($_POST['target'])){
			$join_array =
        array('multiple',
	     array(
		   	array('courses','courses.course_id = batches.batch_course'),
		   	
		   	)
	   	);
		$checkData = $this->my_model->select_data('batches.*,courses.course_name' , 'batches' , array('batch_id' => $_POST['target']) , 1 , array('batch_id' , 'DESC') , '' ,$join_array);
			
			if(!empty($checkData)){
				$resp = array('status' => 1 , 'data' => $checkData[0]);
			}else{
				$resp = array('status' => 0);	
			}
		}else{
			$resp = array('status' => 0);
		}
		echo json_encode($resp, JSON_UNESCAPED_SLASHES);
	}
	
	
	/**************************************************************/
	/****************** Manage Course Section End *************/
	/**************************************************************/



	/**************************************************************/
	/***************** Manage Enquiry Section Start ************/
	/**************************************************************/
	
	
	public function manage_enquiry(){
		if(isset($_POST) && !empty($_POST)){
			$enqData = array(
									'enq_name' => $_POST['enq_name'],
									'enq_email' => $_POST['enq_email'],
									'enq_mobile' => $_POST['enq_mobile'],
									'enq_course' => $_POST['enq_course'],
									'enq_followdate' =>date("Y-m-d ", strtotime($_POST['enq_followdate'])).' 00:00:00',
									'enq_remark' => $_POST['enq_remark'],
								);
			if(isset($_POST['targetEnquiry']) && $_POST['targetEnquiry'] != ''){
				$this->my_model->update_data('enquiries' , $enqData , array('enq_id' => $_POST['targetEnquiry']));	
			}else{
				$enqData['enq_date'] =date("Y-m-d h:i:s"); 
				$this->my_model->insert_data('enquiries' , $enqData);			
			}					
 			$resp = array('status' => 1);
		}else{
			$resp = array('status' => 0);
		}
		echo json_encode($resp, JSON_UNESCAPED_SLASHES);
	}
	
	public function get_item_enquiry(){
		if(isset($_POST['target'])){
			$checkData = $this->my_model->select_data('*' , 'enquiries' , array('enq_id' => $_POST['target']) , 1);
			if(!empty($checkData)){
				$resp = array('status' => 1 , 'data' => $checkData[0]);
			}else{
				$resp = array('status' => 0);	
			}
		}else{
			$resp = array('status' => 0);
		}
		echo json_encode($resp, JSON_UNESCAPED_SLASHES);
	}
	

	public function register_enquiry(){
		$enq_id=$_POST['enq_id'];
		$stud_name=$_POST['stud_name'];
		$stud_email=$_POST['stud_email'];
		$stud_mobile=$_POST['stud_mobile'];
		$stud_gender=$_POST['stud_gender'];
		$stud_address=$_POST['stud_address'];
		$stud_course=$_POST['stud_course'];
		$stud_batch=$_POST['stud_batch'];
		$stud_fees=$_POST['stud_fees'];
		$stud_deposit=$_POST['stud_deposit'];
		$stud_discount=$_POST['stud_descount'];
		$stud_doj=date("Y-m-d h:i:s", strtotime($_POST['stud_doj']));
		$stud_note=$_POST['stud_note'];

        $checkEmail = $this->my_model->select_data('*' , 'user' , array('user_email' =>$stud_email) , 1);
        if(empty($checkEmail)){
		$user_arr=array(
                "user_role"=>4,
                "user_full_name"=>$stud_name,
                "user_email"=>$stud_email,
                "user_password"=>md5('pass@2017'),
                "status"=>1,
                "mobile"=>$stud_mobile,
                "doj"=>$stud_doj,
                "gender"=>$stud_gender,
                "qualification"=>$_POST['enq_education'],
                "user_college"=>$_POST['enq_college'],
                "address"=>$stud_address,
				'registration_date' =>date("Y-m-d h:i:s")
			);

        $user_id=$this->my_model->insert_data('user' , $user_arr);

        $stud_arr=array(
             "stud_user_id"=>$user_id,
             "stud_course"=>$stud_course,
             "stud_batch"=>$stud_batch,
             "stud_fess"=>$stud_fees,
             "stud_disc"=>$stud_discount,
             "stud_doj"=>$stud_doj,
             "stud_remaining"=>$stud_fees-$stud_discount-$stud_deposit
        	);
        $stud_id=$this->my_model->insert_data('student_course' , $stud_arr);
		if($stud_deposit>0){
        $fees_arr=array(
          "fees_uid"=>$user_id,
          "fess_studid"=>$stud_id,
          "fess_amount"=>$stud_deposit,
          "fees_note"=>'Deposit at time  registration',
		  'fess_date' =>date("Y-m-d h:i:s")
        	);
        $fees_id=$this->my_model->insert_data('fees' , $fees_arr);
		$acData=array('ac_type'=>1,'ac_type_id'=>$fees_id,'ac_date'=>date("Y-m-d h:i:s"));
		$this->my_model->insert_data('account',$acData);
		}

	    if($enq_id!=''){
	        $this->my_model->update_data('enquiries' ,array('enq_status'=>1), array('enq_id' => $enq_id));
	    }
        
        $resp = array('status' => 1);
	    }else{
	    	$resp = array('status' => 0,'error'=>'Email already exists');
	    }
        echo json_encode($resp, JSON_UNESCAPED_SLASHES);
    
	}
	
	/**************************************************************/
	/****************** Manage Enquiry Section End *************/
	/**************************************************************/

	

	/**************************************************************/
	/****************** Add Fees Section End *************/
	/**************************************************************/
   
    public function add_fees(){
		if(isset($_POST) && !empty($_POST)){
			$feesData = array(
									'fees_uid' => $_POST['fees_userId'],
									'fess_studid' => $_POST['fees_course'],
									'fess_amount' => $_POST['fees_amount'],
									'fess_method' => $_POST['fess_method'],
									'fees_note' => $_POST['fees_remark']
								);
			
		$fees_id= $this->my_model->insert_data('fees' , $feesData);
		$acData=array('ac_type'=>1,'ac_type_id'=>$fees_id,'ac_date'=>date("Y-m-d h:i:s"));
		$this->my_model->insert_data('account',$acData);
		 
         $student_courseDetail=$this->my_model->select_data('stud_remaining' , 'student_course' , array('stud_id' =>$_POST['fees_course']) , 1);
		 $stud_remaining=$student_courseDetail[0]['stud_remaining']-$_POST['fees_amount'];
		 $this->my_model->update_data('student_course' ,array('stud_remaining'=>$stud_remaining), array('stud_id' => $_POST['fees_course']));	 
 			$resp = array('status' => 1);
		}else{
			$resp = array('status' => 0);
		}
		echo json_encode($resp, JSON_UNESCAPED_SLASHES);
	}

	/**************************************************************/
	/****************** Add Fees Section End *************/
	/**************************************************************/


	/**************************************************************/
	/****************** Add Fees Section End *************/
	/**************************************************************/
   
    public function manage_followup(){
		if(isset($_POST) && !empty($_POST)){
			$follow_enqid=$_POST['follow_enqid'];
			$follow_mode=$_POST['follow_mode'];
			$follow_feedback=$_POST['follow_feedback'];
			$follow_status=$_POST['follow_status'];
			$follow_next_date=$_POST['follow_next_date'];
			$follow_date=date("Y-m-d h:i:s");
			$follow_note=$_POST['follow_note'];
			if($follow_next_date==''){
 			  $follow_next_date=date("Y-m-d h:i:s");
			}else{
              $follow_next_date=date("Y-m-d ", strtotime($follow_next_date)).' 00:00:00';
			}
			$followData = array(
									'follow_enqid' =>$follow_enqid,
									'follow_date' => $follow_date,
									'follow_next_date' =>$follow_next_date,
									'follow_mode' => $follow_mode,
									'follow_feedback' => $follow_feedback,
									'follow_status' => $follow_status,
									'follow_userid' => $this->userId,
									'follow_status' => $follow_status,
									'follow_note'   =>$follow_note
								);
			
			$this->my_model->insert_data('followup' , $followData);
			
			 $this->my_model->update_data('enquiries' , array('enq_status'=>$follow_status,'enq_followdate'=>$follow_next_date) , array('enq_id' => $follow_enqid));	
				
 			$resp = array('status' => 1);
		}else{
			$resp = array('status' => 0);
		}
		echo json_encode($resp, JSON_UNESCAPED_SLASHES);
	}

	/**************************************************************/
	/****************** Add Fees Section End *************/
	/**************************************************************/
	
	
	
		/**************************************************************/
	/***************** Manage Expanses Type Section Start ************/
	/**************************************************************/
	
	
	public function manage_expensestype(){
		if(isset($_POST) && !empty($_POST)){
			$ExpensesData = array(
									'expense_name' => $_POST['expensestype_name'],
									
								);
			if(isset($_POST['targetExpensestype']) && $_POST['targetExpensestype'] != ''){
				$this->my_model->update_data('expanses_add' , $ExpensesData , array('expanses_add_id' => $_POST['targetExpensestype']));	
			}else{
				$this->my_model->insert_data('expanses_add' , $ExpensesData);			
			}					
 			$resp = array('status' => 1);
		}else{
			$resp = array('status' => 0);
		}
		echo json_encode($resp, JSON_UNESCAPED_SLASHES);
	}

	
	
	/**************************************************************/
	/****************** Manage Expanses Type Section End *************/
	/**************************************************************/
	
	/**************************************************************/
	/***************** Manage Expanses  Section Start ************/
	/**************************************************************/
	
	
	public function manage_expanses(){
		if(isset($_POST) && !empty($_POST)){
			$exp_date= date("Y-m-d", strtotime($_POST['exp_date'])).' '.date('h:i:s');
			$expensesData = array(
									'exp_name' => $_POST['exp_name'],
									'exp_type' => $_POST['exp_type'],
									'exp_amount' => $_POST['exp_amount'],
									'exp_method' =>  $_POST['exp_method'],
									'exp_note' =>  $_POST['exp_note'],
									'exp_date' => $exp_date
								);
			if(isset($_POST['targetExpanses']) && $_POST['targetExpanses'] != ''){
			   $this->my_model->update_data('expanses' , $expensesData , array('exp_id' => $_POST['targetExpanses']));	
			}else{
			$exp_id=$this->my_model->insert_data('expanses' , $expensesData);
			$acData=array('ac_type'=>2,'ac_type_id'=>$exp_id,'ac_date'=>$exp_date);
            $this->my_model->insert_data('account',$acData);				
			}					
 			$resp = array('status' => 1);
		}else{
			$resp = array('status' => 0);
		}
		echo json_encode($resp, JSON_UNESCAPED_SLASHES);
	}
	
	public function get_item_expanses(){
		if(isset($_POST['target'])){
		$join_array =
        array('multiple',
	     array(
		   	array('expanses_add','expanses_add.expense_add_id= expanses.exp_type'),
		   	)
	   	);
		$checkData = $this->my_model->select_data('*' , 'expanses' , array('exp_id' => $_POST['target']) , 1 , array('exp_id' , 'DESC') , '' ,$join_array);
			
			if(!empty($checkData)){
				$resp = array('status' => 1 , 'data' => $checkData[0]);
			}else{
				$resp = array('status' => 0);	
			}
		}else{
			$resp = array('status' => 0);
		}
		echo json_encode($resp, JSON_UNESCAPED_SLASHES);
	}
	
	
	/**************************************************************/
	/****************** Manage Expanses Type Section End *************/
	/**************************************************************/
	
	
	/**************************************************************/
	/***************** Manage College Section Start ************/
	/**************************************************************/
	
	
	public function manage_college(){
		if(isset($_POST) && !empty($_POST)){
			$collegeData = array(
									'clg_name' => $_POST['clg_name']
								);
			if(isset($_POST['targetCollege']) && $_POST['targetCollege'] != ''){
				$this->my_model->update_data('college' , $collegeData , array('clg_id' => $_POST['targetCollege']));	
			}else{
				$this->my_model->insert_data('college' , $collegeData);			
			}					
 			$resp = array('status' => 1);
		}else{
			$resp = array('status' => 0);
		}
		echo json_encode($resp, JSON_UNESCAPED_SLASHES);
	}
	
	public function get_item_college(){
		if(isset($_POST['target'])){
			$checkData = $this->my_model->select_data('*' , 'college' , array('clg_id' => $_POST['target']) , 1);
			if(!empty($checkData)){
				$resp = array('status' => 1 , 'data' => $checkData[0]);
			}else{
				$resp = array('status' => 0);	
			}
		}else{
			$resp = array('status' => 0);
		}
		echo json_encode($resp, JSON_UNESCAPED_SLASHES);
	}
	
	
	/**************************************************************/
	/****************** Manage College Section End *************/
	/**************************************************************/
	
	
  /**************************************************************/
	/***************** Manage Education Section Start ************/
	/**************************************************************/
	
	
	public function manage_education(){
		if(isset($_POST) && !empty($_POST)){
			$educationData = array(
									'edu_name' => $_POST['edu_name']
								);
			if(isset($_POST['targetEducation']) && $_POST['targetEducation'] != ''){
				$this->my_model->update_data('education' , $educationData , array('edu_id' => $_POST['targetEducation']));	
			}else{
				$this->my_model->insert_data('education' , $educationData);			
			}					
 			$resp = array('status' => 1);
		}else{
			$resp = array('status' => 0);
		}
		echo json_encode($resp, JSON_UNESCAPED_SLASHES);
	}
	
	public function get_item_education(){
		if(isset($_POST['target'])){
			$checkData = $this->my_model->select_data('*' , 'education' , array('edu_id' => $_POST['target']) , 1);
			if(!empty($checkData)){
				$resp = array('status' => 1 , 'data' => $checkData[0]);
			}else{
				$resp = array('status' => 0);	
			}
		}else{
			$resp = array('status' => 0);
		}
		echo json_encode($resp, JSON_UNESCAPED_SLASHES);
	}
	
	
	/**************************************************************/
	/****************** Manage Education Section End *************/
	/**************************************************************/



	/**************************************************************/
	/***************** Manage Expanses  Section Start ************/
	/**************************************************************/
	
	
	public function manage_salary(){
		if(isset($_POST) && !empty($_POST)){
			$sal_date=date("Y-m-d h:i:s");
			$salaryData = array(
									'sal_uid' => $_POST['sal_uid'],
									'sal_amount' => $_POST['sal_amount'],	
									'sal_date' =>  $sal_date
								);
			if(isset($_POST['targetSalary']) && $_POST['targetSalary'] != ''){
			   $this->my_model->update_data('salary' , $salaryData , array('sal_id' => $_POST['targetSalary']));	
			}else{
			$exp_id=$this->my_model->insert_data('salary' , $salaryData);
			$acData=array('ac_type'=>3,'ac_type_id'=>$exp_id,'ac_date'=>$sal_date);
            $this->my_model->insert_data('account',$acData);				
			}					
 			$resp = array('status' => 1);
		}else{
			$resp = array('status' => 0);
		}
		echo json_encode($resp, JSON_UNESCAPED_SLASHES);
	}
	
	public function get_item_salary(){
		if(isset($_POST['target'])){
		$join_array ="";
		$checkData = $this->my_model->select_data('*' , 'salary' , array('sal_id' => $_POST['target']) , 1 , array('sal_date' , 'DESC') , '' ,$join_array);
			
			if(!empty($checkData)){
				$resp = array('status' => 1 , 'data' => $checkData[0]);
			}else{
				$resp = array('status' => 0);	
			}
		}else{
			$resp = array('status' => 0);
		}
		echo json_encode($resp, JSON_UNESCAPED_SLASHES);
	}
	
	
	/**************************************************************/
	/****************** Manage Expanses Type Section End *************/
	/**************************************************************/

}