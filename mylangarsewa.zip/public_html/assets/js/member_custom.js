$(document).ready(function(){
	if($('.receipt_container').length){
		$('.receipt_container').magnificPopup({ type:'image'});
	}
	
	$('.image').on('change',function(){
		var image_rex = /\.(jpe?g|png)$/i;
		var image = $(this).val();
		if(!image_rex.test(image)){
			message('Invalid image formate.' , 'error');
			$(this).val('');
		}	
	});
	
});


function change_pass(element , m_body){
	var check = checkRequire(m_body);
	if(check == 0){
		var current_pass = $('#c_pass').val().trim();
		var new_pass = $('#n_pass').val().trim();
		var rep_pass = $('#r_n_pass').val().trim();
		if(new_pass.length <= 6){
			message('Password should be more than 6 character.' ,'error');
		}else if(new_pass != rep_pass){
			message('New password and repeat password does not match.' ,'error');
		}else{
			var base_url = $('#base_url').val();	
			$.ajax({
				method : 'post',
				url : base_url+'user_action/change_password',
				data : {'c_pass' : current_pass, 'n_pass' : new_pass}
			}).done(function(resp){
				if(resp == 1){
					$(element).removeAttr('onclick').html('<i class="fa fa-spinner fa-pulse fa-fw"></i>');
					location.reload();
				}else if(resp == 2){
					message('Current password is wrong.' ,'error');
				}else if(resp == 3){
					message('Password should be more than six character.' ,'error');
				}else{
					location.reload();
				}
			});
		}
	}
}
