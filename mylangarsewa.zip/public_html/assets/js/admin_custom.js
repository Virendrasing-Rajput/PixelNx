var base_url;

(function ($) {
    "use strict";
    $(document).ready(function () {
		
		base_url = $('#base_url').val(); // Assign base path
		var max_fields      = 20; //maximum input boxes allowed
		var wrapper         = $(".input_fields_wrap"); //Fields wrapper
		var add_button      = $(".add_field_button"); //Add button ID
		
		var x = 1; //initlal text box count
		$(add_button).click(function(e){ //on add input button click
			e.preventDefault();
			if(x < max_fields){ //max input box allowed
				x++; //text box increment
				$(wrapper).append('<div class="dg_add_cat"><label>Sub Category</label><input type="text" name="mytext[]" class="form-control"/><a href="#" class="remove_field">X</a></div>'); //add input box
			}
		});
			$(wrapper).on("click",".remove_field", function(e){ //user click on remove text
			e.preventDefault(); $(this).parent('div').remove(); x--;
		})
		
		// For Calender
		$( "#datepicker" ).datepicker({
			inline: true
		});
		$( ".dg_datepicker" ).datepicker();
		$( "#dg_date_option" ).datepicker();
		
		
		/////
		 $( "#dg_sortable, .dg_sortable_div" ).sortable();
		$( "#dg_sortable, .dg_sortable_div" ).disableSelection();
		////
		
		
		// For Tabs
		$( ".dg_tabs" ).tabs();
		// For Accordion
		$( ".dg_accordion" ).accordion();
		// For Data Tables
		//$('.dg_whole_table').DataTable();
		$('.dg_whole_table').dataTable({bFilter: false, bInfo: false});
		
		// Setup - add a text input to each footer cell
		/////////
		 $('#example').dataTable();
		
	
		// For Table Filter
		/*==Nice Scroll ==*/
		if ($.fn.niceScroll) {
			$(".dg-leftside-navigation").niceScroll({
				cursorcolor: "#e84b56",
				cursorborder: "0px solid #fff",
				cursorborderradius: "0px",
				cursorwidth: "3px"
			});
		}
		////
		
		$('.sidebar-toggle-box .fa-bars').click(function (e) {
	
            $(".dg-leftside-navigation").niceScroll({
                cursorcolor: "#1FB5AD",
                cursorborder: "0px solid #fff",
                cursorborderradius: "0px",
                cursorwidth: "3px"
            });

            $('#dg-sidebar').toggleClass('hide-left-bar');
            if ($('#dg-sidebar').hasClass('hide-left-bar')) {
                $(".leftside-navigation").getNiceScroll().hide();
            }
            $(".dg-leftside-navigation").getNiceScroll().show();
            $('#dg-main-content').toggleClass('merge-left');
		});
			
			
		var $window = $(window),
			$ul = $('#dg-main-content');
				$(window).on('load', function () {
				if ($window.width() < 979) {
				   $ul.addClass('merge-left');
			   }else{
				$ul.removeClass('merge-left')};
		});
	

		var $window = $(window),
			$ulside = $('#dg-sidebar');
			 $(window).on('load', function () {
				if ($window.width() < 979) {
				   $ulside.addClass('hide-left-bar');
			   }else{
				$ulside.removeClass('hide-left-bar')};
		});
		
		//Select adio button for background Settings
		//$(".dg_bgsettings_panel").hide();
		$("input[name$='dg_background_selection']").click(function() {
			var test = $(this).val();
			$(".dg_bgsettings_panel").hide();
			$(".dg_bgsettings_panel[data-period='" + test + "']").show();
		});
		
		//Select adio button for Button Settings
		//$(".dg_buttons_panel").hide();
		$("input[name$='dg_button_selection']").click(function() {
			var test1 = $(this).val();
			$(".dg_buttons_panel").hide();
			$(".dg_buttons_panel[data-period='" + test1 + "']").show();
		});
		
		
		$('.dg_tooltip').hover(function(){
			$('.dg_open_tooltip').fadeIn(500)
		},function(){
			$('.dg_open_tooltip').fadeOut(500)
		});
		
		
		$('.dg_select_right_img').hide();
		
		
		$('ul.dg_btn_selection li a.dg_roundbtn, ul.dg_btn_selection li a.dg_hexa_button, ul.dg_btn_selection li a.dg_big_btn').click(function(e) {
		 e.preventDefault();
		 var id=$(this).attr('id');
		 
		$("ul.dg_btn_selection li a.dg_roundbtn, ul.dg_btn_selection li a.dg_hexa_button, ul.dg_btn_selection li a.dg_big_btn").each(function() {
			$('.dg_select_right_img').hide();
		});
		  $('#div'+id).slideDown("fast");
		});
		
		
		$('.clear_modal').on('click', function(){
			$($(this).attr('data-target')).find('input').val('');
		});
		
		if($('.receipt_container').length){
			$('.receipt_container').magnificPopup({ type:'image'});
		}
		
		$('.image').on('change',function(){
			var image_rex = /\.(jpe?g|png)$/i;
			var image = $(this).val();
			if(!image_rex.test(image)){
				message('Invalid image formate.' , 'error');
				$(this).val('');
			}	
		});	
	
	});
})(jQuery);

function edit_item(element , mdl){
	var target = $(element).closest('tr');
	$('#target_title').val(target.find('td:nth-child(2)').text().trim());
	$('#target_id').val(target.attr('data-target'));
	$('#'+mdl).modal('show');
}

function check_form(element){
	var check = checkRequire(element);
	if(check == 1){
		return false;
	}else{
		return true;
	}
}

function check_blog_form(element){
	var check = checkRequire(element);
	var blog_image = $('#uploadBtn1').val().trim();
	if(check == 1){
		return false;
	}else{
		if(!$('input[name="post_id"]').length && blog_image == ''){
			message('Upload blog image.','error');
			return false;
		}else{
			return true;
		}
	}
	
}

function remove_contact(cont_id , element){
	var cnf = confirm('Are you sure to remove?');
	if(cnf == true){
		$.ajax({
			method : 'post',
			url : base_url+'admin_action/remove_contact',
			data : {'c_id' : cont_id}
			
		}).done(function(resp){
			if(resp == true){
				message('Contact detail removed successfully.','success');
				$(element).closest('tr').remove();
			}else{
				location.reload();
			}
		});
	}
}


