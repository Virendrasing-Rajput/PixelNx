function validateForm() {
    var x = document.forms["myForm"]["log"].value;
    var pwd = document.forms["myForm"]["pwd"].value;
    if (x != "demo") {
        alert("Invalid Username and Password");
        return false;
    }
	if (pwd != "demo") {
        alert("Invalid Username and Password");
        return false;
    }
}
(function ($) {
    "use strict";
    $(document).ready(function () {
		
		  var max_fields      = 20; //maximum input boxes allowed
    var wrapper         = $(".input_fields_wrap"); //Fields wrapper
    var add_button      = $(".add_field_button"); //Add button ID
    
    var x = 1; //initlal text box count
    $(add_button).click(function(e){ //on add input button click
        e.preventDefault();
        if(x < max_fields){ //max input box allowed
            x++; //text box increment
            $(wrapper).append('<div class="dg_add_cat"><label>Sub Category</label><input type="text" name="mytext[]" class="form-control"/><a href="#" class="remove_field">X</a></div>'); //add input box
        }
    });
	    $(wrapper).on("click",".remove_field", function(e){ //user click on remove text
        e.preventDefault(); $(this).parent('div').remove(); x--;
    })
	
	// For Calender
	$( "#datepicker" ).datepicker({
		inline: true
	});
	$( ".dg_datepicker" ).datepicker();
	$( "#dg_date_option" ).datepicker();
	$('#timepicker1').timepicki({increase_direction:'up'}); 
	
	/////
	 $( "#dg_sortable, .dg_sortable_div" ).sortable();
    $( "#dg_sortable, .dg_sortable_div" ).disableSelection();
	////
	tinymce.init({
		selector: ".dg_textarea",
		theme: "modern",
		plugins: [
			"advlist autolink lists link image charmap print preview hr anchor pagebreak",
			"searchreplace wordcount visualblocks visualchars code fullscreen",
			"insertdatetime media nonbreaking save table contextmenu directionality",
			"emoticons template paste textcolor colorpicker textpattern"
		],
		toolbar1: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image",
		toolbar2: "print preview media | forecolor backcolor emoticons",
		image_advtab: true,
		templates: [
			{title: 'Test template 1', content: 'Test 1'},
			{title: 'Test template 2', content: 'Test 2'}
		]
	});
		
	//Sparklin bar effects
	$("#sparkline_bar").sparkline([9, 10, 11, 10, 14, 12, 10, 13, 11], {
                type: 'bar',
                width: '100',
                barWidth: 10,
                height: '75',
                barColor: '#b3dbaa',
                negBarColor: '#e02222'
            });
	$("#sparkline_bar1").sparkline([9, 10, 11, 10, 14, 12, 10, 13, 11], {
                type: 'bar',
                width: '100',	
                barWidth: 10,
                height: '75',
                barColor: '#cbbbea',
                negBarColor: '#e02222'
            });
	$("#sparkline_bar2").sparkline([9, 10, 11, 10, 14, 12, 10, 13, 11], {
                type: 'bar',
                width: '100',
                barWidth: 10,
                height: '75',
                barColor: '#f4c3af',
                negBarColor: '#e02222'
            });
	// For Tabs
	$( ".dg_tabs" ).tabs();
	// For Accordion
	$( ".dg_accordion" ).accordion();
	// For Data Tables
	//$('.dg_whole_table').DataTable();
	$('.dg_whole_table').dataTable({bFilter: false, bInfo: false});
	$("#table-1").tableDnD();
	$(".dg_table_sorting_secion").tableDnD();
	// Setup - add a text input to each footer cell
	/////////
     $('#example').dataTable()
		  .columnFilter({
			  sPlaceHolder: "head:after",
			aoColumns: [ { type: "text" },
				     { type: "text" },
				     { type: "text" },
				     { type: "text" },
					 { type: "select", values: [ 'Pending', 'Approved']  },
				     null
						]
		}	);
		$('#dg_example').dataTable()
		  .columnFilter({
			  sPlaceHolder: "head:after",
			aoColumns: [ { type: "text" },
				     { type: "text" },
				     { type: "text" },
				     { type: "text" },
					 { type: "select", values: [ 'Pending', 'Approved']  },
				     null
				]
			});
		$('#dg_sale_example').dataTable()
		  .columnFilter({
			  sPlaceHolder: "head:after",
			aoColumns: [ { type: "text" },
				     { type: "text" },
				     { type: "text" },
				     { type: "text" },
				     { type: "text" },
				     { type: "text" },
				     { type: "text" },
				     { type: "text" },
					 { type: "select", values: [ 'Buy', 'Sale']  },
				     null
				]
			});
	
	
  // For Table Filter
	
	//$('#demotable1').tableFilter(options1);
	/*==Nice Scroll ==*/
	if ($.fn.niceScroll) {
		$(".dg-leftside-navigation").niceScroll({
			cursorcolor: "#e84b56",
			cursorborder: "0px solid #fff",
			cursorborderradius: "0px",
			cursorwidth: "3px"
		});
	}
	////
	
	 $('.sidebar-toggle-box .fa-bars').click(function (e) {

            $(".dg-leftside-navigation").niceScroll({
                cursorcolor: "#1FB5AD",
                cursorborder: "0px solid #fff",
                cursorborderradius: "0px",
                cursorwidth: "3px"
            });

            $('#dg-sidebar').toggleClass('hide-left-bar');
            if ($('#dg-sidebar').hasClass('hide-left-bar')) {
                $(".leftside-navigation").getNiceScroll().hide();
            }
            $(".dg-leftside-navigation").getNiceScroll().show();
            $('#dg-main-content').toggleClass('merge-left');
			});
	var $window = $(window),
			$ul = $('#dg-main-content');
				$(window).on('load', function () {
				if ($window.width() < 979) {
				   $ul.addClass('merge-left');
			   }else{
				$ul.removeClass('merge-left')};
		});
	

	var $window = $(window),
			$ulside = $('#dg-sidebar');
			 $(window).on('load', function () {
				if ($window.width() < 979) {
				   $ulside.addClass('hide-left-bar');
			   }else{
				$ulside.removeClass('hide-left-bar')};
		});
	
	});
	
	//
var chart = c3.generate({
    bindto: '#chart',
    data: {
      columns: [
        ['data1', 30, 200, 100, 400, 150, 250],
        ['data2', 50, 20, 10, 40, 15, 25]
      ],
      axes: {
        data2: 'y2' // ADD
      }
    },
    axis: {
      y2: {
        show: true // ADD
      }
    }
});
	var chart = c3.generate({
    bindto: '#chart1',
    data: {
      columns: [
        ['data1', 30, 200, 100, 400, 150, 250],
        
      ],
    },
    axis: {
      y2: {
        show: true // ADD
      }
    }
});
//Select adio button for background Settings
	//$(".dg_bgsettings_panel").hide();
    $("input[name$='dg_background_selection']").click(function() {
        var test = $(this).val();
        $(".dg_bgsettings_panel").hide();
        $(".dg_bgsettings_panel[data-period='" + test + "']").show();
    });
//Select adio button for Button Settings
	//$(".dg_buttons_panel").hide();
    $("input[name$='dg_button_selection']").click(function() {
        var test1 = $(this).val();
        $(".dg_buttons_panel").hide();
        $(".dg_buttons_panel[data-period='" + test1 + "']").show();
    });
		$('.dg_tooltip').hover(function(){
        $('.dg_open_tooltip').fadeIn(500)
    },function(){
        $('.dg_open_tooltip').fadeOut(500)
    })
	 $('.dg_select_right_img').hide();
$('ul.dg_btn_selection li a.dg_roundbtn, ul.dg_btn_selection li a.dg_hexa_button, ul.dg_btn_selection li a.dg_big_btn').click(function(e) {
 e.preventDefault();
 var id=$(this).attr('id');
$("ul.dg_btn_selection li a.dg_roundbtn, ul.dg_btn_selection li a.dg_hexa_button, ul.dg_btn_selection li a.dg_big_btn").each(function() {
$('.dg_select_right_img').hide();
});
  $('#div'+id).slideDown("fast");
});
})(jQuery);