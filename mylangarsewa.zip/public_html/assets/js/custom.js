
var base_url;
(function($){
  "use strict";
	// on ready function
	jQuery(document).ready(function($) {

	base_url = $('#base_url').val().trim();
	// for counter 
		$('.timer').appear(function() {
			$(this).countTo();
		});
		
	$('.sub-button').show();	
	// return only number 
	$('.return_number').on('keypress',function(evt){
		var charCode = (evt.which) ? evt.which : event.keyCode;
		if (charCode > 31 && (charCode < 48 || charCode > 57)){
			return false;
		}else{
			return true;
		} 
	});	
	//testimonial_slider
	
		var owl1 =  $(".ls_testimonial_slider .owl-carousel");
		owl1.owlCarousel({
			loop:true,
			items:1,
			dots: false,
			nav: true,
			navText: ['<i class="fa fa-angle-left"></i>','<i class="fa fa-angle-right"></i>'],
			autoHeight: false,
			touchDrag: false,
			mouseDrag: false,
			margin:0,
			autoplay:false
		});
		
	//datepicker
		$( "#datepicker, #datepicker1" ).datepicker({
				dateFormat: 'dd-mm-yy',
				defaultDate: "+1w",
				numberOfMonths: 1,
				minDate: new Date()
		});
		$(".datepicker_dob").datepicker({ changeMonth: true, changeYear: true, yearRange: '1900:2016', dateFormat: 'dd-mm-yy'});
		
	
	//langar Sewa image slider
	
	$('.ls_langar_sewa_slider .owl-carousel').owlCarousel({
		loop:true,
		margin:10,
		items: 1,
		dots:false,
		nav:true,
		navText:['<i class="fa fa-angle-left"></i>','<i class="fa fa-angle-right"></i>'],
		autoplay:true
	});
	
	//Search popup
	
	$(".ls_search").on ("click" , function(){
		$(".ls_search_popup").addClass("open");
	});
	$(".ls_search_popup .close_button").on ("click" , function(){
		$(".ls_search_popup").removeClass("open");
	});
	
	
	// select currency 
	$('select[name="select_currency"]').on('change' , function(){
		$(this).find('option:first').attr('disabled', true);
		$('.min_cur').html('Minimum '+$(this).find('option:selected').attr('data-target')+$(this).find('option:selected').attr('target-amount'));
	});
	
	
	//select item option
	
	//$('.ls_showhide_div').hide();
	$('.ls_itemselect input[name="sel_item"], .ls_arrivaldiv_inner input[name="arrive_temp"]').click(function(){
		var target = $(this).attr('data-target');
		if($(this).val().trim() == '1'){
			$('.'+target).slideDown();
			if(target == 'ls_arrivaldate'){ $('.'+target).find('#datepicker1').addClass('require') };
		}else{
			$('.'+target).slideUp();
			if(target == 'ls_arrivaldate'){ $('.'+target).find('#datepicker1').removeClass('require') };
		}
	});

		// member signup
		$('button.signUp').on('click' , function(){
			var target = $(this);	
			var check = checkRequire(target.closest('form'));
			if(check == 0){
				var pass = $('#u_password').val().trim();
				var re_pass = $('#u_cnf_password').val().trim();
				var u_email = $('#u_email').val().trim();
				if(pass.length >= 7){
					if(pass == re_pass){
						target.html('<i class="fa fa-spinner fa-pulse fa-fw"></i>');	
						$.ajax({
							method:'post',
							url:base_url+'front_ajax/check_email',
							data:{'email':u_email}
						}).done(function(resp){
							if(resp !=0 || resp != ''){
								if(resp == 1){ 
									target.html('SUbMit');	
									message('Email alredy exists.','error');
								}else{
									target.closest('form').submit();
								}
							}else{
								message('Something is wrong, please try after some time.','error');
							}
						});
					}else{
						message('Both password should be same.','error');
					}	
				}else{
					message('Password should be more than six charecter.','error');
				}
			}
		});
		
		// member login
		$('button.logIn').on('click' , function(){
			var target = $(this);	
			var check = checkRequire(target.closest('form'));
			if(check == 0){
				target.html('<i class="fa fa-spinner fa-pulse fa-fw"></i>');
				$.ajax({
					method : 'post',
					url : base_url+'front_ajax/user_login',
					data : {'email' : $('#lg_email').val().trim() , 'password' : $('#lg_password').val().trim()}
				}).done(function(resp){
					if(resp != 0 || resp != ''){
						if(resp == 1){
							location.reload();
						}else if(resp == 2){
							target.html('SUbMit');
							message('Check your email to verify this account.','error');
						}else{
							target.html('SUbMit');
							message('Details are not correct.','error');
						}
					}else{
						target.html('SUbMit');
						message('Something is wrong, please try after some time.','error');
					}
				});
			}
		});
		
		// mail to reset password 
		$('button.resetPass').click(function(){
			var target = $(this);	
			var check = checkRequire(target.closest('form'));
			if(check == 0){
				var email = $('#reset_email').val().trim();
				target.html('<i class="fa fa-spinner fa-pulse fa-fw"></i>');
				$.ajax({
					method : 'post',
					url : base_url+'front_ajax/reset_password',
					data : {'email' : email}
				}).done(function(resp){
					if(resp == 1){
						target.removeClass('resetPass');
						location.reload();
					}else if(resp == 2){
						target.html('Submit');
						message('For account verification check your mail.','error');
					}else{
						target.html('Submit');
						message('Email not exists.','error');
					}
				});
			}
		});
		
		
		//password reset 
		$('button.passwordReset').click(function(){
			var target = $(this);	
			var check = checkRequire(target.closest('form'));
			if(check == 0){
				var pass = $('#pass').val().trim();
				var re_pass = $('#re_pass').val().trim();
				if(pass.length >= 7){
					if(pass == re_pass){
						target.html('<i class="fa fa-spinner fa-pulse fa-fw"></i>');
						target.removeClass('passwordReset');
						target.closest('form').submit();
					}else{
						message('Both password should be same.','error');
					}
				}else{
					message('Password should be more than six charecter.','error');
				}
			}
		});
		
		// comment box hide show
		$('.reply_post').click(function(){
			var target = $('.reply_post').parent();
			target.find('.ls_replybox').remove();
			$(this).after($('#reply_box').html());
			target.find('.ls_replybox input[name="comment_parent"]').val($(this).attr('data-target'));
		});
		
		// pagination
		$('#ciPagination li a').on('click', function() {
			$(this).append('<form method="post"><input type="hidden" name="ci_pagination_key" value="' + $(	this).parent().attr('data-value') + '"></form>');
			$(this).find('form').submit();
		});

		if($('form#payPayment').length){
			$('form#payPayment').submit();
		}
	
	});
})(); 


function check_form_valid(formId , element){
	var check = checkRequire(formId);
	if(check == 0){
		$(element).removeAttr('onclick').append('<i class="fa fa-spinner fa-pulse fa-fw"></i>');
		$('#'+formId).submit();
	}
}

function process_your_sewa_form_c(frm){
	var target = $(frm);
	var target_amount = parseInt(target.find('select[name="select_currency"] option:selected').attr('target-amount'));
	var cur = target.find('select[name="select_currency"] option:selected').attr('data-target');
	var sewa_amount = parseInt(target.find('input[name="sewa_amount"]').val());
	var sel_item = target.find('input[name="sel_item"]:checked').val();
	var check_item = 0;
	$('#sewa_item_list').find('input[name="item[]"]').each(function(){
		if($(this).is(':checked')){
			check_item = 1;
		}
	});
	
	if($('select[name="select_currency"]').val() != 0){
		var check = checkRequire(frm); 
		if(check == 0){
			if(sewa_amount >= target_amount){
				if(sel_item == 1 && check_item == 0){
					message('Please select item.','error');
					return false;
				}else{
					$(frm).find('.sub-button').attr('type','button').append(' <i class="fa fa-spinner fa-pulse fa-fw"></i>');
					return true;	
				}
			}else{
				message('Minimum amount should be '+target_amount+cur+'.','error');
				return false;
			}	
		}else{
			return false;
		}	
	}else{
		message('Please choose currency.','error');
		return false;
	}
}

function request_for_quote(formId , element){
	var chheck_item = 0;
	$('#'+formId).find('input[type="checkbox"]').each(function(){
		
	});
}


    