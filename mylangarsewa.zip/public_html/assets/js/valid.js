function message(msg , type){
	var cls = (type == 'error')? 'ls_popup_error' : 'ls_popup_success';
	if($('.ls_message_popup').length){
		$('.ls_message_popup').remove();
	} 
		
	$('head').after('<div class="ls_message_popup '+cls+'"><p class="ls_message_popup_text">'+msg+'<a onclick="$(this).parent().parent().remove()"><i class="fa fa-close" title="Remove"></i></a></p></div>');
}

function checkRequire(formId){	
	var email = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/;	 
	var url = /(http|ftp|https):\/\/[\w-]+(\.[\w-]+)+([\w.,@?^=%&amp;:\/~+#-]*[\w@?^=%&amp;\/~+#-])?/;

	var image = /\.(jpe?g|gif|png|PNG|JPE?G)$/;
	var mobile =/^(\+\d{1,3}[- ]?)?\d{10}$/; 
	var facebook = /^(https?:\/\/)?(www\.)?facebook.com\/[a-zA-Z0-9(\.\?)?]/;
	var twitter = /^(https?:\/\/)?(www\.)?twitter.com\/[a-zA-Z0-9(\.\?)?]/;
	var google_plus = /^(https?:\/\/)?(www\.)?plus.google.com\/[a-zA-Z0-9(\.\?)?]/;

	$('.error_message').remove();
	var check = 0;
	var target = (typeof formId == 'object')? $(formId):$('#'+formId);
	target.find('input , textarea , select').each(function(){
		if($(this).hasClass('require')){
			if($(this).val().trim() == ''){
				check = 1;
				message('Please fill out require field.','error');
				$(this).addClass('error');
				 return false; 
			}else{
				$(this).removeClass('error');
			} 
		}   
		
		
		if($(this).val().trim() != ''){
			var valid = $(this).attr('data-valid'); 
			if(typeof valid != 'undefined'){
				if(!eval(valid).test($(this).val().trim())){
					message($(this).attr('data-error'),'error');
					$(this).addClass('error');	
					check = 1;
					 return false; 
				}else{
					$(this).removeClass('error');
				}
			}
		}
	});
	return check;
}