(function($){
  "use strict";
	
	// on ready function
	jQuery(document).ready(function($) {


	// for counter 
		$('.timer').appear(function() {
			$(this).countTo();
		});
		
	//testimonial_slider
	
		var owl1 =  $(".ls_testimonial_slider .owl-carousel");
		owl1.owlCarousel({
			loop:true,
			items:1,
			dots: false,
			nav: true,
			navText: ['<i class="fa fa-angle-left"></i>','<i class="fa fa-angle-right"></i>'],
			autoHeight: false,
			touchDrag: false,
			mouseDrag: false,
			margin:0,
			autoplay:false
		});
		
	//datepicker
		$( "#datepicker, #datepicker1" ).datepicker();
	
	//langar Sewa image slider
	
	$('.ls_langar_sewa_slider .owl-carousel').owlCarousel({
		loop:true,
		margin:10,
		items: 1,
		dots:false,
		nav:true,
		navText:['<i class="fa fa-angle-left"></i>','<i class="fa fa-angle-right"></i>'],
		autoplay:true
	});
	
	//Search popup
	
	$(".ls_search").on ("click" , function(){
		$(".ls_search_popup").addClass("open");
	});
	$(".ls_search_popup .close_button").on ("click" , function(){
		$(".ls_search_popup").removeClass("open");
	});
	
	//select item option
	
	//$('.ls_product_box').hide();
	$('.ls_itemselect input[type="radio"]').click(function(){
		if($(this).val().trim() == 'yes'){
			$('.ls_product_box').slideDown();
		}else{
			$('.ls_product_box').slideUp();
		}
	});


	
	});
})(); 


    