<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Image_control{ 
	public $basePath;
	function __Construct(){
		$this->CI = get_instance();
		$this->CI->load->library('image_lib');
		$this->basePath = explode('application/',dirname(__FILE__))[0];
	}	
	# function For upload images
	function upload_image($upPath , $name , $postFix = NULL){
		$uploadPath = $this->basePath.$upPath;
		$config['upload_path'] = $uploadPath;
		$config['allowed_types'] = '*';
		$this->CI->load->library('upload', $config);
		if ($this->CI->upload->do_upload($name)){
			//$this->upload->display_errors();	
			$uploaddata = $this->CI->upload->data();
			$imgName = $uploaddata['raw_name'];
			$imgExt = $uploaddata['file_ext'];
			$randomstr = substr(md5(microtime()), 0, 10);
			$uploadedImage = $randomstr.$postFix.$imgExt;
			rename($uploadPath.$imgName.$imgExt, $uploadPath.$uploadedImage);
			return $uploadedImage;
		}else{ 
			return '';
		}
	}
	
	# function for resize image 
	function resizeImage($imgPath , $name , $height , $width , $thumb = NULL , $ratio= NULL){
		$config['source_image'] = $this->basePath.$imgPath.$name;
		$config['create_thumb'] = ($thumb == 1)?true:false;
		$config['maintain_ratio'] = ($ratio == 1)?true:false;
		$config['width'] = $width;
		$config['height'] = $height; 
		$this->CI->image_lib->initialize($config);
		$this->CI->image_lib->resize();
		$this->CI->image_lib->clear();
		//$this->CI->image_lib->display_errors();
	}
	
	# function For upload multiple images
	function uploadMultipleImage($upl_path , $name , $postFix = NULL){
		$imageId = '';
		$upload_Path = $this->basePath.$upl_path;
		$config1['upload_path'] = $upload_Path;
		$config1['allowed_types'] = 'JPG|PNG|JPEG|jpg|png|jpeg';
		$files = $_FILES;
		$cpt = count($_FILES[$name]['name']);
		for($i=0; $i<$cpt; $i++)
		{    
			$_FILES[$name]['name']= $files[$name]['name'][$i];
			$_FILES[$name]['type']= $files[$name]['type'][$i];
			$_FILES[$name]['tmp_name']= $files[$name]['tmp_name'][$i];
			$_FILES[$name]['error']= $files[$name]['error'][$i];
			$_FILES[$name]['size']= $files[$name]['size'][$i];  
			$this->CI->load->library('upload', $config1);
			if ($this->CI->upload->do_upload($name)){ 
				$uploaddata=$this->CI->upload->data();
				$logo_name = $uploaddata['raw_name'];
				$logo_ext = $uploaddata['file_ext'];
				$randomstr = substr(md5(microtime()), 0, 10);
				$logo_new_name = $randomstr.$postFix.$logo_ext; 
				rename($upload_Path.$logo_name.$logo_ext, $upload_Path.$logo_new_name);
				
				$imageId .= $logo_new_name.' ,';
			}else{ 
				$imageId .= ' ,';//$this->CI->upload->display_errors();
			} 
		}
			
		return $imageId;	
	}
	
	
	function remove_image($path , $image){
		$upath = $this->basePath.$path;
		$uploadPath = $upath.$image;
		if(file_exists($uploadPath)){
			@unlink($uploadPath);
		}
	}
	
} 

?>