<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Send_mail{			# define 'Form_action' class
	function __Construct(){							#define constructor
		$this->CI = get_instance();
	}
	
	function mail_send($to , $subject , $message , $file = ''){
		$config = array();
		$config['useragent'] = "CodeIgniter";
		$config['mailpath'] = "/usr/bin/sendmail"; // or "/usr/sbin/sendmail"
		$config['protocol'] = "smtp";
		$config['smtp_host'] = "localhost";
		$config['smtp_port'] = "25";
		$config['mailtype'] = 'html';
		$config['charset']  = 'utf-8';
		$config['newline']  = "\r\n";
		$config['wordwrap'] = TRUE;

		$this->CI->load->library('email');

		$this->CI->email->initialize($config);
		
		$from = $this->CI->site_detail->site_email;
		$title = $this->CI->site_detail->site_name;
		//$this->CI->email->set_header('Content-type', 'text/html');
		//$this->CI->email->set_mailtype('html');
		//$this->CI->email->set_newline("\r\n");
		$this->CI->email->set_header('charset', 'iso-8859-1');
		$this->CI->email->from($from, $title); 
		if($file != ''){
			$this->CI->email->attach($file);
		}
		$this->CI->email->to($to);
		$this->CI->email->subject($subject);
		$this->CI->email->message($message);
		$this->CI->email->send();
		return $this->CI->email->print_debugger(array('headers'));
	}
} # end class 'Form_action'
