<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Site_detail{
	public $site_name , $site_title , $site_email , $site_logo , $site_copyright , $site_mobile , $site_favicon , $site_keywords , $site_description;
	function Site_detail(){ 
		$this->CI = get_instance();
		$this->CI->load->model('langar_model');
		$site_data = $this->CI->langar_model->select_data('*' , 'site_detail');
		if(!empty($site_data)){
			$this->site_name = $site_data['0']['site_name'];
			$this->site_email = $site_data['0']['site_email'];
			$this->site_mobile = $site_data['0']['site_contact'];
			$this->site_logo = 'assets/images/logo.png';
			$this->site_favicon = 'assets/images/favicon.png';
			$this->site_copyright = $site_data['0']['site_copyright'];
			$this->site_title = $site_data['0']['site_title'];
			$this->site_keywords = $site_data['0']['site_keywords'];
			$this->site_description = $site_data['0']['site_description'];
		} 
	} # end function 
	
}	# end class 
 
?>