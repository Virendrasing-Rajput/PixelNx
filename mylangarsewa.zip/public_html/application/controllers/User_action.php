<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_action extends CI_Controller {
	public $m_id;
	function __Construct(){
		parent::__Construct();
		$this->m_id = $this->session->userdata('id');
		if($this->session->userdata('login')){
			$role = $this->session->userdata('role');
			if($role == 1){
				redirect(base_url('admin'));
			}
		}else{
			redirect(base_url());
		}
	}
	
	function post_comment(){
		if(isset($_POST['reply']) || isset($_POST['comment'])){
			$c_data = (isset($_POST['reply']))?trim($_POST['reply']):trim($_POST['comment']);
			if($c_data != ''){
				$comment_data = array(
									'comment_parent' => (isset($_POST['comment_parent']))?$_POST['comment_parent']:0,
									'post_id' => $_POST['post_id'],
									'cmmented_by' => $this->session->userdata('id'),
									'comment_data' => $c_data,
									'comment_status' => 1
									);
				$ins_cmnt = $this->langar_model->insert_data('blog_comment' , $comment_data);
				$this->session->set_flashdata('success','Your comment posted successfully.');
				
			}else{
				$this->session->set_flashdata('notice','Comment should not be empty.');
			}
			
		}
		redirect($this->agent->referrer());
	}
	
	
	//update profile image
	
	function update_profile(){
		if(isset($_FILES['profile_img']['name']) && $_FILES['profile_img']['name'] != ''){
			$this->load->library('image_control');
			$profile_img = $this->image_control->upload_image('/assets/img/profile/' , 'profile_img' , $this->m_id);
			$this->image_control->resizeImage('/assets/img/profile/' , $profile_img , '150' , '150' , '0' , '0');
			if($this->session->userdata('profile') != 'profile.jpg'){
				$this->image_control->remove_image('/assets/img/profile/' , $this->session->userdata('profile'));// remove current prfile
			}
			
			$this->langar_model->update_data('users' , array('profile_image' => $profile_img) , array('user_id' => $this->m_id) , 1);
			$this->session->set_userdata(array('profile' => $profile_img));
			$this->session->set_flashdata('success','Profile picture updated successfully.');
		}else{
			$this->session->set_flashdata('error','Choose your profile image.'); 
		}
		redirect($this->agent->referrer());
	}
	
	
	
	
	// function for ajax
	
	
	// change password 
	function change_password(){
		if(isset($_POST['c_pass'])  &&  isset($_POST['n_pass'])){
			$check_pass = $this->langar_model->select_data('user_id' , 'users' , array('user_id' => $this->m_id , 'user_password' => md5($_POST['c_pass'])));
			if(!empty($check_pass)){
				if(strlen(trim($_POST['n_pass'])) <= 6){
					echo 3;
				}else{
					echo $this->langar_model->update_data('users' , array('user_password' => md5($_POST['n_pass'])) , array('user_id' => $this->m_id , 'user_password' => md5($_POST['c_pass'])) , 1);
					$this->session->set_flashdata('success','Password changed successfully.');
				}
			}else{
				echo 2;
			}
		}else{
			echo false;
		}
	}
	
	
	
	
	
}
