<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Member extends CI_Controller{
	public $m_id; 
	public function __Construct(){ 
		parent::__Construct(); 
		//print_r($this->session->userdata); 
		if($this->session->userdata('login')){ 
			$this->m_id = $this->session->userdata('id');
			$role = $this->session->userdata('role');
			if($role == 1){
				redirect(base_url('admin'));
			}
		}else{
			redirect(base_url());
		}
	} 
	
	function index(){
		$data['index'] = 1;
		$data['comlplete_sewa'] = $this->langar_model->aggregate_data('order' , 'order_id' , 'COUNT' , array('user_id' => $this->m_id , 'order_status' => 1));  
		$data['in_comlplete_sewa'] = $this->langar_model->aggregate_data('order' , 'order_id' , 'COUNT' , array('user_id' => $this->m_id , 'order_status' => 0));  
		
		$data['recent_sewa_detail'] = $this->langar_model->select_data('order.order_id,order.order_uniq,order.request_date,order.order_status,payment.pay_currency, payment.pay_amount' , 'order' , array('user_id' => $this->m_id) , 5 , array('order_id' , 'DESC') , '' , array('payment', 'payment.pay_id = order.payment_id'));
	
		$this->load->view('member/include/header',$data); 
		$this->load->view('member/dashboard',$data); 
		$this->load->view('member/include/footer',$data);
	}  
	
	function sewa($order_id = NULL){
		$data['sewa'] = 1;
		if($order_id != ''){ 
			$data['single'] = 1;
			$check_sewa = $this->langar_model->select_data('order.*,payment.pay_currency, payment.pay_amount' , 'order' , array('user_id' => $this->m_id , 'order_uniq' => $order_id)  , '' , '' , '' , array('payment', 'payment.pay_id = order.payment_id'));
			if(!empty($check_sewa)){
				$data['order_detail'] = $check_sewa;
			}else{
				redirect(base_url('member/sewa'));
			}
		}else{
			$cond = array('user_id' => $this->m_id);
			if(isset($_POST['status']) && $_POST['status'] != ''){
				$cond['order_status'] =  $data['status'] = $_POST['status'];
			}
			if(isset($_POST['request_id']) && trim($_POST['request_id']) != ''){
				$cond['order_uniq'] = $data['request_id'] = trim($_POST['request_id']);
			} 
			
			
			$data['order_detail'] = $this->langar_model->select_data('order.order_id,order.order_uniq,order.request_date,order.order_status,payment.pay_currency, payment.pay_amount' , 'order' , $cond  , '' , array('order_id' , 'DESC') , '' , array('payment', 'payment.pay_id = order.payment_id'));
		}
		$this->load->view('member/include/header',$data); 
		$this->load->view('member/sewa',$data); 
		$this->load->view('member/include/footer',$data);
	}
	 
	function profile(){
		$data['profile'] = 1;
		$this->load->view('member/include/header',$data); 
		$this->load->view('member/profile',$data); 
		$this->load->view('member/include/footer',$data);
	}
	
	
}
