<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
	public function __Construct(){
		parent::__Construct();
		
		if($this->session->userdata('login')){
			$role = $this->session->userdata('role');
			if($role == 2){
				redirect(base_url('member'));
			}
		}else{
			redirect(base_url());
		}
	}
	public function index(){
		$data['index'] = true;
		$data['resent_users'] = $this->langar_model->select_data('*' , 'users' , array('email_verification' => 1) , 5 , array('user_id' , 'DESC'));
		$data['sewa_detail'] = $this->langar_model->select_data('order.order_id,order.order_uniq,order.request_date,users.user_id,users.user_name ,payment.pay_currency, payment.pay_amount' , 'order' , '' , 5 , array('order_id' , 'DESC') , '' , array('multiple' , array(array('users' , 'users.user_id = order.user_id'), array('payment', 'payment.pay_id = order.payment_id'))));
		
		$this->load->view('admin/include/header',$data);
		$this->load->view('admin/index');
		$this->load->view('admin/include/footer');
	}
	
	public function member(){
		$data['member'] = true;
		$this->load->view('admin/include/header',$data);
		$this->load->view('admin/member');
		$this->load->view('admin/include/footer');
	}
	
	
	public function item_manager(){
		$data['item_detail'] = $this->langar_model->select_data('*','item');
		$data['item'] = true;
		$this->load->view('admin/include/header',$data);
		$this->load->view('admin/item_manage');
		$this->load->view('admin/include/footer');
	}
	
	
	public function blog_post($type = "" , $post_id = NULL){
		$data['blog_post'] = true;
		$this->load->view('admin/include/header',$data);
		if($type != ''){
			if(isset($post_id)){
				//$blog_detail = $this->langar_model->select_data('blog_post.*','blog_post' , array('post_id' => $post_id) , '' , '' , '' , array('blog_category','blog_category.category_id = blog_post.post_category'));
				$blog_detail = $this->langar_model->select_data('blog_post.*','blog_post' , array('post_id' => $post_id));
			
				if(!empty($blog_detail)){
					$data['blog_detail'] = $blog_detail;
				}else{
					redirect(base_url('admin/blog_post'));
				}
			}
			$this->load->view('admin/add_blog_post',$data);
		}else{
			//$data['blog_detail'] = $this->langar_model->select_data('post_id,post_slug,post_title,post_image,post_description,post_date,category_title,post_status','blog_post' , '' , '' , array('post_id','DESC') , '' , array('blog_category','blog_category.category_id = blog_post.post_category'));
			$data['blog_detail'] = $this->langar_model->select_data('post_id,post_slug,post_title,post_image,post_description,post_date,post_status','blog_post' , '' , '' , array('post_id','DESC'));
			$this->load->view('admin/blog_post',$data);
		}
		
		$this->load->view('admin/include/footer');
	}
	
	public function blog_categories(){
		$data['blog_cate'] = true;
		$data['category_detail'] = $this->langar_model->select_data('*','blog_category');
		$this->load->view('admin/include/header',$data);
		$this->load->view('admin/blog_categories');
		$this->load->view('admin/include/footer');
	}
	
	function testimonial(){
		$data['testimonial'] = true;
		$data['testimonial_detail'] = $this->langar_model->select_data('testimonial.* , users.user_name' , 'testimonial' , '' , '' , array('testimonial_id' , 'DESC') , '' , array('users','users.user_id = testimonial.member_id'));
		$this->load->view('admin/include/header',$data);
		$this->load->view('admin/testimonial');
		$this->load->view('admin/include/footer');
	}
	
	
	function contact(){
		$data['contact'] = true;
		$data['contact_detail'] = $this->langar_model->select_data('*' , 'contact');
		$this->load->view('admin/include/header',$data);
		$this->load->view('admin/contact');
		$this->load->view('admin/include/footer');
	}
	
	function notification(){
		$data['notification'] = true;
		$data['notification_detail'] = $this->langar_model->select_data('*','notice_message');
		$this->load->view('admin/include/header',$data);
		$this->load->view('admin/notification');
		$this->load->view('admin/include/footer');
	}
	
	function sewa($order_id = NULL){;
		$data['sewa'] = true;
		if($order_id != ''){
			$data['single'] = 1;
			$check_sewa = $this->langar_model->select_data('order.*,users.user_id,users.user_name,users.user_email,users.user_contact ,payment.pay_currency, payment.pay_amount' , 'order' , array('order_uniq' => $order_id) , 1 , array('order_id' , 'DESC') , '' , array('multiple' , array(array('users' , 'users.user_id = order.user_id'), array('payment', 'payment.pay_id = order.payment_id'))));
			if(!empty($check_sewa)){
				$data['order_detail'] = $check_sewa;
			}
			
		}else{
			$cond = array();
			if(isset($_GET['member'])){
				$cond['order.user_id'] = $_GET['member'];
			}
		
			$aggr_cnd = $cond;
			$aggr_cnd['order_status'] = 1;
			
			$data['sewa_completed'] = $this->langar_model->aggregate_data('order' , 'order_id' , 'COUNT' , $aggr_cnd);  
			$aggr_cnd['order_status'] = 0;
			
			$data['sewa_remaining'] = $this->langar_model->aggregate_data('order' , 'order_id' , 'COUNT' , $aggr_cnd); 
			
			if(isset($_POST['status']) && $_POST['status'] != ''){
				$cond['order_status'] = $data['status'] = $_POST['status'];
			}
			
			if(isset($_POST['request_id']) && trim($_POST['request_id']) != ''){
				$cond['order_uniq'] = $data['request_id'] = $_POST['request_id'];
			} 
			
			$data['sewa_deta'] = $this->langar_model->select_data('order.order_id,order.order_uniq,order.request_date,order.order_status,users.user_id,users.user_name,users.user_email ,payment.pay_currency, payment.pay_amount' , 'order' , $cond , '' , array('order_id' , 'DESC') , '' , array('multiple' , array(array('users' , 'users.user_id = order.user_id'), array('payment', 'payment.pay_id = order.payment_id'))));
		}
		
		$this->load->view('admin/include/header',$data);
		$this->load->view('admin/sewa');
		$this->load->view('admin/include/footer');
	}
	
	function profile(){
		$data = array();
		$this->load->view('admin/include/header',$data);
		$this->load->view('admin/profile');
		$this->load->view('admin/include/footer');
	}
	
	function settings(){
		$data['setting'] = 1;
		$this->load->view('admin/include/header',$data);
		$this->load->view('admin/settings');
		$this->load->view('admin/include/footer');
	}
	
	
	function slider_setting(){
		$data['slider_setting'] = true;
		$data['langar_message'] = $this->langar_model->select_data('*' , 'l_sewa');
		$data['gallery_image'] = $this->langar_model->select_data('*' , 'gallery');
		$this->load->view('admin/include/header',$data);
		$this->load->view('admin/langar_sewa');
		$this->load->view('admin/include/footer');
	}
	
	
	
}
