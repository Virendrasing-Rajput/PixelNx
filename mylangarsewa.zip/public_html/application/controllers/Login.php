<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
	function index(){
		if($this->session->userdata('login')){
			$role = $this->session->userdata('role');
			if($role == 1){
				$target = 'admin';
			}elseif($role == 2){
				$target = 'member';
			}
			redirect(base_url($target));
		}else{
			$this->load->view('admin/login');
		}
	}
}
