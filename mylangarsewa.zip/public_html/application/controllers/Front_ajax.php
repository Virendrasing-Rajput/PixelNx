<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Front_ajax extends CI_Controller {
	function admin_login(){
		if(isset($_POST['email']) && isset($_POST['password'])){
			$admin_detail = $this->langar_model->select_data('*' , 'admin' , array('admin_email' => trim($_POST['email']),'admin_password' => md5(trim($_POST['password']))));	
			if(!empty($admin_detail)){
				$admin_detail = array(
									'login' => 1,
									'role' => 1,
									'id' => $admin_detail['0']['admin_id'],
									'name' => $admin_detail['0']['admin_name'],
									'email' => $admin_detail['0']['admin_email'],
									'profile' => ($admin_detail['0']['profile_image'] != '')?$admin_detail['0']['profile_image']:'profile.jpg'
									);
				$this->session->set_userdata($admin_detail);
				$this->session->set_flashdata("success","Login successfull.");	
				echo true;
			}else{
				echo false;
			}
		}else{ 
			echo false;
		} 
	}
	
	
	function check_email(){
		if(isset($_POST['email'])){
			$user_detail = $this->langar_model->select_data('user_id' , 'users' , array('user_email' => trim($_POST['email'])));
			echo (!empty($user_detail))?1:2;
		}else{
			echo false;
		}
	}
	
	
	function user_login(){
		if(isset($_POST['email']) && isset($_POST['password'])){
			$user_detail = $this->langar_model->select_data('*' , 'users' , array('user_email' => trim($_POST['email']), 'user_password' => md5(trim($_POST['password']))) , 1);
			if(!empty($user_detail)){
				if($user_detail['0']['email_verification'] == 1){
					$detail = array(
								'login' => 1,
								'role' => 2,
								'id' => $user_detail['0']['user_id'],
								'name' => $user_detail['0']['user_name'],
								'profile' => ($user_detail['0']['profile_image'] !='')?$user_detail['0']['profile_image']:'profile.jpg',
								'email' => trim($_POST['email'])
								);
					$this->session->set_userdata($detail);	
					$this->session->set_flashdata("success","Login successfull.");					
					echo 1;
				}else{
					echo 2;
				}	
			}else{
				echo 3;
			}
		}else{
			echo false;
		}
	}
	
	
	function reset_password(){ 
		if(isset($_POST['email'])){ 
			$check_email = $this->langar_model->select_data('user_id,user_name,email_verification,verification_code' , 'users' , array('user_email' => trim($_POST['email'])) , 1);	
			if(!empty($check_email)){
				if($check_email['0']['email_verification'] == 1){
					$code = md5(microtime());
					
					$this->langar_model->update_data('users', array('verification_code' => $code) , array('user_email' => trim($_POST['email'])) , 1);
					$this->load->library('send_mail'); 
					
					$temp_detail = array('user_name' => trim($check_email['0']['user_name']),'reset_link' => base_url('reset-password/'.$code));
					
					$message = $this->load->view('front/template/forgot_password', $temp_detail , true); 
					
					$this->send_mail->mail_send(trim($_POST['email']) , 'Reset Password' , $message);
					$this->session->set_flashdata('success','Please check your email to reset your password.');
					echo 1;
				}else{
					echo 2;
				}
			}else{
				echo false;
			}
		}else{
			echo false;
		}
	}
	
	
	
}
