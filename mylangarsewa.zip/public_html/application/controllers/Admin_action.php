<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_action extends CI_Controller {
	
	function __Construct(){
		parent::__Construct();
		if($this->session->userdata('login')){
			$role = $this->session->userdata('role');
			if($role == 2){
				redirect(base_url('member'));
			}
		}else{
			redirect(base_url());
		}
	}
	
	function slugify($text){
		$text = preg_replace('~[^\pL\d]+~u', '-', $text); // replace non letter or digits by -
		$text = iconv('utf-8', 'us-ascii//TRANSLIT', $text); // transliterate
		$text = trim(preg_replace('~[^-\w]+~', '', $text), '-'); // remove unwanted characters and trim 
		$text = strtolower(preg_replace('~-+~', '-', $text)); // remove duplicate - and lower case
		if (empty($text)){
			return 'n-a'; 
		}else{
			 return $text;
		}
	} # end slugify()
	
	function update_item(){
		if(isset($_POST['item_name']) && trim($_POST['item_name']) != ''){
			$item_detail = array(
								'item_name' => trim($_POST['item_name']),
								'item_status' => $_POST['item_status']
								);
			$item_where = array('item_name' => trim($_POST['item_name']));
			if(isset($_POST['item_id']) && trim($_POST['item_id']) != ''){
				$item_where['item_id != '] = trim($_POST['item_id']);
			}
			
			$chech_item = $this->langar_model->select_data('item_name' , 'item' , $item_where);
			if(empty($chech_item)){
				if(isset($_POST['item_id']) && trim($_POST['item_id']) != ''){
					$this->langar_model->update_data('item' , $item_detail , array('item_id' =>$_POST['item_id']));
					$this->session->set_flashdata('success','Item updated successfully.');
				}else{
					$this->langar_model->insert_data('item' , $item_detail);
					$this->session->set_flashdata('success','Item added successfully.');
				}
			}else{
				$this->session->set_flashdata('notice','Item already exist.');	
			}
		}
		redirect($this->agent->referrer());
	}
	
	function update_blog_category(){
		if(isset($_POST['cate_title']) && trim($_POST['cate_title']) != ''){
			$cate_slug = $this->slugify(trim($_POST['cate_title']));
			$blog_detail = array(
								'category_slug' => $cate_slug,
								'category_title' => trim($_POST['cate_title']),
								'category_status' => $_POST['Cate_status']
								);
			$cate_where = array('category_slug' => $cate_slug);					
			if(isset($_POST['cate_id']) && trim($_POST['cate_id']) != ''){
				$cate_where['category_id != '] = trim($_POST['cate_id']);
			}					
			$chech_cate = $this->langar_model->select_data('category_slug' , 'blog_category' , $cate_where);
			if(empty($chech_cate)){
				if(isset($_POST['cate_id']) && trim($_POST['cate_id']) != ''){
					$this->langar_model->update_data('blog_category' , $blog_detail , array('category_id' =>$_POST['cate_id']));
					$this->session->set_flashdata('success','Blog category updated successfully.');
				}else{
					$this->langar_model->insert_data('blog_category' , $blog_detail);
					$this->session->set_flashdata('success','Blog category added successfully.');
				}
			}else{
				$this->session->set_flashdata('notice','Blog category already exist.');	
			}
		}
		redirect($this->agent->referrer());
	}
	
	function update_post(){
		if(isset($_POST['post_title']) && trim($_POST['post_title']) != '' && isset($_POST['post_desc']) && trim($_POST['post_desc']) != ''){
			$this->load->library('image_control');
			if($_FILES['post_image']['name'] != ''){
				$blog_image = $this->image_control->upload_image('/assets/img/post/' , 'post_image' , '');
				$this->image_control->resizeImage('/assets/img/post/' , $blog_image , '350' , '845');
				if(isset($_POST['post_image']) && trim($_POST['post_image']) != ''){
					$this->image_control->remove_image('/assets/img/post/' , trim($_POST['post_image']));
				}
				
			}else{
				$blog_image = (isset($_POST['post_image']) != '')?$_POST['post_image']:'';
			}
			
			
			$post_slug = $this->slugify(trim($_POST['post_title']));	
			$post_detail = array(
								//'post_category' => $_POST['post_category'],
								'post_slug' => $post_slug,
								'post_title' => $_POST['post_title'],
								'post_image' => $blog_image,
								'post_description' => $_POST['post_desc'],
								'post_description_second' => $_POST['post_desc_sec'],
								'post_description_third' => $_POST['post_desc_thi'],
								'post_status' => $_POST['post_status'],
								'show_comment' => $_POST['post_show_comment'],
								);
						
			$post_where = array('post_slug' => $post_slug);					
			if(isset($_POST['post_id']) && trim($_POST['post_id']) != ''){
				$post_where['post_id != '] = trim($_POST['post_id']);
			}	
			
			$chech_post = $this->langar_model->select_data('post_id,post_slug' , 'blog_post' , $post_where);	
			if(empty($chech_post)){	
				if(isset($_POST['post_id']) && trim($_POST['post_id']) != ''){
					$this->langar_model->update_data('blog_post' , $post_detail , array('post_id' => trim($_POST['post_id'])));
					$this->session->set_flashdata('success','Blog updated successfully.');
				}else{
					$this->langar_model->insert_data('blog_post' , $post_detail);
					$this->session->set_flashdata('success','Blog added successfully.'); 
				}
			}else{
				$this->session->set_flashdata('notice','Blog title already exist.');
			}
		}
		redirect(base_url('admin/blog_post'));
	}
	
	function add_testimonial($type = NULL , $te_id = null){
		if($type != '' && $type == 'del'){
			$del = $this->langar_model->delete_data('testimonial' , array('testimonial_id' => $te_id));
			$this->session->set_flashdata("success","Testimonial detail removed successfully.");
		}else{
			if(isset($_POST['testi_data']) && isset($_POST['testi_by'])){
				if(trim($_POST['testi_data']) != '' && trim($_POST['testi_by'])){
					$testi_detail = array(
										'member_id' => 	$_POST['testi_by'],
										'testimonial_data' => 	$_POST['testi_data'],
										); 
					$this->langar_model->insert_data('testimonial' , $testi_detail);
					$this->session->set_flashdata('success','Testimonial detail saved successfully.');		
				}else{
					$this->session->set_flashdata("notice","Fields cann't be empty.");
				}
			}
		}
		redirect($this->agent->referrer());
	}
	
	
	function add_receipt(){
		if(isset($_POST['order_id']) && $_FILES['rec_img']['name']){
			$allowed =  array('jpeg','png' ,'jpg');
			$ext = pathinfo($_FILES['rec_img']['name'], PATHINFO_EXTENSION);
			if(in_array($ext,$allowed) ) {
				$this->load->library('image_control');
				 $rec = $this->image_control->upload_image('/assets/img/receipt/' , 'rec_img' , $_POST['order_id']);
				 $rec_detail = array('order_id' => $_POST['order_id'],'rec_name' => $rec);
				 $this->langar_model->insert_data('order_receipt' , $rec_detail);
				
				$order_detail = $this->langar_model->select_data('order.*,users.user_id,users.user_name,users.user_email,users.user_contact ,payment.pay_currency, payment.pay_amount' , 'order' , array('order_id' => $_POST['order_id']) , 1 , '' , '' , array('multiple' , array(array('users' , 'users.user_id = order.user_id'), array('payment', 'payment.pay_id = order.payment_id'))));
				
				if(!empty($order_detail)){
					$template_data = array('user_name' => $order_detail['0']['user_name'], 'request_id' => $order_detail['0']['order_uniq']);
					$message = $this->load->view('front/template/sewa_receipt', $template_data , true);
					$this->load->library('send_mail'); // load mail library
					$file = explode('application/',dirname(__FILE__))[0].'/assets/img/receipt/'.$rec;
					$this->send_mail->mail_send($order_detail['0']['user_email'] , 'Sewa Receipt' , $message , $file);	
				}
				
				$this->session->set_flashdata('success','Receipt saved successfully.');
			}else{
				$this->session->set_flashdata("error","Invalid image formate.");
			}
		}else{
			$this->session->set_flashdata("notice","Receipt should be require.");
		}
		redirect($this->agent->referrer());
	}
	
	
	function remove_receipt($rec_id){
		if(isset($rec_id)){
			$this->load->library('image_control');
			$rec_detail = $this->langar_model->select_data('rec_name' , 'order_receipt' , array('rec_id' => $rec_id));
			if(!empty($rec_detail)){
				$rec_name = $rec_detail['0']['rec_name'];
				$this->image_control->remove_image('/assets/img/receipt/' , $rec_name);
				$this->langar_model->delete_data('order_receipt' , array('rec_id' => $rec_id));
				$this->session->set_flashdata("success","Receipt removed successfully.");
			}
		}
		redirect($this->agent->referrer());
	}
	
	
	function up_order_status(){
		if(isset($_POST['order_status'])){
			$this->langar_model->update_data('order' , array('order_status' =>$_POST['order_status'] , 'completed_date' => date('Y-m-d H:i:s')) , array('order_id' => $_POST['order_id']));
			$this->session->set_flashdata('success','Order detail updated successfully.');
		
			$order_detail = $this->langar_model->select_data('order.*,users.user_id,users.user_name,users.user_email,users.user_contact ,payment.pay_currency, payment.pay_amount' , 'order' , array('order_id' => $_POST['order_id']) , 1 , '' , '' , array('multiple' , array(array('users' , 'users.user_id = order.user_id'), array('payment', 'payment.pay_id = order.payment_id'))));
			if(!empty($order_detail)){
				$currency = $order_detail['0']['pay_currency'];
				$c_symbol = ($currency == 'USD')?'&#x24;':(($currency == 'GBP')?'&#xa3;':(($currency == 'EURO')?'&euro;':(($currency == 'INR')?'&#8360;':'')));
				
				$template_data = array('user_name' => trim($order_detail['0']['user_name']), 'reqest_date' => $order_detail['0']['request_date'], 'request_id' => $order_detail['0']['order_uniq'], 'sewa_amount' => $c_symbol.$order_detail['0']['pay_amount'], 'complete_date' => $order_detail['0']['completed_date']);
				
				$this->load->library('send_mail');
				$message = $this->load->view('front/template/sewa_complete', $template_data , true);
				
				$this->send_mail->mail_send($order_detail['0']['user_email'] , 'Sewa Completed' , $message);
			}
			
			
			
		}
		redirect($this->agent->referrer());
	}
	// add gallery images
	function add_gallery_image(){
		if(isset($_FILES['add_image'])){
			$allowed =  array('jpeg','png' ,'jpg');
			$ext = pathinfo($_FILES['add_image']['name'], PATHINFO_EXTENSION);
			if(in_array($ext,$allowed) ) {
				$this->load->library('image_control'); 
				$path = '/assets/img/gallery/';
				$up_images = $this->image_control->upload_image('/assets/img/gallery/' , 'add_image'); 
				//$this->image_control->resizeImage($path , $up_images , 600 , 1066 , 0 , 1);
				$this->image_control->resizeImage($path , $up_images , 83 , 83 , 1 , 0);
				$this->langar_model->insert_data('gallery' , array('g_image' => $up_images));
				$this->session->set_flashdata('success','Image added successfully.');
			}else{
				$this->session->set_flashdata("error","Invalid image formate.");
			}
		}else{ 
			$this->session->set_flashdata("error","Please select images.");
		}
		
		redirect($this->agent->referrer());	
	}
	
	
	// remove gallery image 
	function remove_gallery_image($img_id){
		$img_detail = $this->langar_model->select_data('g_image' , 'gallery' , array('g_id' => $img_id));
		if(!empty($img_detail)){
			$img = $img_detail['0']['g_image'];
			$thumb = explode('.',$img);
			$thumb_image = $thumb[0].'_thumb.'.$thumb[1];
			$this->load->library('image_control');
			$this->image_control->remove_image('/assets/img/gallery/' , $img);
			$this->image_control->remove_image('/assets/img/gallery/' , $thumb_image);
			$this->langar_model->delete_data('gallery' , array('g_id' => $img_id));
			$this->session->set_flashdata('success','Image removed successfully.');
		}	
		redirect($this->agent->referrer());	
	}
	
	function up_langar_sewa_message(){
		if(isset($_POST['l_title']) && trim($_POST['l_title']) != '' && isset($_POST['l_description']) && trim($_POST['l_description']) != ''){
			$this->langar_model->update_data('l_sewa' , array('l_title' => $_POST['l_title'] , 'l_description' => $_POST['l_description']) , array('l_id' => 1));
			$this->session->set_flashdata("success","Data updated successfully.");
		}else{
			$this->session->set_flashdata("notice","All fields are required.");
		}
		redirect($this->agent->referrer());	
	}
	
	
	
	function update_profile(){
		if(isset($_FILES['profile_img']['name']) && $_FILES['profile_img']['name'] != ''){
			$this->load->library('image_control');
			$profile_img = $this->image_control->upload_image('/assets/img/profile/' , 'profile_img' , 'adm');
			$this->image_control->resizeImage('/assets/img/profile/' , $profile_img , '150' , '150' , '0' , '0');
			if($this->session->userdata('profile') != 'profile.jpg'){
				$this->image_control->remove_image('/assets/img/profile/' , $this->session->userdata('profile'));// remove current prfile
			}
			
			$this->langar_model->update_data('admin' , array('profile_image' => $profile_img) , array('admin_id' => 1) , 1);
			$this->session->set_userdata(array('profile' => $profile_img));
			$this->session->set_flashdata('success','Profile picture updated successfully.');
		}else{
			$this->session->set_flashdata('error','Choose your profile image.'); 
		}
		redirect($this->agent->referrer());
	}

	function update_setting(){
		if(isset($_POST['save'])){
			$site_data = array(
							'site_name' => trim($_POST['name']),
							'site_title' => trim($_POST['title']),
							'site_email' => trim($_POST['email']),
							'site_contact' => trim($_POST['contact']),
							'site_keywords' => trim($_POST['keyword']),
							'site_description' => trim($_POST['description']),
							'site_copyright' => trim($_POST['copyright']),
							);
			$this->langar_model->update_data('site_detail' , $site_data , array('site_id' => 1));	
			$this->session->set_flashdata('success','Site detail updated successfully.');	
		}
		redirect($this->agent->referrer());
	}
	
	
	function update_notification(){
		if(isset($_POST['n_text']) && trim($_POST['n_text']) != ''){
			$notif = array(
						'notice_text' => 	trim($_POST['n_text']),
						'notice_status' => $_POST['n_status']
						);
			$this->langar_model->update_data('notice_message' , $notif , array('notice_id' => 1));	
			$this->session->set_flashdata('success','Notice detail updated successfully.');				
		}
		redirect($this->agent->referrer());
	}
	
	
	// code for ajax 
	
	function remove_contact(){
		if(isset($_POST['c_id'])){
			echo $this->langar_model->delete_data('contact' , array('contact_id' => $_POST['c_id'])); 
		}else{
			echo false;
		}
	}
	
	
	
	
	
}
