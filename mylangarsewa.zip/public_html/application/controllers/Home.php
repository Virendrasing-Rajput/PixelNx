<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
	function __Construct(){
		parent::__Construct(); 
	}	
	
	
	public function index(){ 
		$this->langar_sewa();
		/*$this->load->view('front/include/header',$data);
		$this->load->view('front/about');
		$this->load->view('front/include/footer'); */
	}
	
	
	function about(){  
		$data['about'] = true;
		$this->load->view('front/include/header',$data);
		$this->load->view('front/about');
		$this->load->view('front/include/footer'); 
	} 
	
	function langar_sewa(){ 
		//$this->index();
		$data['langar_sewa'] = 1;
		$data['item_detail'] = $this->langar_model->select_data('item_id,item_name' , 'item' , array('item_status' => 1));
		$data['testimonial_detail'] = $this->langar_model->select_data('testimonial.* , users.user_name' , 'testimonial' , '' , '' , array('testimonial_id' , 'DESC') , '' , array('users','users.user_id = testimonial.member_id'));
		$data['gallery_image'] = $this->langar_model->select_data('g_image' , 'gallery' , '' , '' , array('g_id' , 'DESC'));
		if($this->session->userdata('role') == 2){
			$data['user_contact'] = $this->langar_model->select_data('user_contact' , 'users' , array('user_id' => $this->session->userdata('id')))['0']['user_contact'];
		}
		$this->load->view('front/include/header',$data);
		$this->load->view('front/index',$data);
		$this->load->view('front/include/footer',$data);
		/*
		$data['langar_message'] = $this->langar_model->select_data('*' , 'l_sewa');
		$data['gallery_image'] = $this->langar_model->select_data('g_image' , 'gallery');
		$data['recent_post_data'] = $this->recent_post_side();
		$data['post_category_data'] = $this->post_category_side();
		$data['langar_sewa'] = true;
		$this->load->view('front/include/header',$data);
		$this->load->view('front/langar_sewa');
		$this->load->view('front/include/footer'); */
	}
	
	
	
	
	function blog($blog_slug = NULL){
		$data['blog'] = true;
		$data['recent_post_data'] = $this->recent_post_side();
		$data['post_category_data'] = $this->post_category_side();
		$this->load->view('front/include/header',$data);
		if($blog_slug != ''){
			$check_blog = $this->langar_model->select_data('blog_post.*','blog_post' , array('post_slug' => $blog_slug, 'post_status' => 1) , 1);
			if(!empty($check_blog)){
				$data['blog_detail'] = $check_blog;
				$this->load->view('front/blog_single',$data);
			}else{
				redirect(base_url('blog'));
			}
		}else{
			$this->load->library('ci_pagination');
			$count_comment = $this->langar_model->aggregate_data('blog_post' , 'post_id' , 'COUNT' , array('post_status' => 1));
			$current_key = (isset($_POST['ci_pagination_key']))?$_POST['ci_pagination_key']:0;
			$data['pagination_data'] = $this->ci_pagination->pagination_data($count_comment, $current_key , 2); 
			
			$data['blog_detail'] = $this->langar_model->select_data('post_slug,post_title,post_image,post_description,post_date','blog_post' , array('post_status' => 1) , array(2 , $current_key) , array('post_id','DESC'));
			
			$this->load->view('front/blog',$data);
		}
		$this->load->view('front/include/footer');
	}
	
	function contact(){
		if(isset($_POST['c_name']) && isset($_POST['c_email'])){
			$contact_detail = array(
									'contact_name' => trim($_POST['c_name']),
									'contact_email' => trim($_POST['c_email']),
									'contact_subject' => trim($_POST['c_subject']),
									'contact_message' => trim($_POST['c_message'])
									);
			$this->langar_model->insert_data('contact' , $contact_detail);
			$this->session->set_flashdata('success','Message send successfully.');	
			redirect(base_url('contact'));	
		}
		$data['contact'] = true;
		$this->load->view('front/include/header',$data);
		$this->load->view('front/contact');
		$this->load->view('front/include/footer');
	}
	
	function sign_up(){
		if(isset($_POST)){
			$check_detail = $this->langar_model->select_data('user_id' , 'users' , array('user_email' => trim($_POST['uEmail'])));
			if(empty($check_detail)){
				$code = md5(microtime());
				$user_detail = array(
							'user_name' => trim($_POST['uName']),
							'user_email' => trim($_POST['uEmail']),
							'user_password' => md5(trim($_POST['uPassword'])),
							//'user_dob' => date('Y-m-d',strtotime(trim($_POST['uDOB']))),
							'verification_code' => $code
							);
				$this->langar_model->insert_data('users' , $user_detail);
			
				$this->load->library('send_mail'); 
				$template_data = array('user_name' => trim($_POST['uName']), 'verify_link' => base_url('verification/'.$code));
				
				$message = $this->load->view('front/template/email_confirmation', $template_data , true); 
				
				$this->send_mail->mail_send(trim($_POST['uEmail']) , 'Email Verification' , $message);
				$this->session->set_flashdata('success','Please check your email to verify your account.');
			}else{
				$this->session->set_flashdata('notice','Email already exists.');
			}
			redirect($this->agent->referrer());
		}else{
			redireact(base_url());
		}
	}
	
	
	function recent_post_side(){
		$recent_post_data = '';	
		$recent_post = $this->langar_model->select_data('post_id,post_slug,post_title,post_date','blog_post' , array('post_status' => 1) , 5 , array('post_id','DESC'));	
		if(!empty($recent_post)){
			foreach($recent_post as $rec_post){
				$count_comment = $this->langar_model->aggregate_data('blog_comment' , 'comment_id' , 'COUNT' , array('comment_parent' => 0 , 'post_id' => $rec_post['post_id']));
				
				$recent_post_data .=  '
					<li>
						<div class="entery-c">
							<div class="entry-date">
								<h3>'.date('M d, Y' , strtotime($rec_post['post_date'])).'</h3>
							</div>
							<div class="entry-comment-no">
								<a><i class="fa fa-comments" aria-hidden="true"></i> '.$count_comment.'</a>
							</div>
							<a href="'.base_url('blog/'.$rec_post['post_slug']).'">
								<p>'.$rec_post['post_title'].'</p>
							</a>	
						</div>
					</li>';
			}
		}
		return $recent_post_data;
	}
	
	function post_category_side(){
		$post_category_data = '';
		$blog_category_detail = $this->langar_model->select_data('category_slug,category_title','blog_category' , array('category_status' => 1) , '' , array('category_id','DESC'));
		if(!empty($blog_category_detail)){
			foreach($blog_category_detail as $category){
				$post_category_data .= '<li><a>'.$category['category_title'].'</a></li>';
			}
		}
		return $post_category_data;
	}
	
	
	
	
	
	
	
	/*****************************************************/
	/**************EMAIL VERIFICATION CODE START**********/
	/*****************************************************/
	function verification($v_code , $reset = NULL){
		$check_detail = $this->langar_model->select_data('*','users' , array('verification_code' => $v_code) , 1); 
		$e_vefication = (!empty($check_detail))?$check_detail['0']['email_verification']:0;
		$data['type'] = (isset($reset) && $e_vefication == 1)?2:1;
		if(!empty($check_detail)){
			if($data['type'] == 1){
				$this->langar_model->update_data('users', array('email_verification' =>1 , 'verification_code' => '') , array('verification_code' => $v_code) , 1);
			}
			$data['status'] = 1;
		}else{
			$data['status'] = 0;
		}
		$this->load->view('front/include/header',$data);
		$this->load->view('front/verification',$data);
		$this->load->view('front/include/footer');
	}
	/***************EMAIL VERIFICATION CODE END***********/
	
	
	
	/*****************************************************/
	/****************RESET PASSWORD CODE START************/
	/*****************************************************/
	function reset_password($v_code){
		if(isset($_POST['pass']) && isset($_POST['re_pass'])){
			if(strlen(trim($_POST['pass'])) >= 6){
				if(trim($_POST['pass']) == trim($_POST['re_pass'])){
					$this->langar_model->update_data('users', array('user_password' =>md5(trim($_POST['pass'])) , 'verification_code' => '') , array('verification_code' => $v_code) , 1);
					$this->session->set_flashdata('success','Your password reset successfully.');
					redirect(base_url());
				}else{
					$this->session->set_flashdata('notice','Both password should be same.');
					redirect(base_url('reset-password/'.$v_code));
				}
			}else{
				$this->session->set_flashdata('notice','Password should be more than six charecter.');
				redirect(base_url('reset-password/'.$v_code));
			}
		}else{
			$this->verification($v_code , 1);	
		}
	}
	/****************RESET PASSWORD CODE END**************/
	
	
	
	/*****************************************************/
	/****************PAYPAL PAYMENT CODE START************/
	/*****************************************************/
	function pay(){
		if(isset($_POST['select_currency']) && isset($_POST['sewa_amount'])){	
			$currency = $_POST['select_currency'];
			$amount = $_POST['sewa_amount'];
			if(($currency == 'INR' AND trim($amount) >= 2000) OR ($currency == 'USD' AND trim($amount) >= 25) OR ($currency == 'GBP' AND trim($amount) >= 20) OR ($currency == 'EURO' AND trim($amount) >= 20)){
				$pay_code = substr(md5(microtime()), 0 , 5);
				$this->session->set_userdata(array('payment_code' => $pay_code));
				$sewa_detail = array(
								'selected_item' => (isset($_POST['item']))?json_encode($_POST['item']):'',
								'expected_date' => $_POST['expected_date'],
								's_name' => $_POST['s_name'],
								's_phone' => $_POST['s_phone'],
								's_email' => $_POST['s_email'],
								'payment_code' => $pay_code
								);
			 
				//https://www.paypal.com/cgi-bin/webscrr
				//https://www.sandbox.paypal.com/cgi-bin/webscr
				//$amount = '0.1';
				$form_data = array('business' => 'paypal@mylangarsewa.com' , 'item_name' => 'My Langar Sewa' , 'amount' => $amount , 'no_shipping' => '1' , 'currency_code' => $_POST['select_currency'] , 'cmd' => '_xclick' , 'no_note' => '1' , 'custom' => json_encode($sewa_detail) , 'cancel_return' => base_url('payment_cancel') , 'return' => base_url('pay-notice') , 'notify_url' => base_url('home/payment_notify') , 'image_url' => base_url($this->site_detail->site_logo));
				 
				header('Location: https://www.paypal.com/cgi-bin/webscrr?' . http_build_query($form_data));
			}else{
				$amt = ($currency == 'INR')?3000:50; 
				$this->session->set_flashdata('error','Minimum amount should be '.$amt.$currency);
				redirect(base_url());
			}
		}else{
			redirect(base_url());
		}
	}
	
	function payment_cancel(){
		$this->pay_notice('Cancel');
	}
	
	function payment_notify(){
		if(isset($_POST['custom'])){
			$this->check_payment($_POST); 
		}
	}
	
	function pay_ipn(){  
		if(isset($_POST['custom'])){
			$this->check_payment($_POST);
		}
	}
	
	function pay_notice($pay_status = NULL){
		if($this->session->userdata('payment_code')){
			$data['pay_notice'] = 1;
			if($pay_status != ''){
				$data['pay_status'] = $pay_status;
			}else{
				$payment_status = $this->langar_model->select_data('status' , 'ckeck_payment' , array('pay_no' => $this->session->userdata('payment_code') , 'show' => 0)); 
				if(!empty($payment_status)){
					$data['pay_status'] = $payment_status['0']['status'];
					$this->langar_model->update_data('ckeck_payment' , array('show'=> 1) , array('pay_no' => $this->session->userdata('payment_code')));
					$this->session->unset_userdata('payment_code');
				}else{
					redirect(base_url());
				}	
			}
			
			
			$this->load->view('front/include/header',$data);
			$this->load->view('front/verification',$data);
			$this->load->view('front/include/footer');		
		}else{
			redirect(base_url());
		}
	}
	
	function check_payment($payment_detail){
		 
		$order_data = json_decode($payment_detail['custom']); 		
		 
		$check_pay =  $this->langar_model->select_data('pay_id' , 'payment' , array('pay_code' => $order_data->payment_code));
		
		if(empty($check_pay)){ 
			$status = ($payment_detail['payment_status'] == 'Completed')?1:0;
			
			$pay_deta = array('pay_no' => $order_data->payment_code, 'status' => $payment_detail['payment_status'], 'pay_data' => json_encode($payment_detail));
			$this->langar_model->insert_data('ckeck_payment' , $pay_deta); // check payment detail
			if($status == 1){
				$pay_detail = array(
								'pay_currency' => $payment_detail['mc_currency'],
								'pay_amount' => $payment_detail['mc_gross'],
								'payer_id' => $payment_detail['payer_id'],
								'txn_id' => $payment_detail['txn_id'],
								'payment_status' => $payment_detail['payment_status'],
								'payer_email' => $payment_detail['payer_email'],
								'pay_status' => $status,
								'pay_code' => $order_data->payment_code
								);
						
				$pay_id = $this->langar_model->insert_data('payment', $pay_detail); 
				
				$template_data = array('user_name' => $order_data->s_name);
				
				$check_user = $this->langar_model->select_data('*' , 'users' , array('user_email' => $order_data->s_email));
				if(!empty($check_user)){
					$user_id = $check_user['0']['user_id'];
					$mem_name = $check_user['0']['user_name'];
					$mem_email = $check_user['0']['user_email'];
					$mem_contact = $check_user['0']['user_contact'];
				}else{
					$mem_name = $order_data->s_name;
					$mem_email = $order_data->s_email;
					$mem_contact = $order_data->s_phone;
					
					$pass = substr(md5(microtime()), 0 , 7);
					$user_data = array(
										'user_name' => $order_data->s_name,
										'user_contact' => $order_data->s_phone,
										'user_email' => $order_data->s_email,
										'user_s_email' => $payment_detail['payer_email'],
										'user_password' => md5($pass),
										'email_verification' => 1
										);
					$user_id = $this->langar_model->insert_data('users' , $user_data);
					
					$template_data['email'] = $order_data->s_email;
					$template_data['password'] = $pass;
				}
				
				$order_id = substr(md5(microtime().$pay_id),0,8);
				$template_data['request_id'] = $order_id;
				$order_detail = array(
									'order_uniq' => $order_id,
									'user_id' => $user_id,
									'payment_id' => $pay_id,
									'selected_item' => $order_data->selected_item,
									'arrival_temple' => ($order_data->expected_date != '')?1:0,
									'expected_date' => $order_data->expected_date,
									'request_date' => date('Y-m-d H:i:s')
									);
				$this->langar_model->insert_data('order' , $order_detail);
				
				$message = $this->load->view('front/template/sewa_request', $template_data , true); // member mail template detail
								
				$this->load->library('send_mail');
				
				$this->send_mail->mail_send($order_data->s_email , 'Sewa Request Submitted' , $message); // mail to member
				
				
				if($order_data->s_email != $payment_detail['payer_email']){
					$this->send_mail->mail_send($payment_detail['payer_email'] , 'Sewa Request Submitted' , $message);
				} 
				$currency = $payment_detail['mc_currency'];
				$c_symbol = ($currency == 'USD')?'&#x24;':(($currency == 'GBP')?'&#xa3;':(($currency == 'EURO')?'&#x80;':(($currency == 'INR')?'&#8360;':'')));
			
				/* mail to request notice admin*/
				$admin_data = array('request_id' => $order_id, 'sewa_amount' => $c_symbol.' '.$payment_detail['mc_gross'], 'm_name' => $mem_name, 'm_email' => $mem_email , 'm_contact' =>$mem_contact);
				$admin_template = $this->load->view('front/template/sewa_notice_admin', $admin_data , true);
				
				$this->send_mail->mail_send($this->site_detail->site_email , 'New Sewa Request' , $admin_template); // mail to admin
				
				// SMS notice to admin
				
				$mob_no = '9826258326,8725912995,7828132331';
				$message = 'New Sewa Request
				
				Member Detail:
				Name- '.$mem_name.',
				Email- '.$mem_email.',
				Contact- '.$mem_contact.',
					
				Sewa detail:
				Request ID- '.$order_id.',
				Sewa Amount- '.$currency.' '.$payment_detail['mc_gross'];
				$url = 'https://control.msg91.com/api/sendhttp.php?authkey=127466ArvSKqlWC57f5f814&mobiles='.$mob_no.'&message='.urlencode($message).'&sender=MLSewa&response=json&route=4';
				$ch = curl_init($url);
				curl_setopt($ch, CURLOPT_HEADER, false);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
				$resp  = curl_exec($ch);
				$json = json_decode($resp);
			}
		}
	}
	
	/****************PAYPAL PAYMENT CODE END**************/
	
	/*****************************************************/
	/********************LOGOUT CODE START****************/
	/*****************************************************/
	function logout(){
		$this->session->sess_destroy();
		redirect(base_url());
	}	
	/*******************LOGOUT CODE END*******************/
	
	
	function check($temp){
		$data['reqest_date'] = '21-9-2016';
		$data['complete_date'] = date('d-m-Y');
		$data['request_id'] = 'as12sa';
		$data['sewa_amount'] = '$50';
		$data['verify_link'] = 'sadsadsadsadfd';
		$data['profile_link'] = 'sadsadsadsadfd';
		$data['user_name'] = 'Praduman';
		$data['forgot_password'] = 'sadsadsadsadfd';
		$data['reset_link'] = 'sadsadsadsadfd';
		
		$data['m_name'] = 'praduman';
		$data['m_email'] = 'p@asd.com';
		$data['m_contact'] = '7828132331';
		
		
		$this->load->view('front/template/'.$temp.'.php', $data);
	}
	
	
}
