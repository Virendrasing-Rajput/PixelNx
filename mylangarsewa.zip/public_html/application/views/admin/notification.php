          <div class="dg_page_heading">
            <h4><i class="flaticon-book119"></i>Notification</h4>
          </div>
          <section class="dg-wrapper">
            <div class="dg_bottom_content_section">
              <div class="row">
                <div class="col-md-12">
                  <div class="dg_heading">
                    <h5>Notification Detail</h5>
                  </div>
					<div class="row">
						<div class="col-md-12">
						<?php
						if(isset($notification_detail) && !empty($notification_detail)){
							$n_text = $notification_detail['0']['notice_text'];
							$n_status = $notification_detail['0']['notice_status'];
						}else{
							$n_text = '';
							$n_status = '';
						}
						?>
							<form method="post" action="<?php echo base_url('admin_action/update_notification'); ?>" onsubmit="return  check_form(this);">
							  <div class="dg_white_backup spacer40">
								<div class="col-md-12">
									<div class="form-group">
										<textarea style="width:100%" class="form-control require" rows="2" name="n_text" placeholder="Typr your notification here..."><?php echo $n_text; ?></textarea>
									</div>
									<div class="form-group">
										<select name="n_status" class="form-control">
											<option value="1" <?php echo ($n_status == 1)?'selected':''; ?>>Active</option>
											<option value="0" <?php echo ($n_status == 0)?'selected':''; ?>>In-Active</option>
										</select>
									</div>
								</div>
								<div class="col-md-12">
								  <button type="submit" class="btn btn-primary pull-right upper_spacer5">Submit</button>
								</div>
							  </div>
						  
							</form>	
						</div>
					</div>
                </div>
              </div>
              <!-- row end -->
            </div>
          </section>
      </section>
	</section>