		<div class="dg_page_heading">
			<h4><i class="flaticon-award47"></i>Sewa</h4>
		</div>
		<section class="dg-wrapper">
			<?php
			if(!isset($single)){
				?>
				<div class="dg_bottom_content_section">
					<div class="row">
						<div class="col-md-6">
						  <div class="dg_review text-center">
							<p>Total Sewa In-Complete</p>
							<h2><?php echo (isset($sewa_remaining))?$sewa_remaining:0; ?></h2>
							<?php 
								$mem = (isset($_GET['member']) && $_GET['member'] != '')?'&member='.$_GET['member']:'';
							?>
							<!--<a href="<?php echo base_url('admin/sewa?status=0'.$mem); ?>" class="dg_blue">View Item Lists</a>-->
						  </div>
						</div>
						<div class="col-md-6">
						  <div class="dg_review text-center">
							<p>Total Sewa Complete</p>
							<h2><?php echo (isset($sewa_completed))?$sewa_completed:0; ?></h2>
							<!--<a href="<?php echo base_url('admin/sewa?status=1'.$mem); ?>" class="dg_blue">View Item Lists</a> -->
						  </div>
						</div>
						<div class="col-md-12">
							<div class="dg_white_backup">
								<form method="post">
									<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
										<div class="dg_input_search">
											<input type="text" class="form-control" placeholder="Request ID" name="request_id" value="<?php echo (isset($request_id) && $request_id != '')?$request_id:''; ?>" > 
										</div>
									</div>
									<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
										<div class="dg_input_search">
											<select name="status" class="form-control">
												<option value="">Choose One</option>
												<option <?php echo (isset($status) && $status == 1)?'selected':''; ?> value="1">Complete</option>
												<option <?php echo (isset($status) && $status == 0)?'selected':''; ?> value="0">In-Complete</option>
											</select>
										</div>
									</div>
									<div class="col-lg-1 col-md-2 col-sm-12 col-xs-12 mini_upper_spacer">
										<button class="btn btn-primary" type="submit">Search</button>
									</div>
								</form>
							</div>
						</div>
					</div>
					
					<div class="row">
						<div class="col-md-12 spacer40">
						  <div class="dg_heading">
							<h5>Sewa Detail</h5>
							<!--<span class="pull-right">
							  <a href="add_reviewer.html" class="btn_black dg_btn">
								Add Reviewer
							  </a>
							</span> -->
						  </div>
							<?php 
							if(isset($sewa_deta) && !empty($sewa_deta)){
								?>
								<table class="display dg_whole_table">
									<thead>
										<tr>
											<th>S. No.</th>
											<th>Request ID</th>
											<th>Donator Name</th>
											<th>Donator Email</th>
											<th>Donate Date</th>
											<th>Donate Amount</th>
											<th>Status</th>
											<th>Action</th>
										</tr>
									</thead>
									<tbody>
										<?php 
										$cnt = 1;
										foreach($sewa_deta as $sewa){
											$currency = $sewa['pay_currency'];
											$c_symbol = ($currency == 'USD')?'&#x24;':(($currency == 'GBP')?'&#xa3;':(($currency == 'EURO')?'&euro;':(($currency == 'INR')?'&#8360;':'')));
											$status = ($sewa['order_status'] == 1)?'Complete':'In-Complete';
											echo '
											<tr>
												<td>'.$cnt++.'</td>
												<td>'.$sewa['order_uniq'].'</td>
												<td>'.$sewa['user_name'].'</td>
												<td>'.$sewa['user_email'].'</td>
												<td>'.date('d M, Y', strtotime($sewa['request_date'])).'</td>
												<td>'.$c_symbol.$sewa['pay_amount'].'</td>
												<td>'.$status.'</td>
												<td>
													<ul class="dg_action">
														<li class="dg_view">
														  <a href="'.base_url('admin/sewa/'.$sewa['order_uniq']).'" title="View Detail">
															<i class="fa fa-eye"></i>
														  </a>
														</li>
													</ul>		
												</td>
											</tr>';
										}
										?>
									</tbody>
								</table>
								<?php
							}else{
								?>
								<div class="alert alert-warning dg_queue_update empty" role="alert">
									<span class="dg_alerts_setting">
									  <i class="flaticon-warning30">
									  </i>
									  Info
									</span>
									<span class="dg_alert_text">
									  No records found...
									</span>
								</div>	
								<?php
							}	
							?>
							
						</div>
					</div>
				  <!-- row end -->
				</div>
				<?php
			}elseif(isset($single)){
				?>
					<?php /*<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
						<div class="ls_imguploader">
							<div class="row">
								<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
									<label>Upload Receipt</label>
								</div>
								<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">
									<strong>:-</strong>
								</div>
								<div class="col-lg-7 col-md-7 col-sm-6 col-xs-12">
									<div class="dg_floatable">
										<input id="uploadFile" placeholder="Choose File" disabled="disabled" class="form-control">
										<div class="file-upload btn btn-primary">
											<span>Upload</span>
											<input id="uploadBtn1" type="file" class="upload" name="post_image">
										</div>
										<span class="dg_btm_text">JPG or PNG 845x350px</span>
									</div>
								</div>
							</div>	
						</div>
					</div>*/?>
					<?php
					if(isset($order_detail) && !empty($order_detail)){
						$currency = $order_detail['0']['pay_currency'];
						$c_symbol = ($currency == 'USD')?'&#x24;':(($currency == 'GBP')?'&#xa3;':(($currency == 'EURO')?'&euro;':(($currency == 'INR')?'&#8360;':'')));
						?>
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
							<div class="dg_heading">
								<h5>Sewa Detail</h5>
								<span class="pull-right">
									 <?php echo ($order_detail['0']['order_status'] == 1)?'<h5>Sewa Completed</h5>':'<a data-toggle="modal" data-target="#add_receipt">
										<span class="btn_black dg_btn">Add Receipt</span>
									</a>'; ?>
									
								</span>
							</div>
							<div class="ls_donator_profile">
								<div class="row">
									<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 col-lg-offset-3 col-md-offset-3 col-sm-offset-3">
										<h3 class="ls_heading">Sewa Detail</h3>
									</div>
								</div>
								<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 col-lg-offset-2 col-md-offset-2">
									<div class="ls_profilediv">
										<div class="row">
											<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
												<label>Sewa Status</label>
											</div>
											<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">
												<span>:-</span>
											</div>
											<div class="col-lg-7 col-md-7 col-sm-6 col-xs-12">
												<form method="post" action="<?php echo base_url('admin_action/up_order_status'); ?>">
													<input type="hidden" value="<?php echo $order_detail['0']['order_id']; ?>" name="order_id">
													<div class="col-lg-8 col-md-8 col-sm-6 col-xs-12">
														<select name="order_status" class="form-control">
															<option value="1" <?php echo ($order_detail['0']['order_status'] == 1)?'selected':''; ?>>Complete</option>
															<option value="0" <?php echo ($order_detail['0']['order_status'] == 0)?'selected':''; ?>>In-Complete</option>
														</select>
													</div>	
													<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
														<button class="btn btn-primary" type="submit">Save</button>
													</div>
												</form> 
											</div>
										</div>
									</div>
									
									<div class="ls_profilediv">
										<div class="row">
											<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
												<label>Request Id</label>
											</div>
											<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">
												<span>:-</span>
											</div>
											<div class="col-lg-7 col-md-7 col-sm-6 col-xs-12">
												<p><?php echo $order_detail['0']['order_uniq']; ?></p>
											</div>
										</div>
									</div>
									<?php echo ($order_detail['0']['order_status'] == 1)?'
									<div class="ls_profilediv">
										<div class="row">
											<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
												<label>Completed Date</label>
											</div>
											<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">
												<span>:-</span>
											</div>
											<div class="col-lg-7 col-md-7 col-sm-6 col-xs-12">
												<p>'.date('d M, Y',strtotime($order_detail['0']['completed_date'])).'</p>
											</div>
										</div>
									</div>':''; ?>
									<div class="ls_profilediv">
										<div class="row">
											<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
												<label>Donator Name</label>
											</div>
											<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">
												<span>:-</span>
											</div>
											<div class="col-lg-7 col-md-7 col-sm-6 col-xs-12">
												<p><?php echo $order_detail['0']['user_name']; ?></p>
											</div>
										</div>
									</div>
									<div class="ls_profilediv">
										<div class="row">
											<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
												<label>Contact Number</label>
											</div>
											<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">
												<span>:-</span>
											</div>
											<div class="col-lg-7 col-md-7 col-sm-6 col-xs-12">
												<p><?php echo $order_detail['0']['user_contact']; ?></p>
											</div>
										</div>
									</div>
									<div class="ls_profilediv">
										<div class="row">
											<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
												<label>Donator Email Id</label>
											</div>
											<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">
												<span>:-</span>
											</div>
											<div class="col-lg-7 col-md-7 col-sm-6 col-xs-12">
												<p><?php echo $order_detail['0']['user_email']; ?></p>
											</div>
										</div>
									</div>
									<div class="ls_profilediv">
										<div class="row">
											<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
												<label>Donate Date</label>
											</div>
											<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">
												<span>:-</span>
											</div>
											<div class="col-lg-7 col-md-7 col-sm-6 col-xs-12">
												<p><?php echo date('d M, Y', strtotime($order_detail['0']['request_date'])); ?></p>
											</div>
										</div>
									</div>
									<div class="ls_profilediv">
										<div class="row">
											<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
												<label>Donator Amount</label>
											</div>
											<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">
												<span>:-</span>
											</div>
											<div class="col-lg-7 col-md-7 col-sm-6 col-xs-12">
												<p><?php echo $c_symbol.$order_detail['0']['pay_amount']; ?></p>
											</div>
										</div>
									</div>
									<div class="ls_profilediv">
										<div class="row">
											<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
												<label>Item List</label>
											</div>
											<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">
												<span>:-</span>
											</div>
											<div class="col-lg-7 col-md-7 col-sm-6 col-xs-12">
												<p>
												<?php  
												if($order_detail['0']['selected_item'] != ''){
													$sel_item = json_decode($order_detail['0']['selected_item'] , true); 
												
													foreach($sel_item as $item){
														$item_d = $this->langar_model->select_data('item_name' , 'item' , array('item_id' => $item));
														if(!empty($item_d)){
															echo $item_d['0']['item_name'].', &nbsp;&nbsp;&nbsp;';
														}
													}
												}else{
													echo 'Not Selected';
												}
												
													
												?>
												
												</p>
											</div>
										</div>
									</div>
									<?php
									if($order_detail['0']['arrival_temple'] == 1){
										?>
										<div class="ls_profilediv"> 
											<div class="row">
												<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
													<label>Arrival Date</label>
												</div>
												<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">
													<span>:-</span>
												</div>
												<div class="col-lg-7 col-md-7 col-sm-6 col-xs-12">
													<p><?php echo date('d M, Y', strtotime($order_detail['0']['expected_date'])); ?></p>
												</div>
											</div>
										</div>
										<?php
									}
									
									$rec_detail = $this->langar_model->select_data('rec_id,rec_name' , 'order_receipt' , array('order_id' => $order_detail['0']['order_id'])); 
									if(!empty($rec_detail)){
									?>
										<div class="ls_profilediv">
											<div class="row">
												<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
													<label>Uploaded Receipt </label>
												</div>
												<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">
													<span>:-</span>
												</div>
												<div class="col-lg-7 col-md-7 col-sm-6 col-xs-12">
													<div class="row">
														<?php
														foreach($rec_detail as $rec){
														echo '
															<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
															<div class="ls_receipt_img">
																<a class="receipt_container" href="'.base_url('assets/img/receipt/'.$rec['rec_name']).'">
																<img src="'.base_url('assets/img/receipt/'.$rec['rec_name']).'" class="img-responsive">
																</a>
																<div class="ls_removeimg">
																	<a title="Remove Receipt" href="'.base_url('admin_action/remove_receipt/'.$rec['rec_id']).'"><i class="fa fa-times"></i></a>
																</div>
															</div>
															
														</div>';
														
														}
														?>
													</div>
												</div>
											</div>
										</div>
									<?php } ?>
								</div>
							</div>
						</div>
						<?php
					}
					?>
					
				<?php
			}
			?>
			
		</section>
	</section>
  
</section>
<?php 
if(isset($single) && isset($order_detail) && !empty($order_detail)){
	?>
	<div class="modal fade" id="add_receipt" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title" id="myModalLabel">Add Receipt</h4>
				</div>
				<form method="post" onsubmit="return check_form(this)" action="<?php echo base_url('admin_action/add_receipt'); ?>" enctype="multipart/form-data">
					<div class="modal-body">
						<div class="dg_floatable ls_uploadimg">
							<input type="hidden" name="order_id" value="<?php echo $order_detail['0']['order_id']; ?>">
							<input id="uploadFile" placeholder="Choose File" disabled="disabled" class="form-control">
							<div class="file-upload btn btn-primary">
								<span>Upload</span>
								<input id="uploadBtn1" type="file" class="upload image" name="rec_img">
							</div>
							<span class="dg_btm_text">jpg or png</span>
						</div>
					</div> 
					<div class="modal-footer">
						<button type="submit" class="btn btn-primary">Save</button>
					</div>
				</form>
			</div>
		</div>
	</div>
	<?php
}	
?>