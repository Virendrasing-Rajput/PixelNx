          <div class="dg_page_heading">
            <h4><i class="flaticon-browser16"></i>Contact</h4>
          </div>
          <section class="dg-wrapper">
            <div class="dg_bottom_content_section">
              <div class="row">
                <div class="col-md-12">
                  <div class="dg_heading">
                    <h5>Contact's Lists</h5>
                  </div>
				  <?php 
					if(isset($contact_detail) && !empty($contact_detail)){
						?>
						<table class="display dg_whole_table">
							<thead>
							  <tr>
								<th>S. No.</th>
								<th>Name</th>
								<th>Email</th>
								<th>Subject</th>
								<th>Date</th>
								<th>Message</th>
								<th>Action</th>
							  </tr>
							</thead>
							<tbody>
								<?php 
								$cnt = 1;
								foreach($contact_detail as $contact){
									$contact_id = $contact['contact_id'];	
									echo '
									<tr> 
										<td>'.$cnt++.'</td>
										<td>'.$contact['contact_name'].'</td>
										<td>'.$contact['contact_email'].'</td>
										<td>'.$contact['contact_subject'].'</td>
										<td>'.date('d M, Y' , strtotime($contact['contact_date'])).'</td>
										<td>'.$contact['contact_message'].'</td>
										<td>
										  <ul class="dg_action">
											<li class="dg_del">
											  <a onclick="remove_contact('."$contact_id".' , this)" title="delete"><i class="fa fa-times"></i></a>
											</li>
										  </ul>
										</td>
									  </tr>';
								}	
								?>	
							</tbody>
						</table> 
						<?php
					}else{
						?>
						<div class="alert alert-warning dg_queue_update empty" role="alert">
							<span class="dg_alerts_setting">
							  <i class="flaticon-warning30">
							  </i>
							  Info
							</span>
							<span class="dg_alert_text">
							  No records found...
							</span>
						</div>	
						<?php
					}
					?>	
                </div>
              </div>
              <!-- row end -->
            </div>
          </section>
      </section>
	</section>