		<div class="dg_page_heading">
			<h4><i class="flaticon-book119"></i>Testimonial</h4>
        </div>
        <section class="dg-wrapper">
			<div class="dg_bottom_content_section">
				<div class="row">
					<div class="col-md-12">
						<div class="dg_heading">
							<h5>Testimonial Detail</h5>
							<span class="pull-right">
								<a data-toggle="modal" class="clear_modal" data-target="#test_modal">
									<span class="btn_black dg_btn">Add Testimonial</span>
								</a>
							</span>
						</div>
						<div class="dg_main_form spacer20">
							<?php 
							if(isset($testimonial_detail) && !empty($testimonial_detail)){
								?>
								<table class="display dg_whole_table">
									<thead>
										<tr>
											<th>S. No.</th>
											<th>Member Name </th>
											<th>Testimonial Data</th>
											<th>Action </th>
										</tr>
									</thead>
									<tbody>
										<?php
										$cnt = 1;
										foreach($testimonial_detail as $testimonial){
											?>
											<tr>
												<td><?php echo $cnt++; ?></td>
												<td><?php echo $testimonial['user_name']; ?></td>
												<td><?php echo $testimonial['testimonial_data']; ?></td>
												<td>
													<ul class="dg_action">
														<li class="dg_del">
														  <a href="<?php echo base_url('admin_action/add_testimonial/del/'.$testimonial['testimonial_id']); ?>" title="delete"><i class="fa fa-times"></i></a>
														</li>
													</ul>
												</td>
											</tr>
											<?php
										}
										?>
									</tbody>
								</table>
								<?php
							}else{
								?>
								<div class="alert alert-warning dg_queue_update empty" role="alert">
									<span class="dg_alerts_setting">
									  <i class="flaticon-warning30">
									  </i>
									  Info
									</span>
									<span class="dg_alert_text">
									  No records found...
									</span>
								</div>	
								<?php
							}
							?>
						</div>
					</div>
				</div>
			</div>
          <!-- row end -->
        </section>
    </section>  
</section>  
	<!-- Button trigger modal -->
	<!-- Modal -->
	<div class="modal fade" id="test_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title" id="myModalLabel">Add Item</h4>
				</div>
				<form method="post" onsubmit="return check_form(this)" action="<?php echo base_url('admin_action/add_testimonial'); ?>">
					<div class="modal-body">
						<div class="form-group dg_single_form ">
							<label>Coose Member</label>
							<select class="form-control require" name="testi_by">
									<option value="">Choose One</option>
									<?php
									$user_detail = $this->langar_model->select_data('user_id,user_name' , 'users' , array('email_verification' => 1) , '' , array('user_id' , 'DESC'));
									if(!empty($user_detail)){
										foreach($user_detail as $testi){
											echo '<option value="'.$testi['user_id'].'">'.$testi['user_name'].'</option>';
										}
									}
									?>
								</select>
						</div> 
						<div class="form-group dg_single_form ">
							<label>Testimonial Detail</label>
							<span>
								<span><textarea maxlength="1000" rows="4" name="testi_data" placeholder="Testimonial Detail" class="form-control require"></textarea>
							</span>
						</div> 
					</div> 
					<div class="modal-footer">
						<button type="submit" class="btn btn-primary">Save</button>
					</div>
				</form>
			</div>
		</div>
	</div>