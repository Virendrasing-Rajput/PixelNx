	<?php 
	if(isset($blog_detail) && !empty($blog_detail)){
		$post_id = $blog_detail['0']['post_id'];
		$post_category = $blog_detail['0']['post_category'];
		$post_slug = $blog_detail['0']['post_slug'];
		$post_title = $blog_detail['0']['post_title'];
		$post_image = $blog_detail['0']['post_image'];
		$post_description = $blog_detail['0']['post_description'];
		$description_second = $blog_detail['0']['post_description_second'];
		$description_third = $blog_detail['0']['post_description_third'];
		$post_status = $blog_detail['0']['post_status'];
		$show_comment = $blog_detail['0']['show_comment'];
	}else{
		$post_id = '';
		$post_category = '';
		$post_slug = '';
		$post_title = '';
		$post_image = '';
		$post_description = '';
		$description_second = '';
		$description_third = '';
		$post_status = '';
		$show_comment = '';
	}	
	?>
	<div class="dg_page_heading">
          <h4>
            <i class="flaticon-list95">
            </i>
            Blog Post
          </h4>
        </div>
        <section class="dg-wrapper">
          <div class="dg_bottom_content_section">
            <div class="row">
              <div class="col-md-12">
                <div class="dg_heading">
                  <h5>Add Blog Post </h5>
				  <span class="pull-right">
						<a href="<?php echo base_url('admin/blog_post'); ?>"><span class="btn_black dg_btn">Manage Blog</span></a>
					</span>
                </div>
                <div class="dg_main_form spacer20 dg_addblogpage">
                  <form method="post" onsubmit="return check_blog_form(this)" action="<?php echo base_url('admin_action/update_post');?>" enctype="multipart/form-data">
					<?php 
						if(isset($post_id) && $post_id != ''){
							echo '<input type="hidden" name="post_id" value="'.$post_id.'">'; 
							echo '<input type="hidden" name="post_image" value="'.$post_image.'">'; 
						}
					?>
					<div class="form-group dg_single_form">
                      <div class="form-group dg_single_form">
                        <label>Image :</label>
                        <div class="dg_checked_section">
							<div class="dg_floatable">
                              <p>
                                <input id="uploadFile" placeholder="Choose File" disabled="disabled" class="form-control" />
                              </p>
                              <div class="file-upload btn btn-primary">
                                <span>Upload</span>
                                <input id="uploadBtn1" type="file" class="upload image" name="post_image"/>
                              </div>
                              <span class="dg_btm_text">jpg or png 845x350px</span>
                            </div>
                        </div>
                      </div>	
                    </div>
                   <?php /* <div class="form-group dg_single_form">
						<label>Category :</label>
						<span>
						  <select class="form-control require" name="post_category">
							<?php
							$cate_detail = $this->langar_model->select_data('category_id,category_title' , 'blog_category' , array('category_status' => 1));
							if(!empty($cate_detail)){
								foreach($cate_detail as $cate){
									$sel = ($post_category == $cate['category_id'])?'selected':'';
									echo '<option '.$sel.' value="'.$cate['category_id'].'">'.$cate['category_title'].'</option>';
								}
							}
							?>
						  </select>
						</span>
					</div> */ ?>
                    <div class="form-group dg_single_form">
                      <label for="dg_post_title">Post Title :</label>
                      <span>
                        <input type="text" id="dg_post_title" value="<?php echo $post_title; ?>" name="post_title" placeholder="The Latest From Our Journal" class="form-control require">
                        <span class="help-block with-errors">
                        </span>
                      </span>
                    </div>
                    <div class="form-group dg_single_form">
                      <label>Post Description :</label>
                      <span>
                        <textarea class="form-control require" rows="7" placeholder="Description" name="post_desc"><?php echo $post_description; ?></textarea>
                      </span>
                    </div>
                    <div class="form-group dg_single_form">
                      <label>Post Second Description :</label>
                      <span>
                        <textarea class="form-control require" rows="4" name="post_desc_sec"><?php echo $description_second; ?></textarea>
                      </span>
                    </div>
                    <div class="form-group dg_single_form">
                      <label>Post Third Description :</label>
                      <span>
                        <textarea class="form-control require" rows="3" name="post_desc_thi"><?php echo $description_third; ?></textarea>
                      </span>
                    </div>
                    <div class="form-group dg_single_form">
                      <label>Post Statue :</label>
                      <span>
                        <select class="form-control" name="post_status">
                          <option value="1" <?php echo ($post_status == 1)?'selected':''; ?>>Active</option>
                          <option value="0" <?php echo ($post_status == 0)?'selected':''; ?>>In-Active</option>
                        </select>
                      </span>
                    </div>
					<div class="form-group dg_single_form">
                      <label>Show Comments :</label>
                      <span>
                        <select class="form-control" name="post_show_comment">
                          <option value="1" <?php echo ($show_comment == 1)?'selected':''; ?>>Yes</option>
                          <option value="0" <?php echo ($show_comment == 0)?'selected':''; ?>>No</option>
                        </select>
                      </span>
                    </div>
                    <div class="clearfix">
                    </div>
                    <?php /*<div class="dg_heading spacer20">
                      <h5>
                        Comments (02)
                      </h5>
                    </div>
                    <div class="dg_comments_section">
                      <div class="dg_commenter_img">
                        <img src="images/avtar.jpg" alt=""/>
                      </div>
                      <div class="dg_comment_preview">
                        <div class="dg_top_comment dg_comment_bg">
                          <h3>
                            ILUIANN
                          </h3>
                          <span class="dg_time">
                            .About 2 years ago
                          </span>
                          <div class="clearfix">
                          </div>
                          <h5>
                            Very Clean design,good luck with sales!
                          </h5>
                        </div>
                        <div class="dg_bottom_comnt_sec">
                          <div class="dg_top_comment">
                            <div class="dg_auth_img">
                              <img src="images/author_logo.png" alt=""/>
                            </div>
                            <div class="dg_auth_text">
                              <h3>
                                ILUIANN
                              </h3>
                              <span class="dg_time">
                                .About 2 years ago
                              </span>
                              <div class="clearfix">
                              </div>
                              <h5>
                                Very Clean design,good luck with sales!
                              </h5>
                              <a class="pull-right dg_blue" href="#">
                                <i>
                                  Reply>
                                  >
                                </i>
                              </a>
                            </div>
                          </div>
                          <div class="dg_btm_bordered">
                          </div>
                          <div class="dg_top_comment">
                            <div class="dg_auth_img">
                              <img src="images/author_logo.png" alt=""/>
                            </div>
                            <div class="dg_auth_text">
                              <h3>
                                ILUIANN
                              </h3>
                              <span class="dg_time">
                                .About 2 years ago
                              </span>
                              <div class="clearfix">
                              </div>
                              <h5>
                                Very Clean design,good luck with sales!
                              </h5>
                              <a class="pull-right dg_blue" href="#">
                                <i>
                                  Reply>
                                  >
                                </i>
                              </a>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="dg_comments_section">
                      <div class="dg_commenter_img">
                        <img src="images/avtar.jpg" alt=""/>
                      </div>
                      <div class="dg_comment_preview">
                        <div class="dg_top_comment dg_comment_bg">
                          <h3>
                            ILUIANN
                          </h3>
                          <span class="dg_time">
                            .About 2 years ago
                          </span>
                          <div class="clearfix">
                          </div>
                          <h5>
                            Very Clean design,good luck with sales!
                          </h5>
                        </div>
                        <div class="dg_bottom_comnt_sec">
                          <div class="dg_top_comment">
                            <div class="dg_auth_img">
                              <img src="images/author_logo.png" alt=""/>
                            </div>
                            <div class="dg_auth_text">
                              <h3>
                                ILUIANN
                              </h3>
                              <span class="dg_time">
                                .About 2 years ago
                              </span>
                              <div class="clearfix">
                              </div>
                              <h5>
                                Very Clean design,good luck with sales!
                              </h5>
                              <a class="pull-right dg_blue" href="#">
                                <i>
                                  Reply>
                                  >
                                </i>
                              </a>
                            </div>
                          </div>
                          
                        </div>
                      </div>
                    </div>*/?>
                    <div class="form-group">
                      <div class="pull-right upper_spacer30">
                        <button class="btn btn-primary">Save</button>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
              
            </div>
          </div>
          <!-- row end -->
        </section>
      </section>
      
    </section>