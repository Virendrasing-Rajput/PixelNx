		<div class="dg_page_heading">
			<h4><i class="flaticon-folder232"></i>Blog Category</h4>
		</div>
		<section class="dg-wrapper">
			<div class="dg_bottom_content_section">
				<div class="row">
					<div class="col-md-12">
						<div class="dg_heading">
							<h5>Category Detail</h5>
							<span class="pull-right">
								<a data-toggle="modal"  class="clear_modal" data-target="#cateModal">
									<span class="btn_black dg_btn">Add Category</span>
								</a>
							</span>
						</div>
						<div class="dg_main_form spacer20">
							<table class="display dg_whole_table">
								<thead>
									<tr>
										<th>S. No.</th>
										<th>Category Name </th>
										<th>Status</th>
										<th>Action </th>
									</tr>
								</thead>
								<tbody>
									<?php
									if(isset($category_detail) && !empty($category_detail)){
										$cnt = 1;
										foreach($category_detail as $category){
											?>
											<tr data-target="<?php echo $category['category_id']; ?>">
												<td><?php echo $cnt++; ?></td>
												<td><?php echo $category['category_title']; ?></td>
												<td><?php echo ($category['category_status'] == 1)?'Active':'In-Active'; ?></td>
												<td>
												  <ul class="dg_action">
													<li class="dg_edit">
													  <a onclick="edit_item(this , 'cateModal')" title="Edit">
														<i class="fa fa-pencil">
														</i>
													  </a>
													</li>
												  </ul>
												</td>
											</tr>
											<?php
										}
									}
									?>
								</tbody>
						  </table>
						</div>
					</div>
				</div>
			</div>
		  <!-- row end -->
		</section>
	</section>
</section>
	<!-- Button trigger modal -->


	<!-- Modal -->
	<div class="modal fade" id="cateModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title" id="myModalLabel">Add Category</h4>
				</div>
				<form method="post" onsubmit="return check_form(this)" action="<?php echo base_url('admin_action/update_blog_category'); ?>">
					<input type="hidden" name="cate_id" id="target_id">
					<div class="modal-body">
						<div class="form-group dg_single_form ">
							<label>Category Title</label>
							<span><input type="text" name="cate_title" id="target_title" placeholder="Category Title" class="form-control require"></span>
						</div>
						<div class="form-group dg_single_form ">
							<label>Browser Status</label>
							<span>
								<select class="form-control" name="Cate_status">
									<option value="1">Active</option>
									<option value="0">In-Active</option>
								</select>
							</span>
						</div>  
					</div> 
					<div class="modal-footer">
						<button type="submit" class="btn btn-primary">Save</button>
					</div>
				</form>
			</div>
		</div>
	</div>