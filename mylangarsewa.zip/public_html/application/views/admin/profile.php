		<div class="dg_page_heading">
            <h4 class="dg_small"><i class="flaticon-man432"></i>Profile</h4>
        </div>
        <section class="dg-wrapper">
            <div class="dg_bottom_content_section">
				<div class="col-lg-6 col-md-6 cool-sm-12 col-xs-12 col-lg-offset-3 col-md-offset-3">
					<div class="ls_member_profile">
						<div class="ls_member_imgdiv">
							<img src="<?php echo base_url('assets/img/profile/'.$this->session->userdata('profile')); ?>" class="img-responsive" alt="profile pic">
							<span><a title="Change Profile" data-toggle="modal" data-target="#change_profile"><i class="fa fa-camera"></i></a></span>
						</div>
						<h3><?php echo $this->session->userdata('name'); ?></h3>
						<p><?php echo $this->session->userdata('email'); ?></p>
						<?php /*<a data-toggle="modal" data-target="#change_password"> change password </a> */ ?>
					</div>
				</div> 
            </div>
        </section>
    </section>
</section>


	<?php /*<div class="modal fade" id="change_password" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title" id="myModalLabel">Change Password</h4>
				</div>
				<div class="modal-body" id="modal_bodey">
					<div class="form-group dg_single_form ">
						<label>Current Password</label>
						<span><input type="password" id="c_pass" placeholder="Enter Current Password" class="form-control require"></span>
					</div>
					<div class="form-group dg_single_form ">
						<label>New Password</label>
						<span><input type="password" id="n_pass" placeholder="Enter New Password" class="form-control require"></span>
					</div>  
					<div class="form-group dg_single_form ">
						<label>Repeat Password</label>
						<span><input type="password" id="r_n_pass" placeholder="Repeat Current Password" class="form-control require"></span>
					</div>  
				</div>
				<div class="modal-footer">
					<button type="button" onclick="change_pass(this , 'modal_bodey')" class="btn btn-primary">Save</button>
				</div>
			</div>
		</div>
	</div> */ ?>

	<div class="modal fade" id="change_profile" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title" id="myModalLabel">Change Profile Image</h4>
				</div>
				<form method="post" action="<?php echo base_url('admin_action/update_profile'); ?>" enctype="multipart/form-data">	
					<div class="modal-body">
						<div class="dg_floatable ls_uploadimg">
							<input id="uploadFile" placeholder="Choose File" disabled="disabled" class="form-control">
							<div class="file-upload btn btn-primary">
								<span>Upload</span>
								<input type="file" class="upload image" name="profile_img">
							</div>
							<span class="dg_btm_text">JPG or PNG 150x150px</span>
						</div>
					</div> 
					<div class="modal-footer">
						<button type="submit" class="btn btn-primary">Save</button>
					</div>
				</form>	
			</div>
		</div>
	</div>