<!DOCTYPE html>
<!--[if IE 9]>
<html lang="en" class="ie9 no-js">
<![endif]-->
<!--[if !IE]>
<!-->
<html lang="en">
  <!--
<![endif]--> 
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="ROBOTS" content="NOINDEX, NOFOLLOW">
		<title><?php echo $this->site_detail->site_title; ?></title>  
		<!-- Core Css -->
		<link href='http://fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,600,700,800,900' rel='stylesheet' type='text/css'>
		<link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900,100italic,300italic,400italic,700italic,900italic' rel='stylesheet' type='text/css'>
		<!-- main css section start-->
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/'); ?>css/admin_main.css"/>
		<!--main css section end-->
		<!-- favicon links -->
		<link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url($this->site_detail->site_favicon); ?>" />
	</head>
	<body class="dg_login_section">
		<div class="dg_login_panel">
			<div class="dg_top_login">
				<img src="<?php echo base_url('assets/'); ?>images/admin.png" alt=""/>
			</div>
			<a><img src="<?php echo base_url($this->site_detail->site_logo); ?>"></a>
			<div class="dg_login_field">
				<label for="user_login">
					<img src="<?php echo base_url('assets/'); ?>images/user.png" alt=""/>
				</label>
				<input type="text" name="log" id="user_login" class="input" placeholder="Username">
			</div>
			<div class="dg_login_field">
				<label for="user_pass">
					<img src="<?php echo base_url('assets/'); ?>images/password.png" alt=""/>
				</label>
				<input type="password" name="pwd" id="user_pass" class="input" placeholder="Password">
			</div>
			<div class="dg_login_btn_field">
				<button class="dg_login_btn pull-right" onclick="validateForm(this)">Login</button>
				<a href="<?php echo base_url(); ?>" class="dg_login_btn">Go To Site</a>
			</div>
			<div class="clearfix"></div>
			<div class="dg_botom_shadow">
				<img src="<?php echo base_url('assets/'); ?>images/shadow.png" alt=""/>
			</div>
		</div>
		<div class="dg_copy_right"><?php echo $this->site_detail->site_copyright; ?>
		</div>
		<script src="<?php echo base_url('assets/'); ?>js/jquery-1.12.3.min.js"></script>
		<script src="<?php echo base_url('assets/'); ?>js/bootstrap.js"></script>
		<script src="<?php echo base_url('assets/'); ?>js/valid.js"></script>
		<script>
			function validateForm(element){
				var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
				var email = $('#user_login').val().trim();
				var password = $('#user_pass').val().trim();
				if(email != '' && password != ''){
					if(re.test(email)){
						$(element).html('login <i class="fa fa-spinner fa-pulse fa-fw"></i>');
						$.ajax({
							method:'post',
							url:'<?php echo base_url('front_ajax/admin_login') ?>',
							data:{'email' : email , 'password' : password}
						}).done(function(resp){
							//console.log(resp);
							if(resp == true){
								location.href= '<?php echo base_url('admin') ?>';
							}else{
								$(element).html('login');
								message("Please check your detail",'error');
							}
						});
					}else{
						message("Email should be correct",'error');
					}
				}else{
					message("Fields cann't be emapty",'error');
				}
			}
		</script>
	</body>
</html>