          <div class="dg_page_heading">
            <h4><i class="flaticon-colors3"></i>Langar Sewa</h4>
          </div>
          <section class="dg-wrapper">
            <div class="dg_bottom_content_section">
              <div class="row">
                <div class="col-md-12">
                  <div class="dg_heading">
                    <h5>Langar Sewa Detail</h5>
					<span class="pull-right">
						<a data-toggle="modal" class="clear_modal" data-target="#add_image">
							<span class="btn_black dg_btn">Add Gallery Image</span>
						</a>
					</span>
                  </div>
					<?php /*<div class="row">
						<div class="col-md-12">
							<form method="post" action="<?php echo base_url('admin_action/up_langar_sewa_message'); ?>">
							  <div class="dg_white_backup spacer40">
								<div class="col-md-12">
									<div class="form-group">
										<input type="text"  style="width:100%"  class="form-control" name="l_title" value="<?php echo $langar_message['0']['l_title']; ?>">
									</div>
									<div class="form-group">
										<textarea style="width:100%" class="form-control" rows="6" name="l_description" placeholder="What is langar sewa ?"><?php echo $langar_message['0']['l_description']; ?></textarea>
									</div>
								</div>
								<div class="col-md-12">
								  <button type="submit" class="btn btn-primary pull-right upper_spacer5">Submit</button>
								</div>
							  </div>
						  
							</form>	
						</div>
					</div> */ ?>
					<div class="row">
						<?php
						if(isset($gallery_image) && !empty($gallery_image)){
							foreach($gallery_image as $image){
								echo '
								<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
									<div class="ls_receipt_img">
										<img src="'.base_url('assets/img/gallery/'.$image['g_image']).'" class="img-responsive"> 
										<div class="ls_removeimg">
											<a title="Remove Image" href="'.base_url('admin_action/remove_gallery_image/'.$image['g_id']).'"><i class="fa fa-times"></i></a>
										</div>
									</div>
									
								</div>';
							}
						}
						?>
					</div>
				  
				 
                </div>
              </div>
              <!-- row end -->
            </div>
          </section>
      </section>
	</section>
	
	
	
	<div class="modal fade" id="add_image" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog" role="document">
			<div class="modal-content"> 
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
					<h4 class="modal-title" id="myModalLabel">Add Image</h4>
				</div>
				<form method="post" onsubmit="return check_form(this)" action="<?php echo base_url('admin_action/add_gallery_image'); ?>" enctype="multipart/form-data">
					<div class="modal-body">
							<div class="dg_floatable ls_uploadimg">
								<input id="uploadFile" placeholder="Choose File" disabled="disabled" class="form-control">
								<div class="file-upload btn btn-primary">
									<span>Upload</span>
									<input id="uploadBtn1" type="file" class="upload image" name="add_image"> 
								</div>
								<span class="dg_btm_text">jpg or png 1050x600px</span>
							</div>
					</div>
					<div class="modal-footer">
						<button type="submit" class="btn btn-primary">Save</button>
					</div>
				</form> 
			</div>
		</div>
	</div>