		<div class="dg_page_heading">
			<h4><i class="flaticon-list95"></i>Item Manager</h4>
        </div>
        <section class="dg-wrapper">
			<div class="dg_bottom_content_section">
				<div class="row">
					<div class="col-md-12">
						<div class="dg_heading">
							<h5>Item Detail</h5>
							<span class="pull-right">
								<a data-toggle="modal" class="clear_modal" data-target="#item_modal">
									<span class="btn_black dg_btn">Add Item</span>
								</a>
							</span>
						</div>
						<div class="dg_main_form spacer20">
							<table class="display dg_whole_table">
								<thead>
									<tr>
										<th>S. No.</th>
										<th>Item Name </th>
										<th>Status</th>
										<th>Action </th>
									</tr>
								</thead>
								<tbody>
									<?php 
									if(isset($item_detail) && !empty($item_detail)){
										$cnt = 1;
										foreach($item_detail as $item){
											?>
											<tr data-target="<?php echo $item['item_id']; ?>">
												<td><?php echo $cnt++; ?></td>
												<td><?php echo $item['item_name']; ?></td>
												<td><?php echo ($item['item_status'] == 1)?'Active':'In-Active'; ?></td>
												<td>
													<ul class="dg_action">
														<li class="dg_edit">
														  <a onclick="edit_item(this , 'item_modal')" title="Edit"><i class="fa fa-pencil"></i></a>
														</li>
													</ul>
												</td>
											</tr>
											<?php
										}
									} 
									?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
          <!-- row end -->
        </section>
    </section>  
</section>  
	<!-- Button trigger modal -->
	<!-- Modal -->
	<div class="modal fade" id="item_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title" id="myModalLabel">Add Item</h4>
				</div>
				<form method="post" onsubmit="return check_form(this)" action="<?php echo base_url('admin_action/update_item'); ?>">
					<input type="hidden" name="item_id" id="target_id">
					<div class="modal-body">
						<div class="form-group dg_single_form ">
							<label>Item Name</label>
							<span><input type="text" name="item_name" id="target_title" placeholder="Item Name" class="form-control require"></span>
						</div>
						<div class="form-group dg_single_form ">
							<label>Item Status</label>
							<span>
								<select class="form-control" name="item_status">
									<option value="1">Active</option>
									<option value="0">In-Active</option>
								</select>
							</span>
						</div>  
					</div> 
					<div class="modal-footer">
						<button type="submit" class="btn btn-primary">Save</button>
					</div>
				</form>
			</div>
		</div>
	</div>