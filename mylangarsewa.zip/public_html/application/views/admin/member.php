          <div class="dg_page_heading">
            <h4><i class="flaticon-man432"></i>Member</h4>
          </div>
          <section class="dg-wrapper">
            <div class="dg_bottom_content_section">
              <div class="row">
                <div class="col-md-12">
                  <div class="dg_heading">
                    <h5>Member's Lists</h5>
                  </div>
				  <?php 
					$user_detail = $this->langar_model->select_data('*' , 'users' , array('email_verification' => 1) , 5 , array('user_id' , 'DESC'));
					if(!empty($user_detail)){
						?>
						<table class="display dg_whole_table">
							<thead>
							  <tr>
								<th>S. No.</th>
								<th>Name</th>
								<th>Email</th>
								<th>Registration Date</th>
								<th>Total Sewa Complete</th>
								<th>Total Sewa In-Complete</th>
								<th>Action</th>
							  </tr>
							</thead>
							<tbody>
								<?php 
								$cnt = 1;
								foreach($user_detail as $user){
									$count_complete_sewa = 	$this->langar_model->aggregate_data('order' , 'order_id' , 'COUNT' , array('user_id' => $user['user_id'] ,'order_status' => 1));
									
									$count_incomplete_sewa = 	$this->langar_model->aggregate_data('order' , 'order_id' , 'COUNT' , array('user_id' => $user['user_id'] ,'order_status' => 0));
									echo '
									<tr> 
										<td>'.$cnt++.'</td>
										<td>'.$user['user_name'].'</td>
										<td>'.$user['user_email'].'</td>
										<td>'.date('d M, Y' , strtotime($user['registration_date'])).'</td>
										<td>'.$count_complete_sewa.'</td>
										<td>'.$count_incomplete_sewa.'</td>
										<td>
										  <ul class="dg_action">
											<li class="dg_view">
											  <a href="'.base_url('admin/sewa?member='.$user['user_id']).'" title="Preview"><i class="fa fa-eye"></i></a>
											</li>
										  </ul>
										</td>
									  </tr>';
								}	
								?>	
							</tbody>
						</table>
						<?php
					}else{
						?>
						<div class="alert alert-warning dg_queue_update empty" role="alert">
							<span class="dg_alerts_setting">
							  <i class="flaticon-warning30">
							  </i>
							  Info
							</span>
							<span class="dg_alert_text">
							  No records found...
							</span>
						</div>	
						<?php
					}
					?>	
                </div>
              </div>
              <!-- row end -->
            </div>
          </section>
      </section>
	</section>