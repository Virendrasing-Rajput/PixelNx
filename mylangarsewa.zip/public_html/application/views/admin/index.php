		<div class="dg_page_heading">
			<h4 class="dg_small"><i class="flaticon-transport10"></i>Dashboard</h4>
		</div>
		<section class="dg-wrapper">
			<div class="dg_bottom_content_section">
				<div class="row">
					<div class="col-md-12 spacer40">
						<div class="dg_heading">
							<h5>Recent Member's </h5>
							<span class="pull-right">
							  <a href="<?php echo base_url('admin/member'); ?>"><span class="btn_black dg_btn"> View All Members</span></a>
							</span>
						</div>
						<?php 
						if(isset($resent_users) && !empty($resent_users)){
							?>
							<table class="display dg_main_table">
								<thead>
									<tr>
										<th>S. No.</th>
										<th>Name</th>
										<th>Email</th>
										<th>Date Created</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
									<?php 
									$cnt = 1;
									foreach($resent_users as $users){
										echo '
										<tr>
											<td>'.$cnt++.'</td>
											<td>'.$users['user_name'].'</td>
											<td>'.$users['user_email'].'</td>
											<td>'.date('d M Y' , strtotime($users['registration_date'])).'</td>
											<td>
												<ul class="dg_action">
													<li class="dg_view">
													  <a href="'.base_url('admin/sewa?member='.$users['user_id']).'" target="_blank" title="View Sewa Detail"><i class="fa fa-eye"></i></a>
													</li>
												</ul>
											</td>
										</tr>';
									}
									
									/*<ul class="dg_action">
													<li class="dg_view">
													  <a title="preview"><i class="fa fa-eye"></i></a>
													</li>
													<li class="dg_edit">
													  <a title="edit"><i class="fa fa-pencil"></i></a>
													</li>
													<li class="dg_del">
													  <a title="delete"><i class="fa fa-times"></i></a>
													</li>
												</ul>*/
									?>
								</tbody>
							</table>
							<?php
						}else{
							?>
							<div class="alert alert-warning dg_queue_update empty" role="alert">
								<span class="dg_alerts_setting">
								  <i class="flaticon-warning30">
								  </i>
								  Info
								</span>
								<span class="dg_alert_text">
								  No records found...
								</span>
							</div>	
							<?php
						}
						?>
					</div>
				</div>
				<!-- row end -->
				<div class="row">
					<div class="col-md-12">
						<div class="dg_heading">
							<h5>Recent Sewa Proccess</h5>
							<span class="pull-right">
							  <a href="<?php echo base_url('admin/sewa'); ?>"><span class="btn_black dg_btn"> View All</span></a>
							</span>
						</div>
						<?php 
						if(isset($sewa_detail) && !empty($sewa_detail)){
							?>
							<table class="display dg_main_table">
								<thead>
									<tr>
										<th>S. No.</th>
										<th>Request ID</th>
										<th>Sewa Name</th>
										<th>Sewa Date</th>
										<th>Sewa Amount</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
									<?php 
									$cnt = 1 ;
									foreach($sewa_detail as $sewa){
										$currency = $sewa['pay_currency'];
										$c_symbol = ($currency == 'USD')?'&#x24;':(($currency == 'GBP')?'&#xa3;':(($currency == 'EURO')?'&euro;':(($currency == 'INR')?'&#8360;':'')));
										echo ' 
										<tr>
											<td>'.$cnt++.'</td>
											<td>'.$sewa['order_uniq'].'</td>
											<td>'.$sewa['user_name'].'</td>
											<td>'.date('d M, Y', strtotime($sewa['request_date'])).'</td>
											<td>'.$c_symbol.$sewa['pay_amount'].'</td>
											<td>
												<ul class="dg_action">
													<li class="dg_view">
													  <a target="_blank" title="View Detail" href="'.base_url('admin/sewa/'.$sewa['order_uniq']).'"><i class="fa fa-eye"></i></a>
													</li>
												</ul>
											</td>
										</tr>';
									}
									
									/*<ul class="dg_action">
													<li class="dg_view">
													  <a title="preview"><i class="fa fa-eye"></i></a>
													</li>
													<li class="dg_edit">
													  <a title="edit"><i class="fa fa-pencil"></i></a>
													</li>
													<li class="dg_del">
													  <a title="delete"><i class="fa fa-times"></i></a>
													</li>
												</ul>*/
									?>
								</tbody>
							</table>
							<?php
						}else{
							?>
							<div class="alert alert-warning dg_queue_update empty" role="alert">
								<span class="dg_alerts_setting">
								  <i class="flaticon-warning30">
								  </i>
								  Info
								</span>
								<span class="dg_alert_text">
								  No records found...
								</span>
							</div>	
							<?php
						}
						?>
					</div>
				</div>
				<!-- row end -->
			  <!-- row end -->
			</div>
		</section>
	</section>
</section>