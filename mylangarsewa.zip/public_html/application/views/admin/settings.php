<div class="dg_page_heading">
	<h4><i class="flaticon-colors3"></i>Settings</h4>
</div>
		<section class="dg-wrapper">
			<div class="dg_bottom_content_section">
				<div class="row">
					<div class="col-md-12">
						<div class="dg_heading">
						  <h5>Site Settings</h5>
						</div>
						<div class="dg_main_form spacer20">
							<form method="post" action="<?php echo base_url('admin_action/update_setting'); ?>" onsubmit="return check_form(this)">
								<div class="form-group dg_single_form">
									<label for="broser_name">Site Name :</label>
								<span>
									<input type="text" name="name" placeholder="Name" class="form-control require" value="<?php echo $this->site_detail->site_name; ?>">
								</span>
							  
							</div>
							<div class="form-group dg_single_form">
								<label>Site Title :</label>
								<span>
									<input type="text" name="title" class="form-control require" placeholder="Title" value="<?php echo $this->site_detail->site_title; ?>">
								</span>
							</div>
							<div class="form-group dg_single_form">
								<label>Site Email :</label>
								<span>
									<input type="text" name="email" class="form-control require" data-valid="email" data-error="Email should be valid." placeholder="Email" value="<?php echo $this->site_detail->site_email; ?>">
								</span>
							</div>
							<div class="form-group dg_single_form">
								<label>Site Contact :</label>
								<span>
									<input type="text" name="contact" class="form-control require" placeholder="Contact" value="<?php echo $this->site_detail->site_mobile; ?>">
								</span>
							</div>
							<div class="form-group dg_single_form">
								<label>Site Keywords :</label>
								<span>
									<textarea class="form-control require" name="keyword" placeholder="Keywords" rows="3"><?php echo $this->site_detail->site_keywords; ?></textarea>
								</span>
							</div>
							<div class="form-group dg_single_form">
								<label>Site Description :</label>
								<span>
									<textarea class="form-control require" name="description" placeholder="Description" rows="4"><?php echo $this->site_detail->site_description; ?></textarea>
								</span>
							</div>
							<div class="form-group dg_single_form">
								<label>Site Copyright :</label>
								<span>
									<textarea class="form-control require" name="copyright" placeholder="Copyright" rows="3"><?php echo $this->site_detail->site_copyright; ?></textarea>
								</span>
							</div>
							<?php /*<div class="row">
								<div class="col-md-8">
									<div class="form-group dg_single_form dg_temp_set">
										<label>Upload Logo</label>
										<div class="dg_checked_section">
											<p><input id="uploadFile2" placeholder="Choose File" disabled="disabled" class="form-control"></p>
											<div class="file-upload btn btn-primary">
												<span>Upload</span>
												<input id="uploadBtn2" type="file" class="upload">
											</div>
											<span class="dg_btm_text">JPG or PNG 1920x1080px</span>
										</div>
									</div>
									<div class="form-group dg_single_form dg_temp_set">
										<label>Upload Favicon</label>
										<div class="dg_checked_section">
											<p><input id="uploadFile1" placeholder="Choose File" disabled="disabled" class="form-control"></p>
											<div class="file-upload btn btn-primary">
												<span>Upload</span>
												<input id="uploadBtn" type="file" class="upload">
											</div>
											<span class="dg_btm_text">JPG or PNG 1920x1080px</span>
										</div>
									
									</div>
								</div>
								<div class="col-md-4">
									<div class="form-group dg_single_form dg_temp_set">
										<label>Current Logo</label>
										<span><img src="images/logo.png" alt=""></span>
									</div>
									<div class="form-group dg_single_form dg_temp_set">
										<label>Current Favicon</label>
										<span><img src="images/author_logo.png" alt=""></span>
									</div>
								</div>
							</div> */?>
							<div class="clearfix">
							</div>
							<div class="form-group">
								<div class="pull-right upper_spacer30">
									<button class="btn btn-primary" type="submit" name="save">Save</button>
								</div>
							</div>
						  </form>
						</div>
					</div>
				</div>
			</div>
          <!-- row end -->
        </section>
    </section>
</section>