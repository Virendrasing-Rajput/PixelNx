        <div class="dg_page_heading">
            <h4><i class="flaticon-blogger8"></i>Blog Post</h4>
        </div>
        <section class="dg-wrapper">
            <div class="dg_bottom_content_section">
				<div class="row">
					<div class="col-md-12"> 
						<div class="dg_heading">
							<h5>Blog Post List</h5>
							<span class="pull-right">
								<a href="<?php echo base_url('admin/blog_post/add'); ?>"><span class="btn_black dg_btn">Add Blog</span></a>
							</span>
						</div>
						<?php 
						if(isset($blog_detail) && !empty($blog_detail)){
							?>
							<table class="display dg_whole_table">
								<thead>
									<tr>
										<th>S. No.</th>
										<th>Post Title</th>
										<!--<th>Categories</th> -->
										<th>Date</th>
										<th>Status</th>
										<th>Images</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
									<?php 
									$cnt = 1;
									foreach($blog_detail as $blog){
										$clog_title = (strlen($blog['post_title'])>30)?substr($blog['post_title'],0,30).'...':$blog['post_title'];
										$status = ($blog['post_status'] == 1)?'Active':'In-Active';
										echo '
										<tr>
											<td>'.$cnt++.'</td>
											<td>'.$clog_title.'</td>
											
											<td>'.date('d M, Y', strtotime($blog['post_date'])).'</td>
											<td>'.$status.'</td>
											<td class="dg_blue text-center">
												<img src="'.base_url('assets/img/post/'.$blog['post_image']).'" width="175" height="93"  alt="'.$blog['post_title'].'">
											</td>
											<td>
												<ul class="dg_action">
													<li class="dg_view">
													  <a target="_blank" href="'.base_url('blog/'.$blog['post_slug']).'" title="Preview">
														<i class="fa fa-eye">
														</i>
													  </a>
													</li>
													<li class="dg_edit">
													  <a title="Edit" href="'.base_url('admin/blog_post/edit/'.$blog['post_id']).'">
														<i class="fa fa-pencil">
														</i>
													  </a>
													</li>
												</ul>
											</td>
										</tr>'; 
									}
//<td>'.$blog['category_title'].'</td>									
									?>
									<!--
										<li class="dg_del">
										  <a title="delete">
											<i class="fa fa-times">
											</i>
										  </a>
										</li>--->
								</tbody>
							</table>
							<?php
						}else{
							?>
							<div class="alert alert-warning dg_queue_update empty" role="alert">
								<span class="dg_alerts_setting">
								  <i class="flaticon-warning30">
								  </i>
								  Info
								</span>
								<span class="dg_alert_text">
								  No records found...
								</span>
							</div>	
							<?php
						}	
						?>
					</div>
				</div>
              <!-- row end -->
            </div>
        </section>
    </section>
</section>