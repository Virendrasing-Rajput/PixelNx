		<div class="dg_page_heading">
            <h4 class="dg_small"><i class="flaticon-transport10"></i>Dashboard</h4>
        </div>
        <section class="dg-wrapper">
            <div class="dg_bottom_content_section">
				<div class="row">
					<div class="col-md-6">
						<div class="dg_review text-center">
							<p>Total In-Complete Sewa</p>
							<h2><?php echo (isset($in_comlplete_sewa))?$in_comlplete_sewa:0; ?></h2>
							<a href="<?php echo base_url('member/sewa?status=0'); ?>" class="dg_blue">View All &gt;&gt;</a>
						</div>
					</div>
					<div class="col-md-6">
						<div class="dg_review text-center">
							<p>Total Complete Sewa</p>
							<h2><?php echo (isset($comlplete_sewa))?$comlplete_sewa:0; ?></h2>
							<a href="<?php echo base_url('member/sewa?status=1'); ?>" class="dg_blue">View All &gt;&gt;</a>
						</div>
					</div>
				</div>
				<!-- row end -->
				<div class="row">
					<div class="col-md-12 spacer40">
						<div class="dg_heading">
							<h5>Recent Sewa's Detail</h5>
							<span class="pull-right">
								<a href="<?php echo base_url('member/sewa'); ?>">
									<span class="btn_black dg_btn">View All</span>
								</a>
							</span>
						</div>
						<?php
						if(isset($recent_sewa_detail) && !empty($recent_sewa_detail)){
							?>
							<table class="display dg_main_table">
								<thead>
									<tr>
										<th>S. No.</th>
										<th>Request ID</th>
										<th>Request Date</th>
										<th>Sewa Amount</th>
										<th>Sewa Status</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody> 
									<?php
									$cnt = 1;
									foreach($recent_sewa_detail as $sewa){
										$status= ($sewa['order_status'] == 1)?'Complet':'In-Complete';
										$currency = $sewa['pay_currency'];
										
										$c_symbol = ($currency == 'USD')?'$':(($currency == 'GBP')?'&#163;':(($currency == 'EURO')?'&#8364;':(($currency == 'INR')?'<i class="fa fa-inr"></i>':''))); 
										echo '
										<tr>
											<td>'.$cnt.'</td>
											<td>'.$sewa['order_uniq'].'</td>
											<td>'.date('d M, Y' , strtotime($sewa['request_date'])).'</td>
											<td>'.$c_symbol.$sewa['pay_amount'].'</td>
											<td>'.$status.'</td>
											<td>
												<ul class="dg_action">
													<li class="dg_view">
														<a href="'.base_url('member/sewa/'.$sewa['order_uniq']).'" title="View Detail">
															<i class="fa fa-eye"></i>
														</a>
													</li>
												</ul>
											</td>
										</tr>
										';
									}
									
									/*
													<li class="dg_edit">
														<a href="#" title="edit">
															<i class="fa fa-pencil"></i>
														</a>
													</li>*/
									?>
								</tbody>
							</table>
							<?php
						}else{
							?>
							<div class="alert alert-warning dg_queue_update" role="alert">
								<span class="dg_alerts_setting">
								  <i class="flaticon-warning30"></i>Info</span>
								<span class="dg_alert_text">No records found...</span>
							</div>
							<?php
						}
						?>
					</div>
				</div>
				<!-- row end -->
            </div>
        </section>
    </section>
</section>



	