<!DOCTYPE html>
<!--[if IE 9]>
<html lang="en" class="ie9 no-js">
<![endif]-->
<!--[if !IE]>
<!-->
<html lang="en">
  <!--
<![endif]-->
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="">
		<meta name="author" content=""> 
		<title><?php echo $this->site_detail->site_title; ?></title>
		<!-- Core Css -->
		<link href='http://fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,600,700,800,900' rel='stylesheet' type='text/css'>
		<link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900,100italic,300italic,400italic,700italic,900italic' rel='stylesheet' type='text/css'>
		<!-- main css section start-->
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/'); ?>css/admin_main.css"/>
		<?php echo (isset($sewa) && $sewa == true)?'<link rel="stylesheet" type="text/css" href="'.base_url('assets/').'css/magnific-popup.css"/>':''; ?>
		<!--main css section end-->
		<!-- favicon links -->
		<link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url($this->site_detail->site_favicon); ?>" />
	</head>
	<body>
		<section id="container">
			<!--header start-->
			<header class="header fixed-top clearfix">
				<!-- top admin bar -->
				<div class="dg_brand">
					<div class="dg_author">
						<img src="<?php echo base_url('assets/img/profile/').$this->session->userdata('profile'); ?>" alt="<?php echo $this->session->userdata('name'); ?>"/>
					</div>
					<div class="dg_author_name">
						<h5>Welcome to <?php echo $this->session->userdata('name'); ?></h5>
					</div>
					<div class="sidebar-toggle-box">
						<div class="fa fa-bars">
							<!--<i class="flaticon-menu51"></i> -->
						</div>
					</div>
				</div>
				<div class="nav dg_notify_row" id="dg_top_menu">
					<a href="<?php echo base_url(); ?>" target="_blank"><img src="<?php echo base_url($this->site_detail->site_logo); ?>"></a>
				</div>
				<!-- top admin bar end -->
				<!-- top right menu start -->
				<div class="dg-top-nav clearfix">
					<ul class="nav pull-right dg_top_menu_second">
						<li>
							<a href="<?php echo base_url(); ?>" target="_blank">
								<i class="flaticon-flatscreen"></i>
								<span>Visit Site</span>
							</a>
						</li>
						<li>
						  <a href="<?php echo base_url('home/logout'); ?>"><i class="flaticon-power107"></i><span>Logout</span></a>
						</li>
					</ul>
				</div> 
			</header> 
			<div class="clearfix"></div>
			<!--header end-->
			<!--sidebar start-->
			<aside>
				<div id="dg-sidebar" class="nav-collapse">
					<div class="dg-leftside-navigation">
						<ul class="dg-sidebar-menu" id="nav-accordion">
							<li>
								<a <?php echo (isset($index) && $index == true)?'class="active"':''; ?> href="<?php echo base_url('member'); ?>">
									<i class="flaticon-transport10"></i>
									<span>Dashboard</span>
								</a>
							</li>
							<li>
								<a <?php echo (isset($profile) && $profile == true)?'class="active"':''; ?> href="<?php echo base_url('member/profile'); ?>">
									<i class="flaticon-man432"></i>
									<span>Profile</span>
								</a>
							</li>
							<li>
								<a <?php echo (isset($sewa) && $sewa == true)?'class="active"':''; ?> href="<?php echo base_url('member/sewa'); ?>">
									<i class="flaticon-award47"></i>
									<span>Sewa</span>
								</a> 
							</li>
						</ul>
					</div>
				</div>
			</aside>
			<!--sidebar end-->
			<!--main content start-->
			<section id="dg-main-content">
			<!-- top right menu end -->
			
			<input type="" id="base_url" value="<?php echo base_url(); ?>">