
  </body>
	
	<!--main js section start -->
	
	<script src="<?php echo base_url('assets/js/jquery-1.12.3.min.js'); ?>"></script>
	<script src="<?php echo base_url('assets/js/bootstrap.js'); ?>"></script>
	<script src="<?php echo base_url('assets/js/plugins/jqueryui/jquery-ui.js'); ?>"></script>
	<script src="<?php echo base_url('assets/js/plugins/data-tables/jquery.dataTables.min.js'); ?>"></script>
	<script src="<?php echo base_url('assets/js/plugins/jquery.nicescroll.js'); ?>"></script>
	<?php echo (isset($sewa) && $sewa == true)?'<script src="'.base_url('assets/').'js/jquery.magnific-popup.min.js"></script>':''; ?>
	<script src="<?php echo base_url('assets/js/valid.js'); ?>"></script>
	<script src="<?php echo base_url('assets/js/member_custom.js'); ?>"></script>
	
	<!--main js section end-->
	
	<?php 
	if($this->session->flashdata('notice') != ''){
		echo '<script>message("'.$this->session->flashdata('notice').'","error");</script>';
	}
	
	if($this->session->flashdata('error') != ''){
		echo '<script>message("'.$this->session->flashdata('error').'","error");</script>';
	}
	
	if($this->session->flashdata('success') != ''){
		echo '<script>message("'.$this->session->flashdata('success').'","success");</script>';
	}
	?>	
</html>