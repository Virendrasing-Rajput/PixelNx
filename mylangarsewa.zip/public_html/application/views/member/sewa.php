		<div class="dg_page_heading">
			<h4><i class="flaticon-award47"></i>Sewa</h4>
		</div>
		<section class="dg-wrapper">
			<?php
			if(!isset($single)){
				?>
				<div class="dg_bottom_content_section">
					<div class="row">
						<div class="col-md-12">
							<div class="dg_white_backup">
								<form method="post">
									<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
										<div class="dg_input_search">
											<input type="text" class="form-control" placeholder="Request ID" name="request_id" value="<?php echo (isset($request_id) && $request_id != '')?$request_id:''; ?>" > 
										</div>
									</div>
									<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
										<div class="dg_input_search">
											<select name="status" class="form-control">
												<option value="">Choose One</option>
												<option <?php echo (isset($status) && $status == 1)?'selected':''; ?> value="1">Complete</option>
												<option <?php echo (isset($status) && $status == 0)?'selected':''; ?> value="0">In-Complete</option>
											</select>
										</div>
									</div>
									<div class="col-lg-1 col-md-2 col-sm-12 col-xs-12 mini_upper_spacer">
										<button class="btn btn-primary" type="submit">Search</button>
									</div>
								</form>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12 spacer40">
						  <div class="dg_heading">
							<h5>Sewa Detail</h5>
						  </div>
							<?php 
							if(isset($order_detail) && !empty($order_detail)){
								?>
								<table class="display dg_main_table">
									<thead>
										<tr>
											<th>No.</th>
											<th>Request ID</th> 
											<th>Donate Date</th> 
											<th>Donate Amount</th>
											<th>Status</th>
											<th>Action</th>
										</tr> 
									</thead>
									<tbody>
										<?php 
										$cnt = 1;
										foreach($order_detail as $order){
											$currency = $order['pay_currency'];
											$c_symbol = ($currency == 'USD')?'$':(($currency == 'GBP')?'£':(($currency == 'EURO')?'€':(($currency == 'INR')?'<i class="fa fa-inr"></i>':'')));
											$status = ($order['order_status'] == 1)?'Complete':'In-Complete';
											echo '
											<tr>
												<td>'.$cnt++.'</td>
												<td>'.$order['order_uniq'].'</td>
												<td>'.date('d M, Y', strtotime($order['request_date'])).'</td>
												<td>'.$c_symbol.$order['pay_amount'].'</td>
												<td>'.$status.'</td>
												<td>
													<ul class="dg_action">
														<li class="dg_view">
														  <a href="'.base_url('member/sewa/'.$order['order_uniq']).'" title="View Detail">
															<i class="fa fa-eye"></i>
														  </a>
														</li>
													</ul>		
												</td>
											</tr>';
										}
										?>
									</tbody>
								</table>
								<?php
							}else{
								?>
								<div class="alert alert-warning dg_queue_update empty" role="alert">
									<span class="dg_alerts_setting">
									  <i class="flaticon-warning30">
									  </i>
									  Info
									</span>
									<span class="dg_alert_text">
									  No records found...
									</span>
								</div>	
								<?php
							}	
							?>
							
						</div>
					</div>
				  <!-- row end -->
				</div>
				<?php
			}elseif(isset($single)){
				?>
					<?php /*<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
						<div class="ls_imguploader">
							<div class="row">
								<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
									<label>Upload Receipt</label>
								</div>
								<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">
									<strong>:-</strong>
								</div>
								<div class="col-lg-7 col-md-7 col-sm-6 col-xs-12">
									<div class="dg_floatable">
										<input id="uploadFile" placeholder="Choose File" disabled="disabled" class="form-control">
										<div class="file-upload btn btn-primary">
											<span>Upload</span>
											<input id="uploadBtn1" type="file" class="upload" name="post_image">
										</div>
										<span class="dg_btm_text">JPG or PNG 845x350px</span>
									</div>
								</div>
							</div>	
						</div>
					</div>*/?>
					<?php
					if(isset($order_detail) && !empty($order_detail)){
						$currency = $order_detail['0']['pay_currency'];
						$c_symbol = ($currency == 'USD')?'$':(($currency == 'GBP')?'£':(($currency == 'EURO')?'€':(($currency == 'INR')?'<i class="fa fa-inr"></i>':'')));
						?>
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
							<div class="dg_heading">
								<h5>Sewa Detail</h5>
							</div>
							<div class="ls_donator_profile">
								<div class="row">
									<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 col-lg-offset-3 col-md-offset-3 col-sm-offset-3">
										<h3 class="ls_heading">Sewa Detail</h3>
									</div>
								</div>
								<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 col-lg-offset-2 col-md-offset-2">
									<div class="ls_profilediv">
										<div class="row">
											<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
												<label>Request ID</label>
											</div>
											<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">
												<span>:-</span>
											</div>
											<div class="col-lg-7 col-md-7 col-sm-6 col-xs-12">
												<p><?php echo $order_detail['0']['order_uniq'] ?></p>
											</div>
										</div>
									</div>
									<div class="ls_profilediv">
										<div class="row">
											<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
												<label>Sewa Status</label>
											</div>
											<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">
												<span>:-</span>
											</div>
											<div class="col-lg-7 col-md-7 col-sm-6 col-xs-12">
												<p><?php echo ($order_detail['0']['order_status'] == 1)?'Complete':'In-Complete'; ?></p>
											</div>
										</div>
									</div>
									<?php echo ($order_detail['0']['order_status'] == 1)?'
									<div class="ls_profilediv">
										<div class="row">
											<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
												<label>Completed Date</label>
											</div>
											<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">
												<span>:-</span>
											</div>
											<div class="col-lg-7 col-md-7 col-sm-6 col-xs-12">
												<p>'.date('d M, Y',strtotime($order_detail['0']['completed_date'])).'</p>
											</div>
										</div>
									</div>':''; ?>
									<div class="ls_profilediv">
										<div class="row">
											<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
												<label>Donator Date</label>
											</div>
											<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">
												<span>:-</span>
											</div>
											<div class="col-lg-7 col-md-7 col-sm-6 col-xs-12">
												<p><?php echo date('d M, Y', strtotime($order_detail['0']['request_date'])); ?></p>
											</div>
										</div>
									</div>
									<div class="ls_profilediv">
										<div class="row">
											<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
												<label>Donator Amount</label>
											</div>
											<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">
												<span>:-</span>
											</div>
											<div class="col-lg-7 col-md-7 col-sm-6 col-xs-12">
												<p><?php echo $c_symbol.$order_detail['0']['pay_amount']; ?></p>
											</div>
										</div>
									</div>
									<div class="ls_profilediv">
										<div class="row">
											<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
												<label>Item List</label>
											</div>
											<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">
												<span>:-</span>
											</div>
											<div class="col-lg-7 col-md-7 col-sm-6 col-xs-12">
												<p>
												<?php  
												if($order_detail['0']['selected_item'] != ''){
													$sel_item = json_decode($order_detail['0']['selected_item'] , true); 
												
													foreach($sel_item as $item){
														$item_d = $this->langar_model->select_data('item_name' , 'item' , array('item_id' => $item));
														if(!empty($item_d)){
															echo $item_d['0']['item_name'].', &nbsp;&nbsp;&nbsp;';
														}
													}
												}else{
													echo 'Not Selected';
												}
												
													 
												?>
												
												</p>
											</div>
										</div>
									</div>
									<?php
									if($order_detail['0']['arrival_temple'] == 1){
										?>
										<div class="ls_profilediv"> 
											<div class="row">
												<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
													<label>Arrival Date</label>
												</div>
												<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">
													<span>:-</span>
												</div>
												<div class="col-lg-7 col-md-7 col-sm-6 col-xs-12">
													<p><?php echo date('d M, Y', strtotime($order_detail['0']['expected_date'])); ?></p>
												</div>
											</div>
										</div>
										<?php
									}
									?>
									<div class="ls_profilediv">
										<div class="row">
											<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
												<label>Uploaded Receipt </label>
											</div>
											<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">
												<span>:-</span>
											</div>
											<div class="col-lg-7 col-md-7 col-sm-6 col-xs-12">
												<div class="row">
													<?php
													$rec_detail = $this->langar_model->select_data('rec_id,rec_name' , 'order_receipt' , array('order_id' => $order_detail['0']['order_id'])); 
													if(!empty($rec_detail)){
														foreach($rec_detail as $rec){
														echo '
															<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
															<div class="ls_receipt_img">
																<a class="receipt_container" href="'.base_url('assets/img/receipt/'.$rec['rec_name']).'">	
																<img src="'.base_url('assets/img/receipt/'.$rec['rec_name']).'" class="img-responsive">
																</a>
																<div class="ls_removeimg">
																	<a title="Download Receipt" href="'.base_url('assets/img/receipt/'.$rec['rec_name']).'" download="Receipt.png"><i class="fa fa-download"></i></a>
																</div>
															</div>
															
														</div>';
														
														}
													
													}
													?>
												</div>
											</div>
										</div>
									</div>
									
									
								</div>
							</div>
						</div>
						<?php
					}
					?>
					
				<?php
			}
			?>
			
		</section>
	</section>
  
</section>