<div class="ls_breadcrumb_wrapper ls_toppadder50 ls_bottompadder50">
	<div class="ls_overlay"></div>
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<h3>Blog</h3>
				<ul>
					<li><a href="<?php echo base_url(); ?>">home</a></li>
					<li>Blog</li>
				</ul>
			</div>
		</div> 
	</div>
</div>
<?php
	global $login,$role;
	$login = $this->session->userdata('login');
	$role = $this->session->userdata('role');
	
	function reply_btn($cmntId){
		global $login,$role;
		echo ($login == 1 && $role == 2)?'<a data-target="'.$cmntId.'" class="comment-reply-link reply_post">Reply</a>':'<a class="comment-reply-link" data-toggle="modal" data-target="#loginpopup">Reply</a>';
	}
	
?>
<div class="ls_innerpages_wrapper ls_toppadder100 ls_bottompadder100">
	<div class="container">
		<div class="row">
			<div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
				<div class="post-timeline">
					<?php 
					if(isset($blog_detail) && !empty($blog_detail)){
						?>
						<div class="entry">
							<div class="entry-image">
								<img src="<?php echo base_url('assets/img/post/'.$blog_detail['0']['post_image']); ?>" class="img-responsive" alt="">
							</div>
							<div class="entry-title">
								<h2><a><?php echo $blog_detail['0']['post_title']; ?></a></h2>
							</div>
							<ul class="entry-meta">
								<li><a>By Admin</a>
								</li>
								<?php /*<li><a><?php echo $blog_detail['0']['category_title']; ?></a>
								</li> */?>
								<li><a>Posted on <?php echo date('d M Y' , strtotime($blog_detail['0']['post_date'])); ?></a>
								</li>
							</ul>
							<div class="entry-content">
								<p><?php echo $blog_detail['0']['post_description']; ?></p>
								<blockquote>
									<p><?php echo $blog_detail['0']['post_description_second']; ?></p>
								</blockquote>
								<p><?php echo $blog_detail['0']['post_description_third']; ?></p>
							</div>
							<?php
							if($blog_detail['0']['show_comment'] == 1){
								$comment_detail = $this->langar_model->select_data('blog_comment.*, users.user_name,users.profile_image','blog_comment' , array('post_id' => $blog_detail['0']['post_id'],'comment_parent' => 0, 'comment_status' => 1) , '' , array('comment_id','ASC') , '' , array('users','users.user_id = blog_comment.cmmented_by'));
								if(!empty($comment_detail)){
								?>
								<div id="comments" class="ls_toppadder50">
									<h4 id="comments-title">Comments</h4>
									<ol class="commentlist">
										<?php
										foreach($comment_detail as $p_comment){
											?>
											<li>
												<div class="comment-wrap">
													<div class="comment-meta">
														<div class="comment-author">
															<span class="comment-avatar">
															<img src="<?php $img = ($p_comment['profile_image'] != '')?$p_comment['profile_image']:'profile.jpg'; echo base_url('assets/img/profile/'.$img);  ?>" class="img-responsive" alt="<?php echo $p_comment['user_name']; ?>" title="<?php echo $p_comment['user_name']; ?>">
														</span>
														</div>
													</div>
													<div class="comment-content">
														<div class="comment-author">
															<a class="url"><?php echo $p_comment['user_name']; ?></a> 
															<span><?php echo date('M d, Y  h:i a' , strtotime($p_comment['comment_date'])); ?></span>
														</div>
														<p><?php echo nl2br($p_comment['comment_data']); ?></p>
														<?php  reply_btn($p_comment['comment_id']); ?>
													</div>
												</div>
												<?php
												$comment_second_detail = $this->langar_model->select_data('blog_comment.*, users.user_name, users.profile_image','blog_comment' , array('comment_parent' => $p_comment['comment_id'], 'comment_status' => 1) , '' , array('comment_id','ASC') , '' , array('users','users.user_id = blog_comment.cmmented_by'));
												if(!empty($comment_second_detail)){
													echo '<ul class="children">';
												foreach($comment_second_detail as $s_cmnt){
													?>
													<li>
														<div class="comment-wrap">
															<div class="comment-meta">
																<div class="comment-author">
																	<span class="comment-avatar">
																	<img src="<?php $img1 = ($s_cmnt['profile_image'] != '')?$s_cmnt['profile_image']:'profile.jpg'; echo base_url('assets/img/profile/'.$img1);  ?>" class="img-responsive" alt="<?php echo $s_cmnt['user_name']; ?>" title="<?php echo $s_cmnt['user_name']; ?>">
																</span>
																</div>
															</div>
															<div class="comment-content">
																<div class="comment-author">
																	<a class="url"><?php echo $s_cmnt['user_name']; ?></a>
																	<span><?php echo date('M d, Y  h:i a' , strtotime($s_cmnt['comment_date'])); ?></span>
																</div>
																<p><?php echo nl2br($s_cmnt['comment_data']); ?></p>
																<?php  reply_btn($s_cmnt['comment_id']); ?>
															</div>
														</div>
														<ul class="children">
															<?php
															$comment_third_detail = $this->langar_model->select_data('blog_comment.*, users.user_name, users.profile_image','blog_comment' , array('comment_parent' => $s_cmnt['comment_id'], 'comment_status' => 1) , '' , array('comment_id','ASC') , '' , array('users','users.user_id = blog_comment.cmmented_by'));
															if(!empty($comment_third_detail)){
																foreach($comment_third_detail as $t_cmnt){
																?>
																<li>
																	<div class="comment-wrap">
																		<div class="comment-meta">
																			<div class="comment-author">
																				<span class="comment-avatar">
																				<img src="<?php $img2 = ($t_cmnt['profile_image'] != '')?$t_cmnt['profile_image']:'profile.jpg'; echo base_url('assets/img/profile/'.$img2);  ?>" class="img-responsive" alt="<?php echo $t_cmnt['user_name']; ?>" title="<?php echo $t_cmnt['user_name']; ?>">
																			</span>
																			</div>
																		</div>
																		<div class="comment-content">
																			<div class="comment-author">
																				<a class="url"><?php echo $t_cmnt['user_name']; ?></a>
																				<span><?php echo date('M d, Y  h:i a' , strtotime($t_cmnt['comment_date'])); ?></span>
																			</div>
																			<p><?php echo nl2br($t_cmnt['comment_data']); ?></p>
																		</div>
																	</div>
																</li>
																<?php
																}
															}
															?>
														
														</ul>
													</li>
													<?php
													}
													echo '</ul>';
												}
												?>
											</li>
											<?php
										}
										?>
									</ol>	
								</div>
								<?php
								}
								
								if($this->session->userdata('role') == 2){
									?>
									<div id="respond">
										<h4 id="comments-title2">Leave a Comment</h4>
										<div class="row">
											<form id="comment_form" method="post" action="<?php echo base_url('user_action/post_comment'); ?>">
												<input type="hidden" name="post_id" value="<?php echo $blog_detail['0']['post_id']; ?>">
												<?php /*<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
													<div class="form-group">
														<input type="text" value="" class="form-control" placeholder="Name">
													</div>
												</div>
												<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
													<div class="form-group">
														<input type="text" value="" class="form-control" placeholder="Email">
													</div>
												</div>*/ ?>
												<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
													<div class="form-group">
														<textarea class="form-control require" rows="7" placeholder="Type your comment here..." name="comment"></textarea>
													</div>
												</div>
												<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 sup_toppadder20">
													<div class="form-group">
														<button type="button"  onclick="return check_form_valid('comment_form' , this)" class="ls_btn">submit </button>
													</div>
												</div>
											</form>
										</div>
									</div>
									<?php 
								}
							}
							?>
						</div>
						<?php
					} 
					?>
				</div>
			</div>
			<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
				<div class="ls_sidebar">
					<?php /*<div class="widget search-widget">
						<form class="form-inline">
							<div class="form-group">
								<input type="text" class="form-control" placeholder="Search">
							</div>
							<button type="submit"><i class="fa fa-search" aria-hidden="true"></i>
							</button>
						</form>
					</div>
					<div class="widget widget-categories">
						<h4>CAtegories</h4>
						<ul>
							<?php echo (isset($post_category_data))?$post_category_data:''; ?>
						</ul>
					</div> */?>
					<div class="widget widget-recent-post">
						<h4> Recent Post</h4>
						<ul>
							<?php echo (isset($recent_post_data))?$recent_post_data:''; ?>
						</ul>
					</div>
					<?php /*<div class="widget widget-tag-cloud">
						<h4>TAgs</h4>
						<a>Design</a>
						<a>Business</a>
						<a>Web</a>
						<a>Art</a>
						<a>Technology</a>
						<a>Mobile</a>
						<a>Corporate</a>
						<a>Websites</a>
					</div> */?>
				</div>
			</div> 
		</div>
	</div>
</div>

<div id="reply_box" class="hide">
	<div class="ls_replybox">
		<form method="post" action="<?php echo base_url('user_action/post_comment'); ?>" id="reply_form">
			<input type="hidden" name="post_id" value="<?php echo $blog_detail['0']['post_id']; ?>">
			<input type="hidden" name="comment_parent">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="form-group">
						<textarea class="form-control require" rows="7" name="reply" placeholder="Type your reply here..."></textarea>
					</div>
				</div> 
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 sup_toppadder20">
					<div class="form-group">
						<button onclick="return check_form_valid('reply_form' , this)" type="button" class="ls_btn">submit </span>
						</button>
					</div>
				</div>
			</div>
		</form>													
	</div>
</div>