<div class="ls_breadcrumb_wrapper ls_toppadder50 ls_bottompadder50">
	<div class="ls_overlay"></div>
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<h3>contact us</h3>
				<ul>
					<li><a href="<?php echo base_url(); ?>">home</a></li>
					<li>contact us</li>
				</ul>
			</div>
		</div>
	</div>
</div>
<div class="ls_innerpages_wrapper ls_contactpage ls_toppadder100 ls_bottompadder100">
	<div class="container">
		<div class="row">
			<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
				<div class="ls_headings ls_bottompadder60">
					<h1>CONTACT INFO </h1>
				</div>
				<div class="ls_contact_detail">
					<span>We are also active in social media. You can find us on below</span>
					<p><i class="fa fa-phone"></i><?php echo $this->site_detail->site_mobile; ?></p>
					<p><i class="fa fa-envelope"></i> <a><?php echo $this->site_detail->site_email; ?></a></p>
					<!--<p><i class="fa fa-map-marker"></i> PO Box 97845 Baker st. 567, Los Angeles, California, US.</p> ---->
					<div class="ls_contact_social_icon">
						<ul>
							<li><a target="_blank" href="<?php echo 'https://www.facebook.com/sharer/sharer.php?u='.base_url(); ?>"><i class="fa fa-facebook"></i></a></li>
							<li><a target="_blank" href="<?php echo 'https://twitter.com/home?status='.base_url(); ?>"><i class="fa fa-twitter"></i></a></li>
							<li><a target="_blank" href="<?php echo 'https://plus.google.com/share?url='.base_url(); ?>"><i class="fa fa-google-plus"></i></a></li>
						</ul>
					</div>
				</div> 
			</div>
			<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
				<div class="ls_headings ls_bottompadder60">
					<h1>SEND A MESSAGE</h1>
				</div>
				<div class="ls_contact_form">
					<div class="row">
						<form method="post" id="contact_form">
						<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 ls_bottompadder20">
							<input type="text" name="c_name" class="require" placeholder="Enter your Name">
						</div>
						<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 ls_bottompadder20">
							<input type="text" class="require" data-valid="email" data-error="Email should be valid"  name="c_email"  placeholder="Enter your email">
						</div>
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 ls_bottompadder20">
							<input type="text" name="c_subject" class="require" placeholder="Enter your subject">
						</div>
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 ls_bottompadder20">
							<textarea class="require" name="c_message" placeholder="Enter your message"></textarea>
						</div>
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 ls_bottompadder20">
							<button type="button" onclick="check_form_valid('contact_form' , this)" class="ls_btn">Send</button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>