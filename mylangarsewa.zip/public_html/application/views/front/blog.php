<div class="ls_breadcrumb_wrapper ls_toppadder50 ls_bottompadder50">
	<div class="ls_overlay"></div>
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<h3>Blog</h3>
				<ul>
					<li><a href="<?php echo base_url(); ?>">home</a></li>
					<li>Blog</li>
				</ul>
			</div>
		</div>
	</div>
</div>
<div class="ls_innerpages_wrapper ls_toppadder100 ls_bottompadder100">
	<div class="container">
		<div class="row">
			<div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
				<div class="post-timeline">
					<?php
					if(isset($blog_detail) && !empty($blog_detail)){
						foreach($blog_detail as $blog){
							?>
							<div class="entry">
								<div class="entry-image">
									<img src="<?php echo base_url('assets/img/post/'.$blog['post_image']); ?>" class="img-responsive" alt="">
								</div>
								<div class="entry-title">
									<h2><a href="<?php echo base_url('blog/'.$blog['post_slug']); ?>"><?php echo $blog['post_title']; ?></a></h2>
								</div>
								<ul class="entry-meta">
									<li><a>By Admin</a>
									</li>
									<?php /*<li><a><?php echo $blog['category_title']; ?></a>
									</li> */?>
									<li><a>Posted on <?php echo date('d M Y' , strtotime($blog['post_date'])); ?></a>
									</li>
								</ul>
								<div class="entry-content">
									<p><?php echo $blog['post_description']; ?></p>
									<a href="<?php echo base_url('blog/'.$blog['post_slug']); ?>" class="more-link ls_btn">Read More </a>
								</div>
							</div>	
							<?php
						}
					}
					?>
				</div>
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<?php echo (isset($pagination_data))?$pagination_data:''; ?>
				</div>
			</div>
			
			<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
				<div class="ls_sidebar">
					<?php /*<div class="widget search-widget">
						<form class="form-inline">
							<div class="form-group">
								<input type="text" class="form-control" placeholder="Search">
							</div>
							<button type="submit"><i class="fa fa-search" aria-hidden="true"></i>
							</button>
						</form>
					</div>
					<div class="widget widget-categories">
						<h4>CAtegories</h4>
						<ul>
							<?php echo (isset($post_category_data))?$post_category_data:''; ?>
						</ul>
					</div>*/ ?>
					<div class="widget widget-recent-post">
						<h4> Recent Post</h4>
						<ul>
							<?php echo (isset($recent_post_data))?$recent_post_data:''; ?>
						</ul>
					</div> 
					<?php /*<div class="widget widget-tag-cloud">
						<h4>TAgs</h4>
						<a>Design</a>
						<a>Business</a>
						<a>Web</a>
						<a>Art</a>
						<a>Technology</a>
						<a>Mobile</a>
						<a>Corporate</a>
						<a>Websites</a>
					</div> */?>
				</div>
			</div>
		</div>
	</div>
</div>