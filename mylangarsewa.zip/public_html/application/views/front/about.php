<div class="ls_breadcrumb_wrapper ls_toppadder50 ls_bottompadder50">
	<div class="ls_overlay"></div>
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<h3>about us</h3>
				<ul>
					<li><a href="<?php echo base_url(); ?>">home</a></li>
					<li>about us</li>
				</ul>
			</div>
		</div>
	</div>
</div>
<div class="ls_about_wrapper ls_toppadder50 ls_bottompadder50">
	<div class="lg_notification">
		<?php 
		$notice_detail = $this->langar_model->select_data('*','notice_message' , array('notice_status' => 1));
		echo (!empty($notice_detail))?'<marquee >'.$notice_detail['0']['notice_text'].'</marquee>':'';
		?>
	</div>
</div>
<div class="ls_about_wrapper ls_bottompadder50">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="ls_headings ls_bottompadder60">
					<h1>who we are</h1>
					<!--<p>what members are saying about our services</p>-->
				</div>
			</div>
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<p>MyLangarSewa is an online platform through which you can give your Langar Sewa in Golden Temple . Website gives you two simple options to order your sewa </p>
				<ol>
					<li>You can simply order with the amount of sewa you are offering and our team will create a package of items based on the amount you have paid and gives you official receipt for the same</li>
					<li>You can simply order with the amount of sewa and select the products you want to offer as sewa , then our team will create the package based on the items you have selected  and provide you official receipt for the same.</li>
					<li>Third option of sewa where people can order the sewa and we will create the package for them and deliver them on the date of their arrival at any location in Amritsar City.</li>
				</ol>
				<p>MyLangarSewa team is serving  sewa  offline from their 60 year old counter in Amritsar. We have a great knowledge and experience in processing sewa. We provide the best and quality products with a reasonable price.  Our team of volunteers helps you not only to process LangarSewa but also assist you on every other stuffs you need when you visit Amritsar.</p>
				<p>For any more information drop your questions at – info@mylangarsewa.com</p>
			</div>
			<?php /*<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
				<div class="ls_our_info_wrapper">
					<h4>our vision</h4>
					<p>The philosophy behind the Langar (Guru's kitchen-cum-eating-house) is two-fold : to provide training to the Sikhs in voluntary service and to help banish all distinction of high and low, touchable and untouchable from the Sikhs' minds. </p>
				</div>
			</div>
			<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
				<div class="ls_our_info_wrapper">
					<h4>our mission</h4>
					<p>All human beings, high or low, and of any caste or colour may sit and eat in the Langar. No discrimination on grounds of the country of origin, colour, caste or religion must be made while making people sit in rows for eating. However, only Amritdhari Sikhs can eat off one plate.</p>
				</div>
			</div> */ ?>
		</div>
	</div>
</div>
<?php /*
<div class="ls_wedo_wrapper ls_toppadder100 ls_bottompadder100">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="ls_headings ls_bottompadder60">
					<h1>what we do</h1>
					<p>what members are saying about our services</p>
				</div>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 ls_bottompadder40">
				<div class="ls_work_section">
					<i class="fa fa-american-sign-language-interpreting" aria-hidden="true"></i>
					<p>Seva is a prominent part of Sikh religion. Illustrative models of voluntary service are organised for imparting training, in the Gurdwaras.</p>
				</div>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 ls_bottompadder40">
				<div class="ls_work_section">
					<i class="fa fa-users" aria-hidden="true"></i>
					<p>Seva is a prominent part of Sikh religion. Illustrative models of voluntary service are organised for imparting training, in the Gurdwaras.</p>
				</div>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 ls_bottompadder40">
				<div class="ls_work_section">
					<i class="fa fa-wheelchair" aria-hidden="true"></i>
					<p>Seva is a prominent part of Sikh religion. Illustrative models of voluntary service are organised for imparting training, in the Gurdwaras.</p>
				</div>
			</div>
			
		</div>
		<div class="row">
			<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ls_toppadder40">
				<div class="ls_imagediv">
					<a><img src="http://placehold.it/450X300" class="img-responsive" alt=""></a>
				</div>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ls_toppadder40">
				<div class="ls_imagediv">
					<a><img src="http://placehold.it/450X300" class="img-responsive" alt=""></a>
				</div>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ls_toppadder40">
				<div class="ls_imagediv">
					<a><img src="http://placehold.it/450X300" class="img-responsive" alt=""></a>
				</div>
			</div>
		</div>
	</div>
</div> */ ?>