<!-- search popup start -->
<!--<div class="ls_search_popup">
<div class="close_button">X</div>
	<div class="search_overlay"></div>
	<div class="ls_search_body">
	 <div class="search_title">Search cars</div>
		<form>
			<div class="search_wrapper">
				<input placeholder="Start search here..." type="text" class="search_form" value="" name="search" id="search_car">
				<button type="submit" class="search_submit"><i class="fa fa-search"></i></button>
			</div>
		</form>
	</div>
</div>-->
<!-- search popup start -->
<?php 
	$item_data = '';
	$item_id = array();
	if(isset($item_detail) && !empty($item_detail)){	
		$coutn_item = round(count($item_detail)/2);
		$chk_cnt = 1;
		foreach($item_detail as $item){
			array_push($item_id,$item['item_id']);
			$item_data .= '
			<li>
				<div class="ls_checkbox">
					<input type="checkbox" value="'.$item['item_id'].'" id="check'.$item['item_id'].'" name="item[]">
					<label for="check'.$item['item_id'].'"></label>
				</div>
				<span>'.$item['item_name'].'</span>
			</li>';
			if($chk_cnt++ == $coutn_item){
				$item_data .= '</ul><ul>';
			}
		}
	}
	
	$item_data_two = $item_data;
	foreach($item_id as $item_i){
		$item_data_two = str_replace('check'.$item_i , 'checka'.$item_i , $item_data_two);
	}
	
	
	$item_qun = '';
	if(isset($item_detail) && !empty($item_detail)){
		$cnt_item = count($item_detail);
		for($cn = 1; $cn <= $cnt_item; $cn++){
			$item_qun .= '<li>
				<select name="item_qun[]">';
			for($wt=1; $wt<11; $wt++){
				$item_qun .= '<option value="'.$wt.'">'.$wt.' kg</option>';
			}
			$item_qun .= '</select>
				</li>';
		}
	} 
	?>
	
<div class="ls_main_banner_wrapper" style="background-image: url(assets/images/banner_img.jpg);">
	<div class="ls_banner_content">
		<div class="ls_banner_calender">
			<h1>Calendar ~ 2018-2019 ~ Chet</h1>
			
			<ul>
				<li>
					<span class="pull-left">Guru Hargobind Ji left this world</span>
					<span class="pull-right ls_banner_date">1 april</span>
				</li>
				<li> 
					<span class="pull-left">Guru Harikrishan Ji left this world </span>
					<span class="pull-right ls_banner_date">9 april</span>
				</li>
				<li>
					<span class="pull-left">Birth of Sahibzada Jujhar Singh Ji</span>
					<span class="pull-right ls_banner_date">10 april</span>
				</li>
				<li>
					<span class="pull-left">Accession of Guru Tegh Bahadur Ji</span>
					<span class="pull-right ls_banner_date">10 april</span>
				</li>
			</ul>
		</div>
		<div class="ls_banner_title">
			<h1>MY LANGAR SEWA</h1>
		</div>
		
		<div class="ls_banner_icon">
			<img src="assets/images/banner_icon.png" alt="">
		</div>
	</div>
</div>
<div class="ls_quantity_wrapper">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="ls_sewa_tab">
					<div class="row">
						<div class="col-lg-10 col-md-10 col-sm-12 col-xs-12 col-lg-offset-1 col-md-offset-1 col-sm-offset-0 col-xs-offset-0">
							<!-- Nav tabs -->
							<ul class="nav nav-tabs" role="tablist">
								<li role="presentation" class="active"><a href="#process_sewa" aria-controls="process_sewa" role="tab" data-toggle="tab">Deliver Your Sewa</a></li>
								<li role="presentation"><a href="#request_quotation" aria-controls="request_quotation" role="tab" data-toggle="tab">Book My Sewa</a></li>
							</ul>
						</div>
					</div>

					<!-- Tab panes -->
					<div class="tab-content">
						<div role="tabpanel" class="tab-pane active" id="process_sewa">
							<div class="row">
								<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 col-lg-offset-2 col-md-offset-2 col-sm-offset-0 col-xs-offset-0 ls_toppadder40">
									<form method="post" onsubmit="return process_your_sewa_form_c(this)" action="<?php echo base_url('home/pay'); ?>"> 
										<div class="ls_amount_value_box ">
											<label>select your currency </label>
											<span> 
												<select name="select_currency" class="require">
													<option value="0">Choose Currency</option>
													<option target-amount="25" data-target="$" value="USD">USD</option>
													<option target-amount="20" data-target="£" value="GBP">GBP</option>
													<option   target-amount="20" disabled data-target="€" value="EURO">EURO </option>
													<option  target-amount="2000" disabled data-target="<i class='fa fa-inr'></i>" value="INR">INR</option>
												</select>
											</span>
										</div>  
										<div class="ls_amount_value_box ">
											<label>enter amount</label>
											<span><input type="text" name="sewa_amount" placeholder="" class="require return_number"></span>
											<p class="min_cur">Minimum $25</p>
										</div>
										<div class="ls_itemselect ls_amount_value_box">
											<label>Do you Want to select Items</label>
											<div class="ls_radio"><input type="radio"  data-target="ls_showhide_div" name="sel_item" value="1" id="radio1"><label for="radio1"></label><span>Yes</span></div>
											
											<div class="ls_radio"><input type="radio" name="sel_item" value="0"  data-target="ls_showhide_div" checked id="radio2"><label for="radio2"></label><span>No</span></div>
										</div>
										<div class="ls_product_box ls_showhide_div">
											<div class="row">
												<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
													<div class="ls_product_name">
														<h5>select your item</h5>
														<ul id="sewa_item_list"><?php echo (isset($item_data))?$item_data:''; ?></ul>
													</div>
												</div>
												<!---<div class="col-lg-8 col-md-8 col-sm-6 col-xs-12">
													<div class="ls_product_quantity">
														<h5>quantity</h5>
														<ul><?php echo (isset($item_qun))?$item_qun:''; ?></ul>
													</div>
												</div> ---->
											</div>
										</div>
										<div class="ls_notesection">
											<h1>Note: If you don't want to select Items, then we will create package for you.</h1>
										</div>
										 <div class="ls_arrivaldiv">
											<div class="ls_arrivaldiv_inner">
												<h4 class="modal-title">Mode Of Delivery</h4>
												<p>
													<span class="ls_radio">
														<input data-target="ls_arrivaldate" type="radio"  value="0" checked name="arrive_temp" id="radio3">
														<label for="radio3"></label>
													</span>
													We deliver on your behalf and give you official receipt
												</p>
												<p>
													<span class="ls_radio">
														<input type="radio" value="1" data-target="ls_arrivaldate" name="arrive_temp" id="radio4">
														<label for="radio4"></label>
													</span>
													We will deliver on your arrival at Temple or Wherever you want in Amritsar City.
												</p>
												<div class="ls_arrivaldate">
													<span class="ls_date">Expected Date</span>
													<input type="text" id="datepicker1" name="expected_date" class="ls_dateinput">
												</div>
											</div>
										</div>
										<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
											<div class="ls_info_feild">
												<input type="text" name="s_name" class="require" placeholder="Name" value="<?php echo ($this->session->userdata('name'))?$this->session->userdata('name'):''; ?>">
												<input type="text"  name="s_phone" class="require" placeholder="Contact No" value="<?php echo (isset($user_contact))?$user_contact:''; ?>" > 
												<input type="text" name="s_email" class="require" placeholder="Email" data-valid="email" data-error="Email should be valid"  value="<?php echo ($this->session->userdata('email'))?$this->session->userdata('email'):''; ?>">
												<!-- 
												 data-valid="mobile" data-error="Contact no. should be valid."
												<a href="" class="ls_btn" data-toggle="modal" data-target="#myModal">proceed for payment</a> -->
												<button type="submit" class="ls_btn sub-button">proceed for payment</button>
												
											</div>
											<div class="ls_notesection">
												<h1>Note: On arrival orders can be cancelled before 48 hours of arrival , but instant delivery orders can not be cancelled as they get processed within 24 hours.</h1>
											</div>	
										</div>
									</form>	
								</div>
							</div>
						</div>
						<div role="tabpanel" class="tab-pane" id="request_quotation">
							<div class="row">
								<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 col-lg-offset-2 col-md-offset-2 col-sm-offset-0 col-xs-offset-0 ls_toppadder20">
									<div class="ls_product_box ls_toppadder40">
										<div class="row">
											<form method="post" id="req_for_qu">
												<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
													<div class="ls_product_name">
														<h5>select your item</h5>
														<ul><?php echo (isset($item_data_two))?$item_data_two:''; ?></ul>
													</div>
												</div>
												<!----<div class="col-lg-8 col-md-8 col-sm-6 col-xs-12">
													<div class="ls_product_quantity">
														<h5>quantity</h5>
														<ul><?php echo (isset($item_qun))?$item_qun:''; ?></ul>
													</div>
												</div>--->
												<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
													<div class="ls_info_feild">
														<input type="text" class="require" placeholder="Name">
														<input type="text" class="require" placeholder="Phone">
														<input type="text" class="require" placeholder="Email">
														<button type="button" onclick="request_for_quote('req_for_qu' , this)" class="ls_btn">Request For Quote</a>
													</div>
												</div>
											</form>	
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="ls_counter_wrapper">
	<div class="ls_overlay"></div>
	<div class="container">
		<div class="row">
			<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
				<div class="ls_counter">
					<h2 class="timer" data-from="0" data-to="1" data-speed="5000"></h2>
					<p>Sewa in Process</p>
				</div>
			</div>
			<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
				<div class="ls_counter">
					<h2 class="timer" data-from="0" data-to="7" data-speed="5000"></h2>
					<p>Sewa Completed</p>
				</div>
			</div>
			<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
				<div class="ls_counter">
					<h2 class="timer" data-from="0" data-to="12" data-speed="5000"></h2>
					<p>members</p>
				</div>
			</div>
			<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
				<div class="ls_counter">
					<h2 class="timer" data-from="0" data-to="4" data-speed="5000"></h2>
					<p>volunteer</p>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
/*
if(isset($testimonial_detail) && !empty($testimonial_detail)){
	?>
	<div class="ls_testimonial_wrapper">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="ls_headings ls_bottompadder60">
						<h1>what people say</h1>
						<p>what members are saying about our services</p>
					</div>
					<div class="ls_testimonial_slider">
						<div class="row">
							<div class="col-lg-10 col-md-10 col-sm-12 col-xs-12 col-lg-offset-1 col-md-offset-1 col-sm-offset-0 col-xs-offset-0">
								<div class="owl-carousel owl-theme">
									<?php 
									foreach($testimonial_detail as $testrimonal){
										echo '
										<div class="item">
											<div class="ls_testimonial">
												<div class="ls_testimonial_img">
													<img src="'.base_url('assets/').'images/testimonial1.jpg" class="img-responsive" alt="">
													<h2>'.$testrimonal['user_name'].'</h2>
												</div>
												<div class="ls_testimonial_data">
													<p>'.nl2br($testrimonal['testimonial_data']).'</p>
												</div>
											</div>
										</div>';
									}
									?>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php
}

*/
?>
