<!doctype html>
<html>
<head>
<meta name="viewport" content="width=device-width">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title><?php echo $this->site_detail->site_name; ?> - reset password</title>
<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
</head>

<body style="-webkit-font-smoothing: antialiased;  height: 100%;  -webkit-text-size-adjust: none;  width: 100% !important;font-family: 'Open Sans', sans-serif;  font-size: 100%;  line-height: 1.6em;  margin: 0;  padding: 100px 0; background-color: #264766;">

<!-- body -->
<table style="max-width: 500px; margin:0 auto; background-color: #f3f3f3; color:#2a445b; display: block; font-size:16px;" border="0">
	<thead>
    	<tr>
        	<td><a href="<?php echo base_url(); ?>"><img style="float: left; margin: 26px 20px 26px 38px;" src="<?php echo base_url($this->site_detail->site_logo); ?>" alt="" width="240" height="21" /></a></td>
		</tr>
    </thead>
    <tbody style="padding: 30px; background-color: white;display:block;">
    	<tr style="display:block;"> 
			<td>
				<h3>Hi <?php echo (isset($user_name))?$user_name:''; ?>,</h3>
				<p>Your receipt for request no. '<?php echo $request_id; ?>'  is given below.</p>
				<p  style="padding-bottom:20px;">Please find the attachment.</p>
			</td>
        </tr>
        <tr style="display:block;">
        	<td>
				<p>Thanks,</p>
				<p>Team <?php echo $this->site_detail->site_name; ?>.</p>
			</td>
        </tr>
    </tbody>
    <tfoot style="background-color:#03A9F4;display:block; text-align:center;">
    	<tr style="display:block;">
        	<td style="display:block; color:#ffffff; padding:20px; margin:0 30px; font-size:12px;"><?php echo $this->site_detail->site_copyright; ?></td>
        </tr>
    </tfoot>
</table>
<!-- /body -->

<!-- footer -->

<!-- /footer -->

</body>
</html>