<!doctype html>
<html>
<head>
<meta name="viewport" content="width=device-width">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title><?php echo $this->site_detail->site_name; ?> - Forgot password</title>
<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
</head>

<body style="-webkit-font-smoothing: antialiased;  height: 100%;  -webkit-text-size-adjust: none;  width: 100% !important;font-family: 'Open Sans', sans-serif;  font-size: 100%;  line-height: 1.6em;  margin: 0;  padding: 100px 0; background-color: #264766;">

<!-- body -->
<table style="max-width: 500px; margin:0 auto; background-color: #f3f3f3; color:#2a445b; display: block; font-size:16px;" border="0">
	<thead>
    	<tr>
        	<td><a href="<?php echo base_url(); ?>"><img style="float: left; margin: 26px 20px 26px 38px;" src="<?php echo base_url($this->site_detail->site_logo); ?>" alt="" width="240" height="21" /></a></td>
		</tr>
    </thead>
    <tbody style="padding: 30px; background-color: white;display:block;">
    	<tr style="display:block;"> 
			<td>
				<h3>Hi <?php echo (isset($user_name))?$user_name:''; ?>,</h3>
				<p  style="padding-bottom:10px;">We have received a request to reset the password for your account at <?php echo $this->site_detail->site_name; ?>.</p>
			</td>
        </tr>
        <tr style="display:block;">
        	<td style="padding-bottom:10px;">Just click the button below, to initiate your Reset Password request.</td>
        </tr>
        
        <tr style="display:block; text-align:center;">
        	<td style="display:inline-block;"><a href="<?php echo (isset($reset_link))?$reset_link:''; ?>" style="padding: 0px 25px; text-decoration: none; letter-spacing: 1px; margin: 30px auto; border: none; display: inline-block; height: 40px; line-height: 38px; color: rgb(255, 255, 255); font-weight: 500; border-radius: 3px; background-color: rgb(3, 169, 244); opacity:1;filter:alpha(opacity=100)" onmouseover="this.style.opacity=0.9;this.filters.alpha.opacity=90" onmouseout="this.style.opacity=1;this.filters.alpha.opacity=100">Reset password</a></td>
        </tr>
        
        <tr style="display:block; text-align:center; font-size:14px;">
        	<td style="display: inline-block;">Or using this link: <a  href="<?php echo (isset($reset_link))?$reset_link:''; ?>" onMouseOver="this.style.color='rgb(40, 32, 68)'" onMouseOut="this.style.color='#16a6de'" style="color:#03A9F4; text-decoration:underline;"><?php echo (isset($reset_link))?$reset_link:''; ?></a></td>
        </tr>
		<tr style="display:block;">
        	<td>
				<p>Thanks,</p>
				<p>Team <?php echo $this->site_detail->site_name; ?>.</p>
			</td>
        </tr>
    </tbody>
    <tfoot style="background-color:#03A9F4;display:block; text-align:center;">
    	<tr style="display:block;">
        	<td style="display:block; color:#ffffff; padding:20px; margin:0 30px; font-size:12px;"><?php echo $this->site_detail->site_copyright; ?></td>
        </tr>
    </tfoot>
</table>
<!-- /body -->

<!-- footer -->

<!-- /footer -->

</body>
</html>
