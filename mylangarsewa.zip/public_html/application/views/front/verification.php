<div class="ls_breadcrumb_wrapper ls_toppadder50 ls_bottompadder50">
	<div class="ls_overlay"></div>
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<h3>verification</h3>
				<ul>
					<li><a href="<?php echo base_url(); ?>">home</a></li>
					<li><?php echo (isset($type) && $type== 1)?'Verification':((isset($type) && $type== 2)?'Reset Password':'Payment Notice'); ?></li>
				</ul>
			</div>
		</div>
	</div>
</div>
<div class="ls_innerpages_wrapper ls_toppadder100 ls_bottompadder100">
	<div class="container">
		<div class="row">
			<?php 
			if(isset($type) && $type== 1){
				echo '<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">';
				echo ($status == 1)?'	
						<div class="ls_normalbox alert-success">
							<h3>Congratulation! Your account is verified successfully... </h3>
							<p>Now You can login</p>
							<a data-toggle="modal" data-target="#loginpopup" class="ls_loginbtn">Login</a>
						</div>':
						'<div class="ls_normalbox alert-info">
							<h3>Oops! This link is used or  invalid ... </h3>
							<p>Please check your email or try again</p>
						</div>';
				echo '</div>';	
				
			}elseif(isset($type) && $type== 2){
				?>
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 ls_toppadder50">
					<?php
					if($status == 1){
						?>
						<div class="ls_normalbox">
							<h2>Reset Your Password</h2>
							<form method="post">
								<div class="form-group">
									<div class="row">
										<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
											<label>Enter Password</label>
										</div>
										<div class="col-lg-8 col-md-8 col-sm-6 col-xs-12">
											<input type="password" name="pass" id="pass" class="require" placeholder="Enter your New Password" value="">
										</div>	
									</div>
								</div>
								<div class="form-group">
									<div class="row">
										<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
											<label>Re-Enter Password</label>
										</div>
										<div class="col-lg-8 col-md-8 col-sm-6 col-xs-12">
											<input type="password" name="re_pass" id="re_pass" class="require" placeholder="Re-Enter your Password" value="">
										</div>	
									</div>
								</div>
								<div class="form-group">
									<div class="row">
										<div class="col-lg-8 col-md-8 col-sm-6 col-xs-12 col-lg-offset-4 col-md-offset-4 col-sm-offset-6">
											<button type="button" class="ls_loginbtn passwordReset">Submit</button>
										</div>
									</div>
								</div>
							</form>
						</div>
						<?php
					}else{
						echo '<div class="ls_normalbox alert-info">
								<h3>Oops! This link is used or  invalid ... </h3>
								<p>Please check your email or try again</p>
							</div>';
					}
					?>
				</div>
				<?php
			}

			if(isset($pay_notice)){
				if($pay_status == 'Completed'){
					echo '<div class="ls_normalbox alert-success">
							<h3>Your request for My Langar Sewa is submitted Successfully.</h3>
							<p>Check your email to more detail.</p>
						</div>';
				}else{
					echo '<div class="ls_normalbox alert-info">
						<h3>Oops! Your payment has '.strtolower($pay_status).'.</h3>
						<p>Please try again.</p>
					</div>';	
				}
			}			
			?>
        </div>
    </div>
</div>