<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
<!--<![endif]-->
<!-- BEGIN HEAD -->

<head>
    <meta charset="utf-8">
    <title><?php echo $this->site_detail->site_title; ?></title>
	<meta content="<?php echo $this->site_detail->site_title; ?>" property="og:title">
	<meta content="website" property="og:type">
	<meta content="<?php echo base_url(); ?>" property="og:url">
	<meta name="MobileOptimized" content="320">
	<meta content="<?php echo $this->site_detail->site_name; ?>" property="og:site_name">
	<meta content="<?php echo $this->site_detail->site_logo; ?>" property="og:image">
	<meta content="<?php echo $this->site_detail->site_description; ?>" property="og:description">
	<meta name="keywords" content="<?php echo $this->site_detail->site_keywords; ?>">
	<meta name="author" content="<?php echo $this->site_detail->site_name; ?>">
	<!--google fonts-->
	<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
	<!--google fonts-->
    <!--srart style -->
    <link href="<?php echo base_url('assets/');?>css/main.css" rel="stylesheet" type="text/css">
    <!-- end style -->
    <!-- favicon links -->
    <link rel="shortcut icon" type="image/png" href="<?php echo base_url($this->site_detail->site_favicon);?>">
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-35935151-36', 'auto');
  ga('send', 'pageview');

</script>
</head>
<body>
<div class="ls_wrapper <?php echo 'ls_inner_header'; //echo (!isset($index))?'ls_inner_header':''; ?>">
	<header>
		<div class="ls_topheader">
			<div class="container">
				<div class="row">
					<div class="col-lg-7 col-md-7 col-sm-7 col-xs-12">
						<div class="ls_toplinks">
							<ul>
								<li><i class="fa fa-phone"></i><?php echo $this->site_detail->site_mobile; ?></li>
								<li><a><i class="fa fa-envelope"></i><?php echo $this->site_detail->site_email; ?></a></li>
							</ul>
						</div>
					</div>
					<div class="col-lg-5 col-md-5 col-sm-5 col-xs-12">
						<div class="ls_topbtns">
							<?php 
							if($this->session->userdata('login') == 1){
								$target = ($this->session->userdata('login') == 1)?'admin':'member';
								echo '<ul>
										<li><a href="'.base_url($target).'"> Dashboard </a></li>
										<li><a href="'.base_url('home/logout').'"> Log out </a></li>
									</ul>';
							}else{
								echo '<ul>
										<li><a data-toggle="modal" data-target="#loginpopup"> login </a></li>
										<li><a data-toggle="modal" data-target="#signuppopup"> sign up </a></li>
									</ul>';
							}
							?>
							<?php if($this->session->userdata('login') != 1){  include('modal.php'); } ?>
						</div>
					</div>
				</div>
			</div>
		</div> 
		<div class="ls_mainmenu">
			<div class="container">
				<div class="row">
					<div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
						<div class="ls_logo">
							<a href="<?php echo base_url(); ?>"><img src="<?php echo base_url($this->site_detail->site_logo); ?>"><!--<h3>my langar sewa</h3>--></a>
							<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
						</div>
					</div>
					<div class="col-lg-9 col-md-9 col-sm-8 col-xs-12">
						<div class="ls_menu">
							<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
								<ul class="nav navbar-nav">
									<?php /*<li <?php echo (isset($index) && $index == true)?'class="active"':''; ?>><a href="<?php echo base_url();  ?>">HOME</a></li> */ ?>
									<li <?php echo (isset($langar_sewa) && $langar_sewa == true)?'class="active"':''; ?>><a href="<?php echo base_url('langar-sewa'); ?>">langar sewa</a></li>
									<li <?php echo (isset($about) && $about== true)?'class="active"':''; ?>><a href="<?php echo base_url('about'); ?>">About us</a></li>
									
									<li <?php echo (isset($blog) && $blog == true)?'class="active"':''; ?>><a href="<?php echo base_url('blog'); ?>">BLOG</a></li>
									<li <?php echo (isset($contact) && $contact == true)?'class="active"':''; ?>><a href="<?php echo base_url('contact'); ?>">CONTACT us</a></li>
									<!--<li><a href="javascript:;" class="ls_search"><i class="fa fa-search" aria-hidden="true"></i></a></li>-->
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header> 
	<input type="hidden" id="base_url" value="<?php echo base_url(); ?>">
	<?php
		if(isset($index) && $index == true){
			?>
			<div class="ls_langar_sewa_slider ls_toppadder20">
				<div class="owl-carousel owl-theme">
						<?php
						if(isset($gallery_image) && !empty($gallery_image)){
							foreach($gallery_image as $image){
								echo '
								<div class="item">
									<img src="'.base_url('assets/img/gallery/'.$image['g_image']).'" class="img-responsive" alt="">
								</div>';
								
							}
						}	
					?>
				</div>
			</div>
			<?php 
			/*echo '<div class="ls_banner_div">
					<img src="'.base_url('assets/').'images/mainbanner.jpg" class="img-responsive" alt="">
				</div>';
			*/	
		}
	?>
</div>