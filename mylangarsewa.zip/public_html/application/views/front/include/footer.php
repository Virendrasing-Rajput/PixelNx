<div class="ls_footer_top">
	<div class="container">
		<div class="row">
			<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
				<div class="ls_footer_headings">
					<h4>about us</h4>
				</div>
				<div class="ls_about_info">
					<p>MyLangarSewa is an online platform through which you can give your Langar Sewa in Golden Temple . Website gives you two simple options to order your sewa.</p>
				</div>
			</div>
			<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
				<div class="ls_footer_headings">
					<h4>products range</h4>
				</div>
				<div class="ls_product_range">
					<ul>
						<?php 
						$sewa_item = $this->langar_model->select_data('item_name' , 'item' , '' , 10 , array('item_id' , 'ASC'));
						if(!empty($sewa_item)){
							foreach($sewa_item as $item){
								echo '<li><a>'.explode('-',$item['item_name'])[0].'</a></li>';
							}
						}
						?>
					</ul>
				</div>
			</div>
			<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
				<div class="ls_footer_headings">
					<h4>Contact Info</h4>
				</div>
				<div class="ls_contact_info">
					<ul>
						<li>
							<p><i class="fa fa-phone"></i><?php echo $this->site_detail->site_mobile; ?></a></p>
						</li>
						<li>
							<p><i class="fa fa-envelope"></i> <a><?php echo $this->site_detail->site_email; ?></a></p>
						</li>
						<?php /*<li>
							<p><i class="fa fa-map-marker"></i> PO Box 97845 Baker st. 567, Los Angeles, California, US.</p>
						</li> */?>
					</ul>
				</div>
			</div>
			<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
				<div class="ls_footer_headings">
					<h4>gallery</h4>
				</div>
				<div class="ls_flickr_gallery">
					<ul>
						<?php 
						$gallery_data = $this->langar_model->select_data('g_image' , 'gallery' , '' ,6 , array('g_id' , 'DESC'));
						if(!empty($gallery_data)){
							foreach($gallery_data as $gallery){
								$img = explode('.',$gallery['g_image']);	
								echo '<li><img src="'.base_url('assets/img/gallery/'.$img[0].'_thumb.'.$img[1]).'" alt="1" title="image1"></li>';
							}
						}
						?>
					</ul>
				</div>
			</div>
		</div>
	</div>
</div> 
<div class="ls_footer_bottom">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<p><?php echo $this->site_detail->site_copyright; ?></p>
			</div>
		</div>
	</div>
</div>
<div class="hide"><?php echo (isset($payment_form))?$payment_form:''; ?></div>
  
<script type="text/javascript" src="<?php echo base_url('assets/js/jquery-1.12.3.min.js');?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/js/bootstrap.js');?>"></script>
<script src="<?php echo base_url('assets/js/modernizr.custom.js');?>" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo base_url('assets/js/plugins/countto/jquery.countTo.js');?>"></script> 
<script type="text/javascript" src="<?php echo base_url('assets/js/plugins/countto/jquery.appear.js');?>"></script>
<script src="<?php echo base_url('assets/js/plugins/owl/owl.carousel.js');?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets/js/plugins/jqueryui/jquery-ui.js');?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets/js/valid.js'); ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/js/custom.js');?>"></script>
<?php 
	if($this->session->flashdata('notice') != ''){
		echo '<script>message("'.$this->session->flashdata('notice').'","error");</script>';
	}
	
	if($this->session->flashdata('error') != ''){
		echo '<script>message("'.$this->session->flashdata('error').'","error");</script>';
	}
	
	if($this->session->flashdata('success') != ''){
		echo '<script>message("'.$this->session->flashdata('success').'","success");</script>';
	}
?>
</body>
</html>