<!-- Modal -->
<div class="modal fade ls_login_popup" id="loginpopup" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title">Login form</h4>
			</div>
			<div class="modal-body">
				<form method="post">
					<div class="form-group">
						<div class="input-group">
							<div class="input-group-addon"><i class="fa fa-user"></i></div>
							<input type="text" class="form-group require" id="lg_email" placeholder="Enter Email" data-valid="email" data-error="Email should be valid">
						</div>
					</div>
					<div class="form-group">
						<div class="input-group">
							<div class="input-group-addon"><i class="fa fa-lock"></i></div>
							<input type="password" id="lg_password" class="form-group require" placeholder="Enter Password">
						</div>
					</div>
					<button type="button" class="ls_btn logIn">SUbMit</button>
					<a class="ls_forget_pwd" onclick="$(this).parent().find('.closeModal').trigger('click');" data-toggle="modal" data-target="#forgetpwd">forget password</a>
					
					<button type="button" class="btn btn-default hide closeModal" data-dismiss="modal"></button>
				</form>
			</div>
		</div>
	</div>
</div>
<div class="modal fade ls_login_popup" id="signuppopup" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title">Sign up form</h4>
			</div>
			<div class="modal-body">
				<form method="post" action="<?php echo base_url('home/sign_up'); ?>">
					<div class="form-group">
						<div class="input-group">
							<div class="input-group-addon"><i class="fa fa-user"></i></div>
							<input type="text" name="uName" class="form-group require" placeholder="Enter Your Name">
						</div>
					</div>
					<div class="form-group">
						<div class="input-group">
							<div class="input-group-addon"><i class="fa fa-envelope"></i></div>
							<input type="text" name="uEmail" id="u_email" class="form-group require" data-valid="email" data-error="Email should be valid" placeholder="Enter Your Email">
						</div>
					</div>
					<div class="form-group">
						<div class="input-group">
							<div class="input-group-addon"><i class="fa fa-lock"></i></div>
							<input type="password" name="uPassword" id="u_password" class="form-group require" placeholder="Enter Password">
						</div>
					</div>
					<div class="form-group">
						<div class="input-group">
							<div class="input-group-addon"><i class="fa fa-repeat"></i></div>
							<input type="password" id="u_cnf_password" class="form-group require" placeholder="Confirm Password">
						</div>
					</div>
					<?php /*<div class="form-group">
						<div class="input-group">
							<div class="input-group-addon"><i class="fa fa-calendar"></i></div>
							<input type="text"  name="uDOB" class="ls_dateinput require datepicker_dob" placeholder="Date of Birth">
						</div>
					</div> */ ?>
					<button type="button" class="ls_btn signUp">SUbMit</button>
				</form>
			</div>
		</div>
	</div>
</div>


<div class="modal fade ls_login_popup" id="forgetpwd" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title">Forget Password</h4>
			</div>
			<div class="modal-body">
				<form method="post" action="">
					<div class="form-group">
						<div class="input-group"> 
							<div class="input-group-addon"><i class="fa fa-envelope"></i></div>
							<input type="text" class="form-group require" data-valid="email" data-error="Email should be valid" placeholder="Enter Your Email " id="reset_email">
						</div>
					</div>
					<button type="button" class="ls_btn resetPass">SUbMit</button>
				</form>
			</div>
		</div>
	</div>
</div>
