/** MOTO Themes Landing Page  **/

(function($) {
  "use strict";
  var moto = {
    initialised: false,
    version: 1.0,
    mobile: false,
    init: function() {
      if (!this.initialised) {
        this.initialised = true;
      } else {
        return;
      }
      /*-------------- moto Functions Calling ---------------------------------------------------
      ------------------------------------------------------------------------------------------------*/
      
      this.video();
      this.custom_animation();
    },
    /*-------------- moto Functions definition ---------------------------------------------------
    ---------------------------------------------------------------------------------------------------*/
	
	video: function(){
		$(".pro_video").css("display", "none");
		$(".mt_video_wrapper .mt_overlay > a").on("click", function(e){
			e.preventDefault(); 
			$(".mt_video_wrapper .mt_vedio").hide(),
			$(".pro_video").css("display", "block"), 
			$(".pro_video").attr("src", t(".pro_video").attr("src") + "?autoplay=1")
		})
	},
	custom_animation: function() {
		// Changing the defaults
		window.sr = ScrollReveal({ 
			duration   : 300,
			distance   : "-50px",
			scale      : 0.8,
			reset: false 
		});
		// Customizing a reveal set
		sr.reveal('.sp_launch_section, .sp_wordpress_design_box, .sp_image_box, .sp_gradient_box, .sp_testimonial_section, .sp_border-box, .sp_video_profit_box, .sp_link_box, .sp_demo_box, .sp_beginner_box ,.sp_border_shape, .sp_give_box ', { duration: 600 }, 100);
	}
   };
   
   	$(document).ready(function() {
		moto.init();
		$('body').addClass('site_loaded');
		
		// stickybar start
		$('.hs_stickybar_toggle').click(function(){
			$('.hs_stickybar_wrapper').toggleClass('stickybar_close');
		});
		// stickybar end
	});
	$(window).on('load', function(){
		
	});
	
})(jQuery);
